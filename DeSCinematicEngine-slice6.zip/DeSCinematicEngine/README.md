# DeS Live Cinematic Engine (DeSCinematicEngine)

Live, deterministic, in-world cinematic productions for Paper. Actors physically exist in the world; players stay free
(no spectator mode, no seats, no camera control, no teleporting). First production: **AZRATHIEL - THE NULL//REQUIEM INCIDENT**.

## Honest status (read this first)

| Level | Status |
|---|---|
| Source implementation | **All subsystems written** (actors, combat, weapons, environment + restoration, audio/dialogue, presentation, commands, API) |
| Offline logic verified (JDK 21, no server) | **Yes**: timeline/validator/motion (40), ERROR rig + 41 clips (97), AZRATHIEL animation mapping (61), chamber structure (10), module coverage (51 actions), choreography simulation (30 impacts, worst reach excess 0.36 blocks), all 8 scenes validate |
| Compilation against Paper 26.2 | **NOT DONE** (no network in the authoring sandbox). Only a "no unresolved own-class symbols" consistency pass was possible |
| Dependency integration verified | NOT DONE |
| Server startup verified | NOT DONE |
| Gameplay tested | NOT DONE |
| Full production tested | NOT DONE |

Expect a first build to need small API fixes, and the visual tuning values below to need adjusting in game.

### What changed after the first real server test
- **ERROR's skin was garbled:** the model UVs were in pixel space; Minecraft model UVs are always 0..16. Fixed in `tools/gen_player_rig.py` and guarded by `tools/check_pack.py` (UV range check). `tools/render_rig_preview.py` renders the rig offline for a visual check.
- **The fight died after the summon:** `Particle.FLASH` needs colour data on current versions and threw inside the main loop, aborting the whole production. Every particle now goes through `Fx` (supplies required data, logs once, never throws); each module's tick is isolated; failed actions are logged and the show continues (`engine.abort-on-critical-failure: false`). Each run writes `plugins/DeSCinematicEngine/logs/<production>-<time>.log` and OPs get a summary in chat.
- **AZRATHIEL's animations are now this engine's own** (`tools/gen_azrathiel_clips.py`); the animation classes from the original plugin were removed. His 3D model is unchanged.
- **Much more cinematic:** reusable macros (slam, flash, bolt, blast), auras, visual-only lightning, movement trails, scythe energy, hit-stop, heavier impacts with automatic sound, faster chamber build, tighter pacing (209 s instead of 400 s), denser fights verified by an offline choreography simulation (44 impacts, worst reach excess 0.40 blocks).

### Known gaps
- **No voice recordings** (owner cannot supply them). The playback system is complete; until `.ogg` files exist the three dialogue slots are silent and a clearly labelled caption fallback is shown (only the final line has script text; the other two lines have not been written).
- **ModelEngine adapter not implemented.** Both actors use the built-in item_display rigs (ERROR: generated player rig + 41 procedural clips; AZRATHIEL: the existing bone rig, vendored). `backend: modelengine` is rejected by `validate`.
- **time_scale / freeze** slow actors and weapon fragments only; world particles and debris keep real time.
- **Lighting** is done with hidden `light` blocks placed by the chamber structure, driven by `env_light`/`fade_world`. No client time/weather changes, no camera control.
- Tile-entity blocks are never modified (so they cannot be lost); the journal restores block data exactly.

### Block-name compatibility (chains)
`minecraft:chain` was rejected by a real Paper 26.2 server. The engine now resolves every structure block against the running server
(`BlockCompat` + `BlockResolver`): as written, then `[axis=y]`, then the renamed spelling (`iron_chain`), then the structure's declared
fallbacks (`block_fallbacks` in the structure file: vertical iron bars, same positions and count). `/descinematic validate` prints which
spelling the server accepted (INFO), a WARN if a fallback is used, and an ERROR only if nothing works. Logic is covered by
`BlockCompatTests` against simulated registries; real-server behaviour is confirmed by running `validate` there.

### Tune in game (values are educated starting points)
`actors/azrathiel.yml: ground_offset`, `weapons/*.yml: hold/stow` (grip, rotation, offsets), head top/bottom skin faces of the player rig, crater/crack sizes, light levels.

## Build
`gradle build` (Java 25, Paper API via `paperVersion` in gradle.properties). Offline core tests: `sh tools/run_core_tests.sh`
(JDK 21+; production-file test needs python3 + PyYAML). Regenerate `defaults.index` with `tools/gen_index.sh` after adding default files.

## Install
Jar -> `plugins/`. Use `DeS-Pack-with-Cinematic.zip` (your merged pack + `des_cinematic`), or merge `resourcepack/assets/des_cinematic` into your own pack yourself. The merged pack declares formats 46-999, which already covers 88. Verify with `python3 tools/check_pack.py <your_pack_dir> resourcepack`. In-game: stand at the arena floor centre and run `/descinematic setorigin azrathiel_null_requiem`.

## Commands (OP only)
`help list status start|stop|pause|resume reload preview <p> validate <p> reset <p> setorigin <p> debug`.
`preview` is a dry run that prints the schedule; it spawns nothing.

## Developer API
`CinematicEngine.isAvailable()` / `CinematicEngine.get().start("id")`; extend with `registerModule(ActionModule)`. Soft dependency only.

## Production format
`productions/<id>/production.yml` + `scenes/*.yml` + `weapons/*.yml`; `actors/*.yml`. Times in seconds (or `tick:`), coordinates relative to
origin. Block-changing actions are rejected unless inside a `destructible` region. See `ActionCatalog` for the full action vocabulary.
