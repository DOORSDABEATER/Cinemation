#!/bin/sh
# Compiles and runs the pure-Java core (no Paper needed). Requires JDK 21+ (or a JRE that ships jdk.compiler).
set -e
cd "$(dirname "$0")/.."
rm -rf build/core && mkdir -p build/core
FILES=$(find src/main/java/com/des/cinematic/core src/main/java/com/des/cinematic/motion src/main/java/com/des/cinematic/rig src/main/java/com/des/cinematic/vael src/test/java -name '*.java' ! -name VaelRig.java)
if command -v javac >/dev/null 2>&1; then javac -d build/core $FILES
else java -m jdk.compiler/com.sun.tools.javac.Main -d build/core $FILES; fi
java -cp build/core com.des.cinematic.CoreTests
if command -v python3 >/dev/null 2>&1 && python3 -c "import yaml" 2>/dev/null; then
  python3 tools/yaml_to_json.py build/bundle.json
  java -cp build/core com.des.cinematic.ProductionFilesTest build/bundle.json
  java -cp build/core com.des.cinematic.RigTests build/bundle.json
  java -cp build/core com.des.cinematic.VaelTests build/bundle.json
  java -cp build/core com.des.cinematic.StructureTests build/bundle.json
  java -cp build/core com.des.cinematic.ModuleCoverageTest build/bundle.json
  java -cp build/core com.des.cinematic.BlockCompatTests build/bundle.json
  java -cp build/core com.des.cinematic.ChoreographySim build/bundle.json
else echo "(skipping production file test: python3 + PyYAML not available)"; fi
