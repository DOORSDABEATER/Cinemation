#!/bin/sh
# No Paper jar offline: compile everything and report ONLY errors that are not about missing Bukkit/Adventure/JOML types.
# This is a typo/consistency check for our own code, NOT a real build.
cd "$(dirname "$0")/.."
rm -rf build/all && mkdir -p build/all
java -m jdk.compiler/com.sun.tools.javac.Main -proc:none -Xmaxerrs 20000 -d build/all $(find src/main/java -name '*.java') > /tmp/javac.out 2>&1; rm -f javac.*.args
EXT='Location|World|Material|Bukkit|Particle|Player|Block|BlockData|JavaPlugin|Component|NamedTextColor|SoundCategory|Title|Plugin|BukkitRunnable|BukkitTask|TileState|BlockDisplay|Transformation|Quaternionf|Vector3f|Matrix4f|Vector|ItemDisplay|ItemStack|ItemMeta|NamespacedKey|Entity|Command|CommandSender|TabCompleter|CommandExecutor|TextColor|ConfigurationSection|YamlConfiguration|CustomModelDataComponent|Color|Display|RayTraceResult|FluidCollisionMode|TeleportFlag|Vector3d|DustOptions'
echo "own-code unresolved symbols (should be empty):"
grep -A4 "cannot find symbol" /tmp/javac.out | grep -E "^\s+symbol:" | sed -E 's/^ *symbol: *//' | grep -v -E "^(class|variable) ($EXT)\b" | grep -v -E "^method (cancel|getCommand|getDataFolder|getLogger|getResource|getServer|getX|getY|getZ|saveDefaultConfig|saveResource)\(" | sort -u
echo "other compile errors (should be empty):"
grep "error:" /tmp/javac.out | grep -v -E "cannot find symbol|does not exist|method does not override" | sed -E 's/^.*cinematic\///' | head -10
echo "(end)"
