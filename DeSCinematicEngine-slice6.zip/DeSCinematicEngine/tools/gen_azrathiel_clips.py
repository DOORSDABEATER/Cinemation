#!/usr/bin/env python3
"""Authors AZRATHIEL's OWN animation clips over the rig's 28 pose parameters -> src/main/resources/rigs/azrathiel_clips.yml
(no animation from any earlier plugin is used). Channels: see rig/ParamClipLibrary. arm lists are [UL, UR, LL, LR].
Design intent: at rest he is slow, symmetrical, unhurried (authority); each action is economical; the ultimate is the only time he opens up."""
import yaml, os
BASE = dict(torso_pitch=0, torso_roll=0, lean=0, sink=0, arm_raise=[8, 8, 16, 16], arm_spread=[14, 14, 26, 26], fore_bend=[20, 20, 30, 30],
            halo_speed=26, halo_radius=1.0, halo_tilt=0, frag_radius=1.6, frag_speed=50, frag_bob=0.10, core_scale=1.0, core_pulse=0.5,
            hover_amp=0.08, hover_hz=0.40, body_scale=1.0, glow=0.7)
C = {}
def K(t, **ch): d = {'t': round(t, 3)}; d.update(ch); return d
def clip(cid, dur, keys, loop=False, ease='in_out_quad'): C[cid] = {'duration': dur, 'loop': loop, 'ease': ease, 'keys': keys}

# ---------------- stillness & presence
clip('azr_idle', 4.0, [K(0), K(2.0, torso_pitch=1.4, arm_raise=[10, 10, 18, 18], core_scale=1.06, glow=0.78, hover_amp=0.07), K(4.0)], loop=True)
clip('azr_guard', 2.0, [K(0, torso_pitch=7, lean=2, arm_raise=[46, 46, 36, 36], arm_spread=[30, 30, 34, 34], fore_bend=[42, 42, 48, 48], halo_speed=80, core_scale=1.15, glow=0.9, frag_speed=110),
                        K(1.0, torso_pitch=8, lean=3, arm_raise=[50, 50, 40, 40], arm_spread=[32, 32, 36, 36], fore_bend=[44, 44, 50, 50], halo_speed=90, core_scale=1.2, glow=0.95, frag_speed=125),
                        K(2.0, torso_pitch=7, lean=2, arm_raise=[46, 46, 36, 36], arm_spread=[30, 30, 34, 34], fore_bend=[42, 42, 48, 48], halo_speed=80, core_scale=1.15, glow=0.9, frag_speed=110)], loop=True)
clip('azr_emerge', 3.4, [K(0, body_scale=0.55, sink=-0.9, arm_raise=[0, 0, 0, 0], arm_spread=[4, 4, 6, 6], fore_bend=[6, 6, 6, 6], halo_radius=0.0, core_scale=0.1, frag_radius=0.4, glow=0.1, halo_speed=300),
                         K(1.2, body_scale=0.82, sink=-0.45, arm_raise=[-6, -6, 0, 0], arm_spread=[38, 38, 50, 50], halo_radius=0.7, core_scale=1.8, frag_radius=2.4, glow=0.9, halo_speed=200, frag_speed=180),
                         K(2.4, body_scale=1.05, sink=0.05, arm_raise=[14, 14, 22, 22], arm_spread=[46, 46, 58, 58], halo_radius=1.2, core_scale=2.0, frag_radius=2.0, glow=1.0, halo_speed=120, frag_speed=110),
                         K(3.4)], ease='out_cubic')
clip('azr_walk', 1.8, [K(0, lean=4, torso_pitch=2, arm_raise=[16, 4, 22, 10], halo_speed=42, frag_speed=80, hover_amp=0.05, hover_hz=0.55),
                       K(0.9, lean=4, torso_pitch=2.5, arm_raise=[4, 16, 10, 22], halo_speed=42, frag_speed=80, hover_amp=0.05, hover_hz=0.55),
                       K(1.8, lean=4, torso_pitch=2, arm_raise=[16, 4, 22, 10], halo_speed=42, frag_speed=80, hover_amp=0.05, hover_hz=0.55)], loop=True, ease='in_out_quad')
clip('azr_stride', 1.5, [K(0, lean=7, torso_pitch=5, arm_raise=[-4, -10, 4, -2], arm_spread=[20, 20, 32, 32], halo_speed=70, frag_speed=140, glow=0.85, core_scale=1.1, hover_amp=0.04, hover_hz=0.7),
                         K(0.75, lean=8, torso_pitch=6, arm_raise=[-10, -4, -2, 4], arm_spread=[20, 20, 32, 32], halo_speed=70, frag_speed=140, glow=0.85, core_scale=1.1, hover_amp=0.04, hover_hz=0.7),
                         K(1.5, lean=7, torso_pitch=5, arm_raise=[-4, -10, 4, -2], arm_spread=[20, 20, 32, 32], halo_speed=70, frag_speed=140, glow=0.85, core_scale=1.1, hover_amp=0.04, hover_hz=0.7)], loop=True, ease='linear')
clip('azr_turn', 0.9, [K(0), K(0.4, torso_roll=9, lean=3, halo_speed=140, frag_speed=100, arm_spread=[22, 22, 34, 34]), K(0.9)])
clip('azr_acknowledge', 1.6, [K(0), K(0.5, torso_pitch=11, arm_raise=[14, 14, 20, 20], core_scale=1.35, glow=0.95, halo_speed=70),
                              K(1.0, torso_pitch=9, core_scale=1.25, glow=0.9), K(1.6)])
clip('azr_look_down', 4.0, [K(0, torso_pitch=0), K(0.9, torso_pitch=15, arm_raise=[6, 6, 12, 12], arm_spread=[18, 18, 30, 30], halo_speed=14, frag_speed=30, core_scale=0.95, glow=0.55),
                            K(4.0, torso_pitch=15, arm_raise=[6, 6, 12, 12], arm_spread=[18, 18, 30, 30], halo_speed=14, frag_speed=30, core_scale=0.95, glow=0.55)], ease='out_quad')
# ---------------- defence
BLK = dict(torso_pitch=11, lean=-2, arm_raise=[88, 88, 74, 74], arm_spread=[-4, -4, 2, 2], fore_bend=[74, 74, 66, 66], core_scale=1.5, glow=1.0, halo_speed=190, halo_radius=1.1)
clip('azr_block', 1.0, [K(0, **BLK), K(0.5, **{**BLK, 'core_scale': 1.62, 'halo_speed': 210, 'halo_radius': 1.13, 'arm_raise': [90, 90, 76, 76]}), K(1.0, **BLK)], loop=True, ease='in_out_quad')
clip('azr_dodge', 0.6, [K(0, torso_pitch=7, arm_raise=[46, 46, 36, 36]), K(0.14, torso_roll=-17, lean=-11, sink=-0.16, arm_spread=[52, 52, 62, 62], arm_raise=[20, 20, 24, 24], halo_speed=260, frag_speed=260, glow=1.0),
                        K(0.34, torso_roll=-6, lean=-4, sink=-0.05, arm_spread=[34, 34, 44, 44], halo_speed=140), K(0.6, torso_pitch=7, arm_raise=[46, 46, 36, 36], halo_speed=80)], ease='out_cubic')
clip('azr_hit', 0.6, [K(0, torso_pitch=7, arm_raise=[46, 46, 36, 36]), K(0.08, torso_pitch=-15, lean=-13, sink=0.04, arm_spread=[46, 46, 56, 56], arm_raise=[18, 18, 22, 22], glow=0.2, core_scale=0.7),
                      K(0.25, torso_pitch=-5, lean=-5, glow=0.8, core_scale=1.1), K(0.6, torso_pitch=7, arm_raise=[46, 46, 36, 36], glow=0.9)], ease='out_quad')
clip('azr_stagger', 1.0, [K(0, torso_pitch=7), K(0.1, torso_pitch=-24, lean=-22, torso_roll=8, sink=0.1, arm_spread=[58, 58, 68, 68], arm_raise=[10, 10, 14, 14], glow=0.15, core_scale=0.55, halo_speed=300),
                          K(0.5, torso_pitch=-10, lean=-9, torso_roll=3, glow=0.7, core_scale=1.0), K(1.0, torso_pitch=7, arm_raise=[46, 46, 36, 36], glow=0.9, core_scale=1.1)], ease='out_quad')
# ---------------- attacks (economical: he never flails)
clip('azr_counter', 0.7, [K(0, torso_pitch=7, arm_raise=[46, 46, 36, 36]), K(0.12, torso_pitch=3, torso_roll=-8, arm_raise=[-18, 20, 22, 32], arm_spread=[34, 24, 36, 30], core_scale=1.3, glow=1.0),
                          K(0.26, torso_pitch=17, lean=22, torso_roll=6, arm_raise=[56, 90, 48, 82], arm_spread=[34, 8, 36, 10], fore_bend=[40, 6, 44, 8], core_scale=1.8, glow=1.0, halo_speed=220),
                          K(0.7, torso_pitch=7, arm_raise=[46, 46, 36, 36], core_scale=1.15, glow=0.9, halo_speed=80)], ease='out_quad')
clip('azr_minimal', 0.5, [K(0, torso_pitch=7), K(0.1, torso_pitch=4, arm_raise=[30, 18, 34, 26], core_scale=1.25), K(0.2, torso_pitch=12, lean=14, arm_raise=[40, 78, 38, 70], arm_spread=[30, 10, 34, 12], fore_bend=[40, 10, 44, 12], core_scale=1.6, glow=1.0),
                          K(0.5, torso_pitch=7, arm_raise=[46, 46, 36, 36], core_scale=1.15)], ease='out_quad')
clip('azr_palm', 0.7, [K(0, torso_pitch=7, arm_raise=[46, 46, 36, 36]), K(0.14, torso_pitch=2, arm_raise=[38, 52, 34, 46], core_scale=1.35, glow=1.0),
                       K(0.28, torso_pitch=14, lean=16, arm_raise=[44, 98, 40, 92], arm_spread=[30, 4, 34, 6], fore_bend=[40, 4, 44, 6], core_scale=2.1, glow=1.0, halo_speed=260, frag_speed=220, frag_radius=1.3),
                       K(0.7, torso_pitch=7, arm_raise=[46, 46, 36, 36], core_scale=1.2, frag_radius=1.7)], ease='out_quad')
clip('azr_strike', 1.1, [K(0, torso_pitch=7), K(0.3, torso_pitch=-16, lean=-12, sink=0.08, arm_raise=[168, 168, 150, 150], arm_spread=[20, 20, 28, 28], fore_bend=[22, 22, 30, 30], core_scale=2.2, frag_radius=2.3, frag_speed=240, halo_radius=1.2, halo_speed=260, glow=1.0),
                         K(0.48, torso_pitch=30, lean=30, sink=-0.1, arm_raise=[22, 22, 12, 12], arm_spread=[24, 24, 30, 30], core_scale=2.6, glow=1.0),
                         K(1.1, torso_pitch=8, arm_raise=[46, 46, 36, 36], core_scale=1.2, frag_radius=1.8, halo_speed=90)], ease='out_cubic')
clip('azr_sweep', 1.0, [K(0, torso_pitch=7, arm_raise=[46, 46, 36, 36]), K(0.22, torso_pitch=5, torso_roll=-20, lean=-6, arm_raise=[70, 40, 60, 30], arm_spread=[84, 20, 90, 24], core_scale=1.6, glow=1.0),
                        K(0.46, torso_pitch=11, torso_roll=22, lean=12, arm_raise=[40, 70, 30, 60], arm_spread=[20, 86, 24, 92], core_scale=2.0, glow=1.0, halo_speed=280, frag_speed=260),
                        K(1.0, torso_pitch=7, arm_raise=[46, 46, 36, 36], core_scale=1.15, halo_speed=90)], ease='out_quad')
clip('azr_flare', 0.9, [K(0, torso_pitch=7), K(0.2, torso_pitch=-6, arm_raise=[60, 60, 50, 50], arm_spread=[70, 70, 82, 82], core_scale=2.4, glow=1.0, halo_radius=1.5, halo_speed=320, frag_radius=3.0, frag_speed=300, body_scale=1.05),
                        K(0.9, torso_pitch=7, arm_raise=[46, 46, 36, 36], arm_spread=[30, 30, 34, 34], core_scale=1.2, halo_radius=1.05, halo_speed=90, frag_radius=1.8, frag_speed=125, body_scale=1.0)], ease='out_cubic')
clip('azr_finisher_prep', 1.4, [K(0, torso_pitch=7), K(0.4, torso_pitch=-4, arm_raise=[110, 110, 96, 96], arm_spread=[40, 40, 52, 52], fore_bend=[24, 24, 30, 30], core_scale=1.8, halo_radius=1.3, halo_speed=170, frag_radius=2.4, frag_speed=200, glow=1.0),
                                K(1.4, torso_pitch=-6, arm_raise=[116, 116, 100, 100], arm_spread=[42, 42, 54, 54], core_scale=2.1, halo_radius=1.4, halo_speed=220, frag_radius=2.6, frag_speed=240, glow=1.0, hover_amp=0.12)], loop=False, ease='out_quad')
# ---------------- the ultimate
clip('azr_ult_charge', 2.0, [K(0, torso_pitch=-3, arm_raise=[148, 148, 132, 132], arm_spread=[60, 60, 72, 72], fore_bend=[16, 16, 22, 22], core_scale=2.5, halo_radius=1.7, halo_speed=250, halo_tilt=28, frag_radius=3.2, frag_speed=320, frag_bob=0.2, body_scale=1.06, hover_amp=0.17, hover_hz=0.9, glow=1.0),
                             K(1.0, torso_pitch=-6, arm_raise=[156, 156, 140, 140], arm_spread=[66, 66, 78, 78], core_scale=2.9, halo_radius=1.95, halo_speed=300, halo_tilt=34, frag_radius=3.6, frag_speed=380, frag_bob=0.24, body_scale=1.1, hover_amp=0.2, hover_hz=1.0, glow=1.0),
                             K(2.0, torso_pitch=-3, arm_raise=[148, 148, 132, 132], arm_spread=[60, 60, 72, 72], fore_bend=[16, 16, 22, 22], core_scale=2.5, halo_radius=1.7, halo_speed=250, halo_tilt=28, frag_radius=3.2, frag_speed=320, frag_bob=0.2, body_scale=1.06, hover_amp=0.17, hover_hz=0.9, glow=1.0)], loop=True)
clip('azr_ult_release', 1.2, [K(0, torso_pitch=-6, arm_raise=[156, 156, 140, 140], arm_spread=[66, 66, 78, 78], core_scale=2.9, halo_radius=1.95, frag_radius=3.6, body_scale=1.1, glow=1.0, halo_speed=300),
                              K(0.2, torso_pitch=26, lean=24, arm_raise=[96, 96, 92, 92], arm_spread=[8, 8, 10, 10], fore_bend=[4, 4, 6, 6], core_scale=3.3, halo_radius=2.3, halo_speed=420, halo_tilt=10, frag_radius=4.2, frag_speed=480, body_scale=1.14, glow=1.0),
                              K(1.2, torso_pitch=24, lean=22, arm_raise=[96, 96, 92, 92], arm_spread=[8, 8, 10, 10], fore_bend=[4, 4, 6, 6], core_scale=3.1, halo_radius=2.2, halo_speed=400, frag_radius=4.0, frag_speed=460, body_scale=1.12, glow=1.0)], loop=False, ease='out_cubic')

out = os.path.join(os.path.dirname(__file__), '..', 'src', 'main', 'resources', 'rigs', 'azrathiel_clips.yml')
with open(out, 'w') as f:
    f.write('# GENERATED by tools/gen_azrathiel_clips.py - edit the generator, not this file.\n')
    yaml.safe_dump({'base': BASE, 'clips': C}, f, default_flow_style=None, sort_keys=False, width=220)
print('wrote', len(C), 'clips ->', out)
