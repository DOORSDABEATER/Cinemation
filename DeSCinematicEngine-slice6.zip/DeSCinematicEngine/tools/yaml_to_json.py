#!/usr/bin/env python3
"""Offline helper for tests: converts the bundled YAML into one JSON bundle the dependency-free Java test can read."""
import json, sys, glob, os, yaml
root = os.path.join(os.path.dirname(__file__), '..', 'src', 'main', 'resources')
pd = os.path.join(root, 'productions')
bundle = {'actors': {}, 'productions': {}, 'rigs': {}, 'structures': {}}
for f in glob.glob(os.path.join(root, 'actors', '*.yml')):
    d = yaml.safe_load(open(f)); bundle['actors'][d['id']] = d
for p in sorted(os.listdir(pd)):
    base = os.path.join(pd, p)
    prod = yaml.safe_load(open(os.path.join(base, 'production.yml')))
    scenes = {}
    for f in sorted(glob.glob(os.path.join(base, 'scenes', '*.yml'))):
        d = yaml.safe_load(open(f)); scenes[d['id']] = d
    weapons = {}
    for f in glob.glob(os.path.join(base, 'weapons', '*.yml')):
        d = yaml.safe_load(open(f)); weapons[d['id']] = d
    bundle['productions'][prod['id']] = {'production': prod, 'scenes': scenes, 'weapons': weapons}
for f in glob.glob(os.path.join(root, 'rigs', '*.yml')):
    bundle['rigs'][os.path.basename(f)[:-4]] = yaml.safe_load(open(f))
for f in glob.glob(os.path.join(root, 'structures', '*.yml')):
    d = yaml.safe_load(open(f)); bundle['structures'][d['id']] = d
out = sys.argv[1] if len(sys.argv) > 1 else 'build/bundle.json'
os.makedirs(os.path.dirname(out), exist_ok=True)
json.dump(bundle, open(out, 'w'))
print('wrote', out)
