#!/usr/bin/env python3
"""Checks that the des_cinematic additions resolve inside a combined pack: every model texture exists, every item definition points at an
existing model, every sound file referenced by sounds.json exists (voice slots are reported separately as missing recordings).
Usage: check_pack.py <base_pack_dir> <additions_dir>   (both contain assets/)"""
import json, os, sys, shutil, tempfile
base, add = sys.argv[1], sys.argv[2]
def files(root):
    out = set()
    for dp, _, fs in os.walk(root):
        for f in fs: out.add(os.path.relpath(os.path.join(dp, f), root).replace(os.sep, '/'))
    return out
have = files(base) | files(add)
def split(ref):
    ns, sep, p = ref.partition(':')
    return (ns, p) if sep else ('minecraft', ref)
def tex_ok(ref):
    ns, p = split(ref)
    return f'assets/{ns}/textures/{p}.png' in have
def model_ok(ref):
    ns, p = split(ref)
    return f'assets/{ns}/models/{p}.json' in have or ns == 'minecraft'
errors = 0; models = items = 0
for f in sorted(files(add)):
    if f.endswith('.json') and '/models/' in f:
        models += 1; m = json.load(open(os.path.join(add, f)))
        for el in m.get('elements', []):
            for fn, face in el.get('faces', {}).items():
                if any(not (0 <= c <= 16) for c in face.get('uv', [])): errors += 1; print('UV OUT OF 0..16 RANGE', f, fn, face['uv'])
        for k, v in m.get('textures', {}).items():
            if not v.startswith('#') and not tex_ok(v): errors += 1; print('MISSING TEXTURE', v, 'in', f)
    if f.endswith('.json') and '/items/' in f:
        items += 1; d = json.load(open(os.path.join(add, f)))
        ref = d.get('model', {}).get('model')
        if ref and not model_ok(ref): errors += 1; print('MISSING MODEL', ref, 'in', f)
snd = os.path.join(add, 'assets/des_cinematic/sounds.json'); missing_voice = []
if os.path.isfile(snd):
    for slot, e in json.load(open(snd)).items():
        for s in e.get('sounds', []):
            if s.get('type') == 'event': continue
            name = s['name']; ns, p = split(name)
            if f'assets/{ns}/sounds/{p}.ogg' not in have:
                if 'voice/' in p: missing_voice.append(slot)
                else: errors += 1; print('MISSING SOUND FILE', name, 'slot', slot)
print(f'checked {models} models, {items} item definitions; {errors} error(s); voice recordings missing: {missing_voice}')
sys.exit(1 if errors else 0)
