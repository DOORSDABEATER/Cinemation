#!/usr/bin/env python3
"""Generates a standard (classic-arm) Minecraft player rig as item models textured with a 64x64 skin.
Six bones (head, body, arm_r, arm_l, leg_r, leg_l); each model = base layer + inflated overlay layer, pivot at the joint = model centre (8,8,8).
Usage: gen_player_rig.py <actor_id> [skin_texture_resource_location]
Outputs resourcepack/assets/des_cinematic/{models/item/actor/<id>/*.json, items/actor_<id>_*.json}"""
import json, os, sys
actor = sys.argv[1] if len(sys.argv) > 1 else 'error'
tex = sys.argv[2] if len(sys.argv) > 2 else f'des_cinematic:actor/{actor}_skin'
root = os.path.join(os.path.dirname(__file__), '..', 'resourcepack', 'assets', 'des_cinematic')

# part: (w,h,d, base_uv, overlay_uv, y_range relative to pivot (bottom, top))
PARTS = {
  'head':  (8, 8, 8, (0, 0),   (32, 0),  (0, 8)),     # pivot = neck
  'body':  (8, 12, 4, (16, 16), (16, 32), (0, 12)),   # pivot = waist
  'arm_r': (4, 12, 4, (40, 16), (40, 32), (-12, 0)),  # pivot = shoulder
  'arm_l': (4, 12, 4, (32, 48), (48, 48), (-12, 0)),
  'leg_r': (4, 12, 4, (0, 16),  (0, 32),  (-12, 0)),  # pivot = hip
  'leg_l': (4, 12, 4, (16, 48), (0, 48),  (-12, 0)),
}
TEX = 64   # skin resolution in pixels
def faces(w, h, d, u, v):
    # standard skin layout in PIXELS. Character faces +Z (south): front->south, back->north, character's right side->west.
    px = {
      'up':    ([u + d, v, u + d + w, v + d], 180),
      'down':  ([u + d + w, v + d, u + d + 2 * w, v], 0),
      'west':  ([u, v + d, u + d, v + d + h], None),
      'south': ([u + d, v + d, u + d + w, v + d + h], None),
      'east':  ([u + d + w, v + d, u + 2 * d + w, v + d + h], None),
      'north': ([u + 2 * d + w, v + d, u + 2 * d + 2 * w, v + d + h], None),
    }
    # Minecraft model UVs are ALWAYS in 0..16 space, whatever the texture resolution => scale pixels by 16/TEX.
    out = {}
    for k, (uv, rot) in px.items():
        out[k] = {'uv': [round(c * 16.0 / TEX, 4) for c in uv]}
        if rot: out[k]['rotation'] = rot
    return out
def element(w, h, d, uv, yr, grow, name):
    cx = 8.0; y0 = 8.0 + yr[0] - grow; y1 = 8.0 + yr[1] + grow
    f = faces(w, h, d, *uv)
    for k in f: f[k]['texture'] = '#skin'
    return {'name': name, 'from': [cx - w / 2 - grow, y0, cx - d / 2 - grow], 'to': [cx + w / 2 + grow, y1, cx + d / 2 + grow], 'faces': f}
os.makedirs(os.path.join(root, 'models', 'item', 'actor', actor), exist_ok=True)
os.makedirs(os.path.join(root, 'items'), exist_ok=True)
for name, (w, h, d, base, over, yr) in PARTS.items():
    model = {'texture_size': [TEX, TEX], 'textures': {'skin': tex, 'particle': tex}, 'elements': [element(w, h, d, base, yr, 0.0, name), element(w, h, d, over, yr, 0.25, name + '_overlay')]}
    json.dump(model, open(os.path.join(root, 'models', 'item', 'actor', actor, name + '.json'), 'w'), indent=1)
    json.dump({'model': {'type': 'minecraft:model', 'model': f'des_cinematic:item/actor/{actor}/{name}'}}, open(os.path.join(root, 'items', f'actor_{actor}_{name}.json'), 'w'))
print('generated rig for', actor, list(PARTS))
