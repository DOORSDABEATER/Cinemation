#!/usr/bin/env python3
"""Offline orthographic render of the generated player rig straight from the model JSON + skin PNG (nearest-neighbour), to eyeball UVs.
Usage: render_rig_preview.py <skin.png> <out.png> [actor=error]. Draws FRONT (south faces) and BACK (north faces) and both SIDES."""
import json, os, sys
from PIL import Image
skin = Image.open(sys.argv[1]).convert('RGBA'); out = sys.argv[2]; actor = sys.argv[3] if len(sys.argv) > 3 else 'error'
root = os.path.join(os.path.dirname(__file__), '..', 'resourcepack', 'assets', 'des_cinematic', 'models', 'item', 'actor', actor)
# joint offsets (px) of each part's model centre (8,8,8) in rig space, x right(-)/left(+), y up
JOINT = {'head': (0, 24), 'body': (0, 12), 'arm_r': (-6, 24), 'arm_l': (6, 24), 'leg_r': (-2, 12), 'leg_l': (2, 12)}
S = 10   # pixels per model px
def face_img(face):
    u0, v0, u1, v1 = [c * 64 / 16.0 for c in face['uv']]
    box = (int(round(min(u0, u1))), int(round(min(v0, v1))), int(round(max(u0, u1))), int(round(max(v0, v1))))
    im = skin.crop(box)
    if u0 > u1: im = im.transpose(Image.FLIP_LEFT_RIGHT)
    if v0 > v1: im = im.transpose(Image.FLIP_TOP_BOTTOM)
    return im
def render(view):
    W, H = 20 * S, 34 * S; canvas = Image.new('RGBA', (W, H), (60, 60, 70, 255))
    items = []
    for part, (jx, jy) in JOINT.items():
        m = json.load(open(os.path.join(root, part + '.json')))
        for ei, el in enumerate(m['elements']):
            items.append((ei, part, jx, jy, el))
    items.sort(key=lambda t: t[0])   # base layer first, overlay on top
    for ei, part, jx, jy, el in items:
        f, t = el['from'], el['to']
        if view in ('south', 'north'):
            face = el['faces'][view]
            x0, x1 = f[0] - 8 + jx, t[0] - 8 + jx; y0, y1 = f[1] - 8 + jy, t[1] - 8 + jy
            im = face_img(face)
            if view == 'south': pass                  # looking at the character's front from +Z: character's right is on our left (-x)
            if view == 'north': x0, x1 = -x1, -x0
            if view == 'south': x0, x1 = x0, x1
            px0 = int((x0 + 10) * S); px1 = int((x1 + 10) * S); py0 = int((34 - (y1 + 0)) * S - 0); py1 = int((34 - y0) * S)
            if view == 'south': pass
            im = im.resize((max(1, px1 - px0), max(1, py1 - py0)), Image.NEAREST); canvas.alpha_composite(im, (px0, py0)) if True else None
        else:
            face = el['faces']['west' if view == 'west' else 'east']
            z0, z1 = f[2] - 8, t[2] - 8; y0, y1 = f[1] - 8 + jy, t[1] - 8 + jy
            im = face_img(face)
            if view == 'east': z0, z1 = -z1, -z0
            px0 = int((z0 + 10) * S); px1 = int((z1 + 10) * S); py0 = int((34 - y1) * S); py1 = int((34 - y0) * S)
            im = im.resize((max(1, px1 - px0), max(1, py1 - py0)), Image.NEAREST); canvas.alpha_composite(im, (px0, py0))
    return canvas
views = [render(v) for v in ('south', 'north', 'west', 'east')]
sheet = Image.new('RGBA', (sum(v.width for v in views), views[0].height)); x = 0
for v in views: sheet.paste(v, (x, 0)); x += v.width
sheet.save(out); print('wrote', out, sheet.size)
