#!/usr/bin/env python3
"""Splits an EXISTING weapon item model into assembly parts and shatter fragments WITHOUT changing its design.
Elements keep their absolute coordinates, so displaying all parts (or all fragments) with the same transform reconstructs the
original model exactly. Writes models + item definitions into the shared des_cinematic namespace and a parts metadata YAML
(centroids, needed so a fragment can be rotated about its own centre).
Usage: split_model.py <source_model.json> <weapon_id> [fragments=24]"""
import json, math, os, sys, yaml
src, wid = sys.argv[1], sys.argv[2]
K = int(sys.argv[3]) if len(sys.argv) > 3 else 24
root = os.path.join(os.path.dirname(__file__), '..')
ns = os.path.join(root, 'resourcepack', 'assets', 'des_cinematic')
d = json.load(open(src)); els = d['elements']

def cen(e):
    return [(e['from'][i] + e['to'][i]) / 2 for i in range(3)]
C = [cen(e) for e in els]
ax = sum(c[0] for c in C) / len(C)

# ---- assembly parts: shaft column (handle/shaft) vs blade elements, blade split by distance from the shaft top
shaft_idx = [i for i, c in enumerate(C) if abs(c[0] - 8) < 2.6]
top_y = max(els[i]['to'][1] for i in shaft_idx)
handle = [i for i in shaft_idx if C[i][1] < 8]
shaft = [i for i in shaft_idx if C[i][1] >= 8]
blade = [i for i in range(len(els)) if i not in shaft_idx]
blade.sort(key=lambda i: math.dist((C[i][0], C[i][1]), (8, top_y)))
n = len(blade); parts = {'handle': handle, 'shaft': shaft, 'blade_root': blade[:n // 3], 'blade_mid': blade[n // 3: 2 * n // 3], 'blade_tip': blade[2 * n // 3:]}

# ---- fragments: deterministic farthest-point seeded k-means over element centres
def kmeans(pts, k, iters=25):
    cs = [pts[0]]
    while len(cs) < k: cs.append(max(pts, key=lambda p: min(math.dist(p, c) for c in cs)))
    for _ in range(iters):
        groups = [[] for _ in range(k)]
        for i, p in enumerate(pts): groups[min(range(k), key=lambda j: math.dist(p, cs[j]))].append(i)
        cs = [[sum(pts[i][a] for i in g) / len(g) for a in range(3)] if g else cs[j] for j, g in enumerate(groups)]
    return [g for g in groups if g]
frags = kmeans(C, min(K, len(els)))
assert sorted(sum(parts.values(), [])) == list(range(len(els))), 'parts must cover every element exactly once'
assert sorted(sum(frags, [])) == list(range(len(els))), 'fragments must cover every element exactly once'

mdir = os.path.join(ns, 'models', 'item', wid); os.makedirs(mdir, exist_ok=True); os.makedirs(os.path.join(ns, 'items'), exist_ok=True)
def emit(name, idxs):
    m = {'textures': d['textures'], 'elements': [els[i] for i in idxs]}
    json.dump(m, open(os.path.join(mdir, name + '.json'), 'w'))
    json.dump({'model': {'type': 'minecraft:model', 'model': f'des_cinematic:item/{wid}/{name}'}}, open(os.path.join(ns, 'items', f'{wid}_{name}.json'), 'w'))
    cc = [sum(C[i][a] for i in idxs) / len(idxs) for a in range(3)]
    return [round(v, 3) for v in cc]
meta = {'weapon': wid, 'source_elements': len(els), 'parts': {}, 'fragments': []}
for name, idxs in parts.items(): meta['parts'][name] = {'item_model': f'des_cinematic:{wid}_{name}', 'centroid': emit(name, idxs), 'elements': len(idxs)}
for j, g in enumerate(frags): meta['fragments'].append({'item_model': f'des_cinematic:{wid}_fragment_{j}', 'centroid': emit(f'fragment_{j}', g), 'elements': len(g)})
meta['bbox_units'] = {'min': [min(e['from'][a] for e in els) for a in range(3)], 'max': [max(e['to'][a] for e in els) for a in range(3)]}
out = os.path.join(root, 'src', 'main', 'resources', 'weapons'); os.makedirs(out, exist_ok=True)
yaml.safe_dump(meta, open(os.path.join(out, wid + '_parts.yml'), 'w'), default_flow_style=None, sort_keys=False)
print(wid, ': parts', {k: len(v) for k, v in parts.items()}, '| fragments', len(frags), 'sizes', sorted(len(g) for g in frags))
