#!/usr/bin/env python3
"""Authors ERROR's procedural animation clips for the standard player rig -> src/main/resources/rigs/error_clips.yml
Schema: clips: <id>: {duration: seconds, loop: bool, ease: name, keys: [{t: seconds, <bone>: {rx,ry,rz,x,y,z}}]}
Bones: root head body arm_r arm_l leg_r leg_l.  rx>0: limbs swing forward / head+body tilt forward.  See rig/Pose.java."""
import yaml, os, math
C = {}
def K(t, **b): d = {'t': round(t, 3)}; d.update({k: v for k, v in b.items() if v}); return d
def clip(cid, dur, keys, loop=False, ease='in_out_quad'): C[cid] = {'duration': dur, 'loop': loop, 'ease': ease, 'keys': keys}
def lying(extra_root=None):
    r = {'rx': -90, 'y': -10}; r.update(extra_root or {}); return r

# ---------------- locomotion
clip('error_idle', 3.2, [K(0, body={'rx': 1}, arm_r={'rx': 4, 'rz': -3}, arm_l={'rx': 4, 'rz': 3}),
                         K(1.6, body={'rx': 2.5}, head={'rx': 1}, arm_r={'rx': 6, 'rz': -4}, arm_l={'rx': 6, 'rz': 4}, root={'y': -0.4}),
                         K(3.2, body={'rx': 1}, arm_r={'rx': 4, 'rz': -3}, arm_l={'rx': 4, 'rz': 3})], loop=True)
clip('error_combat_stance', 1.6, [K(0, root={'y': -3}, body={'rx': 10, 'ry': 12}, head={'rx': -6}, leg_r={'rx': 24}, leg_l={'rx': -18}, arm_r={'rx': 78, 'rz': -8}, arm_l={'rx': 68, 'rz': 10}),
                                  K(0.8, root={'y': -3.6}, body={'rx': 12, 'ry': 10}, head={'rx': -6}, leg_r={'rx': 26}, leg_l={'rx': -20}, arm_r={'rx': 82, 'rz': -8}, arm_l={'rx': 72, 'rz': 10}),
                                  K(1.6, root={'y': -3}, body={'rx': 10, 'ry': 12}, head={'rx': -6}, leg_r={'rx': 24}, leg_l={'rx': -18}, arm_r={'rx': 78, 'rz': -8}, arm_l={'rx': 68, 'rz': 10})], loop=True)
def cycle(cid, dur, leg, arm, lean, bob, arm_bend=0):
    ks = []
    for i, ph in enumerate([0, 0.25, 0.5, 0.75, 1.0]):
        s = math.sin(2 * math.pi * ph); c = math.cos(2 * math.pi * ph)
        ks.append(K(dur * ph, root={'y': -abs(c) * bob, 'rx': lean}, body={'ry': -s * 5, 'rx': lean * 0.5}, head={'ry': s * 3},
                    leg_r={'rx': s * leg}, leg_l={'rx': -s * leg}, arm_r={'rx': -s * arm + arm_bend}, arm_l={'rx': s * arm + arm_bend}))
    clip(cid, dur, ks, loop=True, ease='linear')
cycle('error_walk', 1.0, 32, 26, 2, 0.8)
cycle('error_run', 0.5, 58, 62, 14, 1.8, arm_bend=40)
clip('error_turn', 0.9, [K(0), K(0.35, body={'ry': -22}, head={'ry': -35}, leg_r={'rx': 6}, leg_l={'rx': -6}), K(0.9)])
clip('error_jump', 0.6, [K(0, root={'y': -4}, leg_r={'rx': 20}, leg_l={'rx': 20}, arm_r={'rx': -25}, arm_l={'rx': -25}),
                         K(0.2, root={'y': 1}, leg_r={'rx': -10}, leg_l={'rx': 5}, arm_r={'rx': 130}, arm_l={'rx': 130}),
                         K(0.6, root={'y': 0}, leg_r={'rx': 30}, leg_l={'rx': -8}, arm_r={'rx': 95, 'rz': -25}, arm_l={'rx': 95, 'rz': 25})], ease='out_quad')
clip('error_fall', 0.8, [K(0, arm_r={'rx': 60, 'rz': -55}, arm_l={'rx': 60, 'rz': 55}, leg_r={'rx': 14}, leg_l={'rx': -10}),
                         K(0.4, arm_r={'rx': 75, 'rz': -70}, arm_l={'rx': 75, 'rz': 70}, leg_r={'rx': -12}, leg_l={'rx': 12}),
                         K(0.8, arm_r={'rx': 60, 'rz': -55}, arm_l={'rx': 60, 'rz': 55}, leg_r={'rx': 14}, leg_l={'rx': -10})], loop=True)
clip('error_land', 0.6, [K(0, root={'y': 0}), K(0.12, root={'y': -7}, body={'rx': 22}, leg_r={'rx': 55}, leg_l={'rx': 55}, arm_r={'rx': 30}, arm_l={'rx': 30}),
                         K(0.6, root={'y': -1}, body={'rx': 4})], ease='out_quad')
clip('error_land_flat', 1.4, [K(0, root={'rx': -25, 'y': -2}, arm_r={'rz': -60}, arm_l={'rz': 60}),
                              K(0.18, root=lying({'y': -9}), arm_r={'rx': 10, 'rz': -70}, arm_l={'rx': 10, 'rz': 70}, leg_r={'rx': 8}, leg_l={'rx': 4}),
                              K(0.5, root=lying({'y': -11}), arm_r={'rx': 4, 'rz': -50}, arm_l={'rx': 4, 'rz': 50}),
                              K(1.4, root=lying(), arm_r={'rz': -35}, arm_l={'rz': 35})], ease='out_quad')
# ---------------- exploration / reactions
clip('error_inspect', 2.4, [K(0), K(0.6, body={'rx': 14}, head={'rx': 24, 'ry': -8}, arm_r={'rx': 30, 'rz': -8}),
                            K(1.5, body={'rx': 16}, head={'rx': 28, 'ry': 8}, arm_r={'rx': 38}), K(2.4)])
clip('error_reach', 1.6, [K(0), K(0.5, body={'rx': 16}, head={'rx': 14}, arm_r={'rx': 105, 'rz': -6}, leg_r={'rx': 10}),
                          K(0.9, body={'rx': 18}, arm_r={'rx': 110}), K(1.6, body={'rx': 2}, arm_r={'rx': 30})])
clip('error_weapon_draw', 1.0, [K(0, arm_r={'rx': 20}), K(0.35, body={'ry': 18, 'rx': -6}, arm_r={'rx': 160, 'rz': -12}, arm_l={'rx': 30}),
                                K(1.0, body={'ry': 10}, arm_r={'rx': 75}, arm_l={'rx': 55}, root={'y': -2}, leg_r={'rx': 14}, leg_l={'rx': -10})], ease='out_quad')
clip('error_shock', 1.2, [K(0), K(0.15, root={'y': -1}, body={'rx': -14}, head={'rx': -8}, arm_r={'rx': 25, 'rz': -38}, arm_l={'rx': 25, 'rz': 38}, leg_r={'rx': -12}, leg_l={'rx': 12}),
                          K(1.2, root={'y': -1.5}, body={'rx': -10}, head={'rx': -4}, arm_r={'rx': 20, 'rz': -34}, arm_l={'rx': 20, 'rz': 34}, leg_r={'rx': -10}, leg_l={'rx': 10})], ease='out_quad')
clip('error_hit', 0.45, [K(0), K(0.1, body={'rx': -22}, head={'rx': -28}, arm_r={'rx': 15, 'rz': -35}, arm_l={'rx': 15, 'rz': 35}, leg_r={'rx': -8}), K(0.45, body={'rx': -4}, head={'rx': -4})], ease='out_quad')
clip('error_knockback', 0.9, [K(0, body={'rx': -10}), K(0.15, root={'rx': -30, 'y': -1}, body={'rx': -10}, head={'rx': -22}, arm_r={'rx': 20, 'rz': -55}, arm_l={'rx': 20, 'rz': 55}, leg_r={'rx': 12}, leg_l={'rx': -6}),
                              K(0.9, root={'rx': -14, 'y': -2}, body={'rx': 6}, arm_r={'rx': 10, 'rz': -30}, arm_l={'rx': 10, 'rz': 30}, leg_r={'rx': -14}, leg_l={'rx': 14})], ease='out_quad')
clip('error_launch_fly', 1.2, [K(0, root={'rx': -78, 'y': -2}, head={'rx': -20}, arm_r={'rx': 10, 'rz': -85}, arm_l={'rx': 10, 'rz': 85}, leg_r={'rx': 12}, leg_l={'rx': 4}),
                               K(0.6, root={'rx': -70, 'y': -2}, head={'rx': -14}, arm_r={'rx': 20, 'rz': -78}, arm_l={'rx': 20, 'rz': 78}, leg_r={'rx': 4}, leg_l={'rx': 12}),
                               K(1.2, root={'rx': -78, 'y': -2}, head={'rx': -20}, arm_r={'rx': 10, 'rz': -85}, arm_l={'rx': 10, 'rz': 85}, leg_r={'rx': 12}, leg_l={'rx': 4})], loop=True)
clip('error_recover', 1.4, [K(0, root={'y': -5}, body={'rx': 32}, head={'rx': 22}, leg_r={'rx': 30}, leg_l={'rx': 24}, arm_r={'rx': 12}, arm_l={'rx': 12}),
                            K(0.6, root={'y': -5.5}, body={'rx': 36}, head={'rx': 18}, leg_r={'rx': 32}, leg_l={'rx': 26}),
                            K(1.4, root={'y': -1}, body={'rx': 6}, head={'rx': 0}, arm_r={'rx': 20}, arm_l={'rx': 20})])
# ---------------- lying / getting up / kneeling
clip('error_get_up', 2.0, [K(0, root=lying(), arm_r={'rz': -35}, arm_l={'rz': 35}),
                           K(0.5, root={'rx': -50, 'y': -10}, body={'rx': 20}, arm_r={'rx': -20, 'rz': -20}, arm_l={'rx': -20, 'rz': 20}, leg_r={'rx': 40}, leg_l={'rx': 55}),
                           K(1.0, root={'rx': -10, 'y': -8}, body={'rx': 35}, arm_r={'rx': 20}, arm_l={'rx': 30}, leg_r={'rx': 80}, leg_l={'rx': 95}),
                           K(1.5, root={'y': -5}, body={'rx': 24}, head={'rx': 12}, leg_r={'rx': 35}, leg_l={'rx': 35}),
                           K(2.0, root={'y': -1}, body={'rx': 6}, arm_r={'rx': 14}, arm_l={'rx': 14})])
clip('error_kneel', 2.4, [K(0, root={'y': -6}, body={'rx': 20}, head={'rx': 20}, leg_r={'rx': 88}, leg_l={'rx': -64}, arm_r={'rx': 40}, arm_l={'rx': 28}),
                          K(1.2, root={'y': -6.4}, body={'rx': 24}, head={'rx': 24}, leg_r={'rx': 88}, leg_l={'rx': -64}, arm_r={'rx': 44}, arm_l={'rx': 30}),
                          K(2.4, root={'y': -6}, body={'rx': 20}, head={'rx': 20}, leg_r={'rx': 88}, leg_l={'rx': -64}, arm_r={'rx': 40}, arm_l={'rx': 28})], loop=True)
clip('error_crater_lie', 4.0, [K(0, root=lying(), arm_r={'rz': -35}, arm_l={'rz': 35}), K(2.0, root=lying({'rx': -89}), body={'rx': 1.5}, head={'rx': 2}, arm_r={'rz': -36}, arm_l={'rz': 36}),
                               K(4.0, root=lying(), arm_r={'rz': -35}, arm_l={'rz': 35})], loop=True)
clip('error_struggle', 3.0, [K(0, root=lying(), arm_r={'rz': -35}, arm_l={'rz': 35}),
                             K(0.7, root=lying(), head={'rx': 18}, body={'rx': 8}, arm_r={'rx': 70, 'rz': -20}, arm_l={'rx': 20, 'rz': 30}),
                             K(1.1, root=lying(), head={'rx': 10}, body={'rx': 4}, arm_r={'rx': 35, 'rz': -30}, arm_l={'rz': 30}),
                             K(1.8, root=lying(), head={'rx': 22}, body={'rx': 10}, arm_r={'rx': 85, 'rz': -15}, arm_l={'rx': 30, 'rz': 25}, leg_r={'rx': 14}),
                             K(2.4, root=lying(), head={'rx': 8}, arm_r={'rx': 20, 'rz': -34}, arm_l={'rz': 32}),
                             K(3.0, root=lying(), arm_r={'rz': -35}, arm_l={'rz': 35})])
clip('error_look_at_hand', 4.0, [K(0, root=lying(), arm_r={'rz': -35}, arm_l={'rz': 35}),
                                 K(1.0, root=lying(), head={'rx': 28, 'ry': -10}, arm_r={'rx': 150, 'rz': -8}, arm_l={'rz': 35}),
                                 K(2.4, root=lying(), head={'rx': 30, 'ry': -8}, arm_r={'rx': 155, 'rz': -6}, arm_l={'rz': 35}),
                                 K(3.2, root=lying(), head={'rx': 14}, arm_r={'rx': 140, 'rz': -20}, arm_l={'rz': 35}),
                                 K(4.0, root=lying(), head={'rx': 4}, arm_r={'rx': 20, 'rz': -35}, arm_l={'rz': 35})])
# ---------------- unarmed combat
clip('error_punch_right', 0.5, [K(0, body={'ry': -8}, arm_r={'rx': 75}, arm_l={'rx': 65}),
                                K(0.12, body={'ry': -20, 'rx': 6}, arm_r={'rx': -30}, arm_l={'rx': 80}, leg_r={'rx': 18}, leg_l={'rx': -20}),
                                K(0.22, root={'y': -3}, body={'ry': 28, 'rx': 14}, arm_r={'rx': 96}, arm_l={'rx': 90, 'rz': 15}, leg_r={'rx': 28}, leg_l={'rx': -26}),
                                K(0.5, body={'ry': 6}, arm_r={'rx': 75}, arm_l={'rx': 65}, leg_r={'rx': 12}, leg_l={'rx': -10})], ease='out_quad')
clip('error_punch_left', 0.5, [K(0, body={'ry': 8}, arm_r={'rx': 65}, arm_l={'rx': 75}),
                               K(0.12, body={'ry': 20, 'rx': 6}, arm_l={'rx': -30}, arm_r={'rx': 80}, leg_r={'rx': -20}, leg_l={'rx': 18}),
                               K(0.22, root={'y': -3}, body={'ry': -28, 'rx': 14}, arm_l={'rx': 96}, arm_r={'rx': 90, 'rz': -15}, leg_r={'rx': -26}, leg_l={'rx': 28}),
                               K(0.5, body={'ry': -6}, arm_l={'rx': 75}, arm_r={'rx': 65}, leg_r={'rx': -10}, leg_l={'rx': 12})], ease='out_quad')
clip('error_uppercut', 0.7, [K(0, root={'y': -3}, body={'rx': 10}, arm_r={'rx': 70}, arm_l={'rx': 60}),
                             K(0.2, root={'y': -8}, body={'rx': 24, 'ry': -14}, arm_r={'rx': -25}, leg_r={'rx': 50}, leg_l={'rx': 40}),
                             K(0.34, root={'y': 1}, body={'rx': -12, 'ry': 22}, head={'rx': -12}, arm_r={'rx': 165}, arm_l={'rx': 70}, leg_r={'rx': 8}, leg_l={'rx': -8}),
                             K(0.7, root={'y': -3}, body={'rx': 10}, arm_r={'rx': 80}, arm_l={'rx': 60})], ease='out_quad')
clip('error_kick', 0.8, [K(0, root={'y': -3}, body={'rx': 8}, leg_r={'rx': 20}, leg_l={'rx': -18}, arm_r={'rx': 70}, arm_l={'rx': 60}),
                         K(0.22, body={'rx': -6, 'ry': -10}, leg_r={'rx': -45}, leg_l={'rx': 4}, arm_r={'rx': 50, 'rz': -40}, arm_l={'rx': 40, 'rz': 40}),
                         K(0.38, root={'y': -1}, body={'rx': -22, 'ry': 12}, head={'rx': 6}, leg_r={'rx': 104}, leg_l={'rx': -4}, arm_r={'rx': 20, 'rz': -62}, arm_l={'rx': 20, 'rz': 62}),
                         K(0.8, root={'y': -3}, body={'rx': 8}, leg_r={'rx': 20}, leg_l={'rx': -18}, arm_r={'rx': 70}, arm_l={'rx': 60})], ease='out_quad')
clip('error_spin_kick', 1.0, [K(0, root={'y': -4}, body={'rx': 8}, arm_r={'rx': 70}, arm_l={'rx': 60}, leg_r={'rx': 20}, leg_l={'rx': -18}),
                              K(0.25, root={'y': -5, 'ry': -90}, body={'rx': 10}, leg_r={'rx': 10}, leg_l={'rx': -30}, arm_r={'rx': 30, 'rz': -50}, arm_l={'rx': 30, 'rz': 50}),
                              K(0.5, root={'y': 2, 'ry': -250}, body={'rx': -16}, leg_r={'rx': 98}, leg_l={'rx': 0}, arm_r={'rx': 15, 'rz': -70}, arm_l={'rx': 15, 'rz': 70}),
                              K(0.75, root={'y': -1, 'ry': -360}, body={'rx': 6}, leg_r={'rx': 30}, leg_l={'rx': -10}, arm_r={'rx': 60, 'rz': -30}, arm_l={'rx': 50, 'rz': 30}),
                              K(1.0, root={'y': -3, 'ry': -360}, body={'rx': 8}, arm_r={'rx': 70}, arm_l={'rx': 60}, leg_r={'rx': 20}, leg_l={'rx': -18})], ease='in_out_quad')
clip('error_block', 0.8, [K(0), K(0.12, root={'y': -2}, body={'rx': 10}, head={'rx': 12}, arm_r={'rx': 112, 'rz': 28}, arm_l={'rx': 112, 'rz': -28}, leg_r={'rx': 18}, leg_l={'rx': -14}),
                          K(0.8, root={'y': -2}, body={'rx': 10}, head={'rx': 12}, arm_r={'rx': 112, 'rz': 28}, arm_l={'rx': 112, 'rz': -28}, leg_r={'rx': 18}, leg_l={'rx': -14})], ease='out_quad')
clip('error_dodge', 0.5, [K(0, root={'y': -3}, body={'rx': 8}), K(0.14, root={'y': -5, 'rz': 16}, body={'rx': 14, 'rz': -10}, head={'rz': -8}, leg_r={'rx': 30}, leg_l={'rx': -24}, arm_r={'rx': 40, 'rz': -40}, arm_l={'rx': 40, 'rz': 40}),
                          K(0.5, root={'y': -3}, body={'rx': 8})], ease='out_quad')
clip('error_counter', 0.6, [K(0, root={'y': -3}, body={'rx': 10}, arm_r={'rx': 78}, arm_l={'rx': 68}),
                            K(0.1, root={'y': -4}, body={'rx': 12, 'ry': -16}, arm_l={'rx': 110}, arm_r={'rx': 40}),
                            K(0.24, root={'y': -3}, body={'rx': 12, 'ry': 30}, arm_r={'rx': 100}, arm_l={'rx': 80}, leg_r={'rx': 28}, leg_l={'rx': -24}),
                            K(0.6, root={'y': -3}, body={'rx': 10, 'ry': 8}, arm_r={'rx': 78}, arm_l={'rx': 68})], ease='out_quad')
def _charge(t, y, b, h, a, rz):
    return K(t, root={'y': y}, body={'rx': b}, head={'rx': h}, arm_r={'rx': a, 'rz': -rz}, arm_l={'rx': a, 'rz': rz}, leg_r={'rx': 18}, leg_l={'rx': -14})
clip('error_charge_energy', 2.0, [_charge(0, -4, 10, -22, 30, 62), _charge(0.5, -4.6, 12, -26, 38, 70), _charge(1.0, -4, 10, -22, 30, 62),
                                  _charge(1.5, -4.6, 12, -26, 38, 70), _charge(2.0, -4, 10, -22, 30, 62)], loop=True)
clip('error_cast', 0.9, [K(0, root={'y': -3}, body={'rx': 8}, arm_r={'rx': 40}, arm_l={'rx': 30}), K(0.25, root={'y': -4}, body={'rx': 12, 'ry': -14}, arm_r={'rx': 30, 'rz': -20}, arm_l={'rx': 60}),
                         K(0.45, root={'y': -3}, body={'rx': 10, 'ry': 18}, arm_r={'rx': 98}, arm_l={'rx': 70}, leg_r={'rx': 24}, leg_l={'rx': -20}), K(0.9, root={'y': -3}, body={'rx': 8}, arm_r={'rx': 80}, arm_l={'rx': 60})], ease='out_quad')
# ---------------- NULL//REQUIEM scythe (two-handed; the weapon display follows arm_r)
HOLD = dict(arm_r={'rx': 62, 'rz': -4}, arm_l={'rx': 44, 'rz': 6})
clip('error_scythe_idle', 3.0, [K(0, root={'y': -3}, body={'rx': 8, 'ry': 10}, head={'rx': -4}, leg_r={'rx': 20}, leg_l={'rx': -16}, **HOLD),
                                K(1.5, root={'y': -3.5}, body={'rx': 10, 'ry': 8}, head={'rx': -4}, leg_r={'rx': 22}, leg_l={'rx': -18}, arm_r={'rx': 66, 'rz': -4}, arm_l={'rx': 48, 'rz': 6}),
                                K(3.0, root={'y': -3}, body={'rx': 8, 'ry': 10}, head={'rx': -4}, leg_r={'rx': 20}, leg_l={'rx': -16}, **HOLD)], loop=True)
clip('error_scythe_slash_h', 0.8, [K(0, root={'y': -3}, body={'rx': 8, 'ry': 10}, leg_r={'rx': 20}, leg_l={'rx': -16}, **HOLD),
                                   K(0.2, root={'y': -4}, body={'rx': 6, 'ry': -58}, head={'ry': 20}, arm_r={'rx': 80, 'rz': -30}, arm_l={'rx': 70, 'rz': -20}, leg_r={'rx': 26}, leg_l={'rx': -24}),
                                   K(0.38, root={'y': -4}, body={'rx': 12, 'ry': 78}, head={'ry': -26}, arm_r={'rx': 88, 'rz': 34}, arm_l={'rx': 84, 'rz': 40}, leg_r={'rx': 38}, leg_l={'rx': -30}),
                                   K(0.8, root={'y': -3}, body={'rx': 8, 'ry': 12}, leg_r={'rx': 20}, leg_l={'rx': -16}, **HOLD)], ease='out_quad')
clip('error_scythe_slash_v', 0.9, [K(0, root={'y': -3}, body={'rx': 8, 'ry': 10}, leg_r={'rx': 20}, leg_l={'rx': -16}, **HOLD),
                                   K(0.26, root={'y': -1}, body={'rx': -14}, head={'rx': -12}, arm_r={'rx': 172, 'rz': -8}, arm_l={'rx': 168, 'rz': 8}, leg_r={'rx': 12}, leg_l={'rx': -6}),
                                   K(0.42, root={'y': -6}, body={'rx': 30}, head={'rx': 14}, arm_r={'rx': 42}, arm_l={'rx': 36}, leg_r={'rx': 46}, leg_l={'rx': -22}),
                                   K(0.9, root={'y': -3}, body={'rx': 8, 'ry': 10}, leg_r={'rx': 20}, leg_l={'rx': -16}, **HOLD)], ease='out_quad')
clip('error_scythe_rising', 0.8, [K(0, root={'y': -3}, body={'rx': 8, 'ry': 10}, leg_r={'rx': 20}, leg_l={'rx': -16}, **HOLD),
                                  K(0.2, root={'y': -8}, body={'rx': 26, 'ry': -18}, arm_r={'rx': -12, 'rz': -10}, arm_l={'rx': -8, 'rz': 10}, leg_r={'rx': 50}, leg_l={'rx': 38}),
                                  K(0.38, root={'y': 1}, body={'rx': -14, 'ry': 24}, head={'rx': -14}, arm_r={'rx': 152}, arm_l={'rx': 146}, leg_r={'rx': 6}, leg_l={'rx': -6}),
                                  K(0.8, root={'y': -3}, body={'rx': 8, 'ry': 10}, leg_r={'rx': 20}, leg_l={'rx': -16}, **HOLD)], ease='out_quad')
clip('error_scythe_thrust', 0.7, [K(0, root={'y': -3}, body={'rx': 8, 'ry': 10}, leg_r={'rx': 20}, leg_l={'rx': -16}, **HOLD),
                                  K(0.2, root={'y': -4}, body={'rx': 8, 'ry': -26}, arm_r={'rx': 30}, arm_l={'rx': 20}, leg_r={'rx': 8}, leg_l={'rx': -30}),
                                  K(0.34, root={'y': -5}, body={'rx': 24, 'ry': 30}, head={'rx': 8}, arm_r={'rx': 96}, arm_l={'rx': 92}, leg_r={'rx': 46}, leg_l={'rx': -34}),
                                  K(0.7, root={'y': -3}, body={'rx': 8, 'ry': 10}, leg_r={'rx': 20}, leg_l={'rx': -16}, **HOLD)], ease='out_quad')
clip('error_scythe_spin', 1.5, [K(0, root={'y': -3}, body={'rx': 8}, **HOLD),
                                K(0.4, root={'y': -2, 'ry': -270}, body={'rx': 6}, arm_r={'rx': 82, 'rz': -26}, arm_l={'rx': 76, 'rz': -18}, leg_r={'rx': 12}, leg_l={'rx': -12}),
                                K(0.9, root={'y': -2, 'ry': -720}, body={'rx': 6}, arm_r={'rx': 86, 'rz': -30}, arm_l={'rx': 80, 'rz': -20}),
                                K(1.5, root={'y': -3, 'ry': -720}, body={'rx': 8, 'ry': 10}, **HOLD)], ease='in_out_quad')
clip('error_scythe_whirlwind', 2.2, [K(0, root={'y': -4}, body={'rx': 8}, **HOLD),
                                     K(0.5, root={'y': -2, 'ry': -360, 'rz': 8}, body={'rx': 8}, arm_r={'rx': 84, 'rz': -34}, arm_l={'rx': 80, 'rz': -24}),
                                     K(1.2, root={'y': 1, 'ry': -900, 'rz': 12}, body={'rx': 10}, arm_r={'rx': 88, 'rz': -40}, arm_l={'rx': 84, 'rz': -30}, leg_r={'rx': 28}, leg_l={'rx': -14}),
                                     K(1.8, root={'y': -2, 'ry': -1080, 'rz': 4}, body={'rx': 8}, arm_r={'rx': 80, 'rz': -30}, arm_l={'rx': 74, 'rz': -20}),
                                     K(2.2, root={'y': -3, 'ry': -1080}, body={'rx': 8, 'ry': 10}, **HOLD)], ease='in_out_quad')
clip('error_scythe_aerial', 0.9, [K(0, root={'y': 0, 'rx': 6}, body={'rx': 4}, arm_r={'rx': 150}, arm_l={'rx': 142}, leg_r={'rx': 30}, leg_l={'rx': 14}),
                                  K(0.3, root={'y': 0, 'rx': 28}, body={'rx': 10, 'ry': 30}, arm_r={'rx': 170}, arm_l={'rx': 165}, leg_r={'rx': 40}, leg_l={'rx': 24}),
                                  K(0.5, root={'y': 0, 'rx': 38}, body={'rx': 16, 'ry': -40}, arm_r={'rx': 50}, arm_l={'rx': 44}, leg_r={'rx': 18}, leg_l={'rx': 34}),
                                  K(0.9, root={'y': 0, 'rx': 12}, body={'rx': 6}, arm_r={'rx': 70}, arm_l={'rx': 60}, leg_r={'rx': 24}, leg_l={'rx': 10})], ease='out_quad')
clip('error_scythe_raise_counter', 1.2, [K(0, root={'y': -3}, body={'rx': 8, 'ry': 10}, **HOLD),
                                         K(0.2, root={'y': -6}, body={'rx': -8}, head={'rx': -22}, arm_r={'rx': 165, 'rz': -8}, arm_l={'rx': 160, 'rz': 8}, leg_r={'rx': 34}, leg_l={'rx': -30}),
                                         K(0.7, root={'y': -7}, body={'rx': -12}, head={'rx': -26}, arm_r={'rx': 168, 'rz': -10}, arm_l={'rx': 162, 'rz': 10}, leg_r={'rx': 38}, leg_l={'rx': -34}),
                                         K(1.2, root={'y': -7.5}, body={'rx': -14}, head={'rx': -28}, arm_r={'rx': 170, 'rz': -12}, arm_l={'rx': 164, 'rz': 12}, leg_r={'rx': 40}, leg_l={'rx': -36})], ease='out_quad')

out = os.path.join(os.path.dirname(__file__), '..', 'src', 'main', 'resources', 'rigs', 'error_clips.yml')
os.makedirs(os.path.dirname(out), exist_ok=True)
with open(out, 'w') as f:
    f.write('# GENERATED by tools/gen_error_clips.py - edit the generator, not this file.\n')
    yaml.safe_dump({'clips': C}, f, default_flow_style=None, sort_keys=False, width=200)
print('wrote', len(C), 'clips ->', out)
