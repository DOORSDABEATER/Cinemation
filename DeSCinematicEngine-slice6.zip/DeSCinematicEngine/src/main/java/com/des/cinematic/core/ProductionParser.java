package com.des.cinematic.core;

import java.util.*;

/**
 * Turns raw YAML-derived maps into an immutable {@link Spec.Production}. Never throws on bad data:
 * every problem becomes an {@link Issue} so that "validate" can report all of them at once.
 */
public final class ProductionParser {
    public record Result(Spec.Production production, List<Issue> issues) {
        public boolean ok() { return production != null && issues.stream().noneMatch(i -> i.severity() == Issue.Severity.ERROR); }
    }

    @SuppressWarnings("unchecked")
    private static Map<String, Object> map(Object o) { return o instanceof Map<?, ?> m ? (Map<String, Object>) m : Map.of(); }
    private static List<?> list(Object o) { return o instanceof List<?> l ? l : List.of(); }

    public static Result parse(Map<String, Object> prod, List<Map<String, Object>> sceneMaps) {
        List<Issue> issues = new ArrayList<>();
        Params p = new Params(prod);
        String id = p.str("id", null);
        if (id == null || id.isBlank()) { issues.add(Issue.error("production.yml", "missing 'id'")); return new Result(null, issues); }
        String w = id;

        Vec3 origin = p.vec("origin");
        if (origin == null) { origin = Vec3.ZERO; issues.add(Issue.warn(w, "no valid 'origin' [x,y,z]; use /descinematic setorigin " + id)); }
        String world = p.str("world", null);
        if (world == null) issues.add(Issue.error(w, "missing 'world'"));

        List<String> actors = p.strList("actors");
        if (actors.isEmpty()) issues.add(Issue.error(w, "no 'actors' declared"));
        List<String> weapons = p.strList("weapons");
        Set<String> sounds = new LinkedHashSet<>(map(prod.get("sounds")).keySet());
        Set<String> dialogue = new LinkedHashSet<>(map(prod.get("dialogue")).keySet());

        List<Spec.Region> regions = new ArrayList<>();
        for (Map.Entry<String, Object> e : map(prod.get("regions")).entrySet()) {
            Params rp = new Params(map(e.getValue()));
            Vec3 a = rp.vec("min"), b = rp.vec("max");
            if (a == null || b == null) { issues.add(Issue.error(w + ".regions." + e.getKey(), "needs 'min' and 'max' as [x,y,z]")); continue; }
            Vec3 lo = new Vec3(Math.min(a.x(), b.x()), Math.min(a.y(), b.y()), Math.min(a.z(), b.z()));
            Vec3 hi = new Vec3(Math.max(a.x(), b.x()), Math.max(a.y(), b.y()), Math.max(a.z(), b.z()));
            regions.add(new Spec.Region(e.getKey(), lo, hi, rp.bool("destructible", false)));
        }

        Map<String, Object> macros = map(prod.get("macros"));
        List<Spec.Scene> scenes = new ArrayList<>();
        Set<String> sceneIds = new HashSet<>();
        for (Map<String, Object> sm : sceneMaps) {
            Params sp = new Params(sm);
            String sid = sp.str("id", null);
            if (sid == null) { issues.add(Issue.error(w, "a scene file has no 'id'")); continue; }
            if (!sceneIds.add(sid)) { issues.add(Issue.error(w + "/" + sid, "duplicate scene id")); continue; }
            List<Spec.Action> actions = new ArrayList<>();
            int idx = 0;
            List<Object> expanded = new ArrayList<>();
            for (Object ao : list(sm.get("actions"))) {
                Map<String, Object> call = map(ao); Object an = call.get("action");
                if (an != null && macros.get(String.valueOf(an)) != null) expandMacro(String.valueOf(an), call, map(macros.get(String.valueOf(an))), expanded, issues, w + "/" + sid);
                else expanded.add(ao);
            }
            for (Object ao : expanded) {
                int index = idx++;
                Map<String, Object> am = map(ao);
                Params ap = new Params(am);
                String name = ap.str("action", null);
                String where = w + "/" + sid + "#" + index;
                if (name == null) { issues.add(Issue.error(where, "action entry has no 'action'")); continue; }
                int tick;
                if (ap.has("tick")) tick = ap.integer("tick", 0);
                else if (ap.has("time")) tick = ap.ticks("time", 0);
                else { issues.add(Issue.error(where, "action '" + name + "' has neither 'time' (seconds) nor 'tick'")); continue; }
                if (tick < 0) { issues.add(Issue.error(where, "negative time")); continue; }
                Optional<ActionCatalog.Def> def = ActionCatalog.get(name);
                int dur = ap.has("duration") ? ap.ticks("duration", 0) : def.map(ActionCatalog.Def::defaultTicks).orElse(0);
                boolean crit = ap.has("critical") ? ap.bool("critical", true) : def.map(ActionCatalog.Def::critical).orElse(true);
                actions.add(new Spec.Action(id, sid, index, tick, ap.str("actor", null), name, ap, dur, crit));
            }
            // Deterministic order: by tick, then by position in file.
            actions.sort(Comparator.comparingInt(Spec.Action::tick).thenComparingInt(Spec.Action::index));
            scenes.add(new Spec.Scene(sid, sp.str("name", sid), sp.ticks("duration", 0), List.copyOf(actions)));
        }
        if (scenes.isEmpty()) issues.add(Issue.error(w, "production has no scenes"));

        Spec.Production out = new Spec.Production(id, p.str("display_name", id), p.str("subtitle", ""), world == null ? "" : world, origin,
                List.copyOf(actors), List.copyOf(weapons), Set.copyOf(sounds), Set.copyOf(dialogue), List.copyOf(regions),
                Map.copyOf(map(prod.get("restoration"))), List.copyOf(scenes));
        return new Result(out, issues);
    }

    /**
     * A macro is a named list of timed actions with $parameters. A call "{time: 5, action: slam, at: [..]}" becomes the macro's actions at
     * time + t. Values that are exactly "$name" take the call's value (or the macro default). Expansion is deterministic and happens
     * before validation, so every expanded action is validated like a hand-written one.
     */
    private static void expandMacro(String name, Map<String, Object> call, Map<String, Object> macro, List<Object> out, List<Issue> issues, String where) {
        Params cp = new Params(call);
        if (!cp.has("time") && !cp.has("tick")) { issues.add(Issue.error(where, "macro '" + name + "' call has no 'time'")); return; }
        double base = cp.has("tick") ? cp.dbl("tick", 0) / 20.0 : cp.dbl("time", 0);
        Map<String, Object> defaults = map(macro.get("defaults"));
        for (Object to : list(macro.get("actions"))) {
            Map<String, Object> t = map(to); Map<String, Object> a = new LinkedHashMap<>();
            for (Map.Entry<String, Object> e : t.entrySet()) {
                if (e.getKey().equals("t")) continue;
                Object v = subst(e.getValue(), call, defaults, name, issues, where); if (v != NONE) a.put(e.getKey(), v);
            }
            a.put("time", base + new Params(t).dbl("t", 0));
            out.add(a);
        }
    }
    private static final Object NONE = new Object();
    private static Object subst(Object v, Map<String, Object> call, Map<String, Object> defaults, String macro, List<Issue> issues, String where) {
        if (v instanceof String s && s.startsWith("$")) {
            String k = s.substring(1);
            if (call.get(k) != null) return call.get(k);
            if (defaults.get(k) != null) return defaults.get(k);
            issues.add(Issue.error(where, "macro '" + macro + "' needs parameter '" + k + "'")); return NONE;
        }
        if (v instanceof List<?> l) { List<Object> r = new ArrayList<>(); for (Object e : l) { Object x = subst(e, call, defaults, macro, issues, where); if (x != NONE) r.add(x); } return r; }
        return v;
    }
}
