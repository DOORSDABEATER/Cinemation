package com.des.cinematic.paper;

import org.bukkit.Bukkit;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.block.data.BlockData;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;
import java.util.logging.Logger;

/**
 * Records the ORIGINAL block data of every block a production changes, persisted to recovery/<production>.journal so an
 * unfinished restoration is completed after a crash or restart. Only the first original of a position is kept.
 * Tile-entity blocks are never modified (see EnvironmentModule), so block data alone restores them exactly.
 */
final class BlockJournal {
    private final File file; private final Logger log; private final String productionId;
    private final LinkedHashMap<String, String> original = new LinkedHashMap<>();   // "world;x;y;z" -> blockdata string
    private BufferedWriter out; private int unflushed;
    private final Set<String> warnedWorlds = new HashSet<>();
    private Iterator<Map.Entry<String, String>> restoreIt; private List<Map.Entry<String, String>> restoreList;

    BlockJournal(File dir, String productionId, Logger log) { this.file = new File(dir, productionId + ".journal"); this.productionId = productionId; this.log = log; dir.mkdirs(); }

    static String key(World w, int x, int y, int z) { return w.getName() + ";" + x + ";" + y + ";" + z; }
    int size() { return original.size(); }
    boolean has(String key) { return original.containsKey(key); }

    /** Record the original state (once). Called BEFORE the block is changed. */
    void record(String key, BlockData data) {
        if (original.containsKey(key)) return;
        String s = data.getAsString();
        original.put(key, s);
        try {
            if (out == null) out = Files.newBufferedWriter(file.toPath(), StandardCharsets.UTF_8, StandardOpenOption.CREATE, StandardOpenOption.APPEND);
            out.write(key + "|" + s); out.newLine();
            if (++unflushed >= 256) flush();
        } catch (IOException e) { log.severe("journal write failed for " + productionId + ": " + e.getMessage() + " (restoration after a crash would be incomplete)"); }
    }
    void flush() { try { if (out != null) { out.flush(); unflushed = 0; } } catch (IOException e) { log.severe("journal flush failed: " + e.getMessage()); } }

    /** Loads a journal left on disk by an earlier run. Returns true if there is something to restore. */
    boolean loadFromDisk() {
        if (!file.isFile()) return false;
        try (BufferedReader r = Files.newBufferedReader(file.toPath(), StandardCharsets.UTF_8)) {
            String line;
            while ((line = r.readLine()) != null) { int i = line.indexOf('|'); if (i > 0) original.putIfAbsent(line.substring(0, i), line.substring(i + 1)); }
        } catch (IOException e) { log.severe("cannot read journal " + file + ": " + e.getMessage()); }
        return !original.isEmpty();
    }

    /** Begin restoring newest-first. */
    void beginRestore() { flush(); closeWriter(); restoreList = new ArrayList<>(original.entrySet()); Collections.reverse(restoreList); restoreIt = restoreList.iterator(); }
    boolean restoring() { return restoreIt != null; }

    /** Restore up to maxBlocks. Returns true when finished (journal deleted). Blocks in unloaded chunks are loaded (bounded by maxChunkLoads). */
    boolean restoreBatch(int maxBlocks, int maxChunkLoads) {
        if (restoreIt == null) return true;
        int done = 0, loads = 0;
        List<Map.Entry<String, String>> deferred = new ArrayList<>();
        while (restoreIt.hasNext() && done < maxBlocks) {
            Map.Entry<String, String> e = restoreIt.next();
            String[] k = e.getKey().split(";");
            World w = Bukkit.getWorld(k[0]);
            if (w == null) { if (warnedWorlds.add(k[0])) log.warning("journal: world '" + k[0] + "' is not loaded; its blocks stay journalled until it is"); deferred.add(e); continue; }
            int x = Integer.parseInt(k[1]), y = Integer.parseInt(k[2]), z = Integer.parseInt(k[3]);
            if (!w.isChunkLoaded(x >> 4, z >> 4)) { if (loads >= maxChunkLoads) { deferred.add(e); continue; } w.loadChunk(x >> 4, z >> 4, true); loads++; }
            try { w.getBlockAt(x, y, z).setBlockData(Bukkit.createBlockData(e.getValue()), false); } catch (IllegalArgumentException ex) { log.severe("journal: bad blockdata '" + e.getValue() + "' at " + e.getKey()); }
            done++;
        }
        if (!deferred.isEmpty()) {   // retry next tick: chain deferred entries in front
            List<Map.Entry<String, String>> rest = new ArrayList<>(deferred); restoreIt.forEachRemaining(rest::add); restoreIt = rest.iterator();
            if (rest.size() == deferred.size() && done == 0 && loads == 0 && deferred.stream().allMatch(en -> Bukkit.getWorld(en.getKey().split(";")[0]) == null)) return false;
        }
        if (!restoreIt.hasNext()) { finishRestore(); return true; }
        return false;
    }
    int remaining() { return original.size(); }

    private void finishRestore() { restoreIt = null; restoreList = null; original.clear(); closeWriter(); try { Files.deleteIfExists(file.toPath()); } catch (IOException e) { log.warning("could not delete journal " + file + ": " + e.getMessage()); } }
    private void closeWriter() { try { if (out != null) { out.close(); out = null; } } catch (IOException ignored) { } }
    void discard() { restoreIt = null; restoreList = null; original.clear(); closeWriter(); try { Files.deleteIfExists(file.toPath()); } catch (IOException ignored) { } }
}
