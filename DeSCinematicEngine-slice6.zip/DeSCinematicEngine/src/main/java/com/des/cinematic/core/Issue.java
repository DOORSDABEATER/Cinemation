package com.des.cinematic.core;

public record Issue(Severity severity, String where, String message) {
    public enum Severity { ERROR, WARN, INFO }
    public static Issue error(String where, String msg) { return new Issue(Severity.ERROR, where, msg); }
    public static Issue warn(String where, String msg) { return new Issue(Severity.WARN, where, msg); }
    public static Issue info(String where, String msg) { return new Issue(Severity.INFO, where, msg); }
    @Override public String toString() { return "[" + severity + "] " + where + ": " + message; }
}
