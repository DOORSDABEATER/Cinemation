package com.des.cinematic.core;

import java.util.*;

/** Typed, forgiving accessor over a raw YAML-derived map. */
public final class Params {
    private final Map<String, Object> m;
    public Params(Map<String, Object> m) { this.m = m == null ? Map.of() : m; }
    public Map<String, Object> raw() { return m; }
    public boolean has(String k) { return m.get(k) != null; }
    public String str(String k, String def) { Object o = m.get(k); return o == null ? def : o.toString(); }
    public double dbl(String k, double def) { Object o = m.get(k); return o instanceof Number n ? n.doubleValue() : tryParse(o, def); }
    public int integer(String k, int def) { return (int) Math.round(dbl(k, def)); }
    public boolean bool(String k, boolean def) { Object o = m.get(k); return o instanceof Boolean b ? b : o == null ? def : Boolean.parseBoolean(o.toString()); }
    /** A value expressed in seconds in the file, returned as ticks. */
    public int ticks(String k, int defTicks) { return has(k) ? (int) Math.round(dbl(k, 0) * 20.0) : defTicks; }
    public Ease ease(String k, Ease def) { return Ease.parse(m.get(k), def); }
    public Vec3 vec(String k) { return parseVec(m.get(k)); }
    /** Returns null if any waypoint is malformed. */
    public List<Vec3> path(String k) {
        Object o = m.get(k);
        if (!(o instanceof List<?> l)) return List.of();
        List<Vec3> out = new ArrayList<>();
        for (Object e : l) { Vec3 v = parseVec(e); if (v == null) return null; out.add(v); }
        return out;
    }
    public List<String> strList(String k) {
        Object o = m.get(k);
        if (o instanceof List<?> l) { List<String> r = new ArrayList<>(); for (Object e : l) r.add(String.valueOf(e)); return r; }
        return o == null ? List.of() : List.of(o.toString());
    }
    public static Vec3 parseVec(Object o) {
        if (o instanceof List<?> l && l.size() == 3 && l.stream().allMatch(e -> e instanceof Number))
            return new Vec3(((Number) l.get(0)).doubleValue(), ((Number) l.get(1)).doubleValue(), ((Number) l.get(2)).doubleValue());
        if (o instanceof Map<?, ?> mm && mm.get("x") instanceof Number x && mm.get("y") instanceof Number y && mm.get("z") instanceof Number z)
            return new Vec3(x.doubleValue(), y.doubleValue(), z.doubleValue());
        return null;
    }
    private static double tryParse(Object o, double def) { try { return o == null ? def : Double.parseDouble(o.toString()); } catch (NumberFormatException e) { return def; } }
}
