package com.des.cinematic.paper;

import com.des.cinematic.rig.*;
import org.bukkit.Location;

import java.util.Map;

/** ERROR: keyframed clips on the standard player rig. */
final class ClipBody implements ActorBody {
    private final ClipLibrary clips; private final Map<String, String> map; private final Animator animator = new Animator(); private final PlayerDisplayRig rig;
    ClipBody(ClipLibrary clips, Map<String, String> map, PlayerDisplayRig rig) { this.clips = clips; this.map = map; this.rig = rig; }

    PlayerDisplayRig rig() { return rig; }
    @Override public boolean play(String logical, int blend) {
        String id = map.get(logical);
        if (id == null) throw new IllegalArgumentException("no animation '" + logical + "' mapped for this actor");
        Clip c = clips.get(id).orElseThrow(() -> new IllegalStateException("animation '" + logical + "' -> clip '" + id + "' does not exist in the rig"));
        animator.play(c, blend);
        return c.loops();
    }
    @Override public boolean hasAnimation(String logical) { String id = map.get(logical); return id != null && clips.get(id).isPresent(); }
    @Override public void tick() { animator.tick(); }
    @Override public void render(Location feet, double yaw) { rig.render(feet, yaw, animator.pose()); }
    @Override public boolean animationFinished() { return animator.finished(); }
    @Override public String currentAnimation() { return animator.clipId(); }
    @Override public void remove() { rig.remove(); }
    @Override public boolean isValid() { return rig.isValid(); }
}
