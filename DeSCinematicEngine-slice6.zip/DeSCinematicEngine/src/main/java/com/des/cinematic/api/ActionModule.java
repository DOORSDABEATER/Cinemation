package com.des.cinematic.api;

import com.des.cinematic.core.ActionCatalog;
import com.des.cinematic.core.ActionHandler;
import com.des.cinematic.core.Spec;

import java.util.Set;

/**
 * A pluggable executor for one or more action categories (actors, combat, weapons, environment, audio...).
 * Other DeS plugins may register their own via {@link CinematicApi#registerModule}.
 * All methods are called on the main server thread.
 */
public interface ActionModule {
    String id();
    Set<ActionCatalog.Category> categories();
    default void productionStarted(ProductionContext ctx) {}
    ActionHandler.Outcome begin(Spec.Action action, ProductionContext ctx);
    default void tick(ProductionContext ctx, int sceneTick, int globalTick) {}
    default boolean busy() { return false; }
    default void sceneStarted(Spec.Scene scene) {}
    default void sceneEnded(Spec.Scene scene) {}
    default void pause() {}
    default void resume() {}
    /** Remove every temporary entity/effect. restoreWorld=true must also roll back block changes now. Idempotent. */
    default void cleanup(boolean restoreWorld) {}
    /** Return a reason to REFUSE starting this production (e.g. an earlier run is still being restored), or null. */
    default String preflight(String productionId) { return null; }
    /** Server is stopping: finish any critical work (e.g. world restoration) synchronously. */
    default void shutdown() {}
    /** /descinematic reset: discard any leftover state (journals, orphaned entities) for this production. */
    default void reset(String productionId) {}
    /** Extra static validation (e.g. missing model/animation assets). Default: nothing. */
    default java.util.List<com.des.cinematic.core.Issue> validate(com.des.cinematic.core.Spec.Production p,
            java.util.Map<String, java.util.Map<String, Object>> actorDefs, java.util.Map<String, java.util.Map<String, Object>> weaponDefs) { return java.util.List.of(); }
}
