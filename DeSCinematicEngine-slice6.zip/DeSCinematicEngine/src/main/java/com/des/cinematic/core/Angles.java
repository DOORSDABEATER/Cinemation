package com.des.cinematic.core;

/** Minecraft-convention yaw maths (yaw 0 = +Z/south, 90 = -X/west). */
public final class Angles {
    private Angles() {}
    public static double wrap(double deg) { deg %= 360.0; if (deg >= 180) deg -= 360; if (deg < -180) deg += 360; return deg; }
    public static double delta(double from, double to) { return wrap(to - from); }
    public static double lerp(double from, double to, double t) { return wrap(from + delta(from, to) * t); }
    public static double yawTo(Vec3 from, Vec3 to) {
        double dx = to.x() - from.x(), dz = to.z() - from.z();
        if (Math.abs(dx) < 1e-9 && Math.abs(dz) < 1e-9) return Double.NaN;
        return Math.toDegrees(Math.atan2(-dx, dz));
    }
    /** Rotate current toward target by at most maxStep degrees, along the shortest arc. */
    public static double turnToward(double current, double target, double maxStep) {
        double d = delta(current, target);
        if (Math.abs(d) <= maxStep) return wrap(target);
        return wrap(current + Math.copySign(maxStep, d));
    }
}
