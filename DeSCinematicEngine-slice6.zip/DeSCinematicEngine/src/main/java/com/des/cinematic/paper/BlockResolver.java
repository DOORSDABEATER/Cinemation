package com.des.cinematic.paper;

import com.des.cinematic.core.BlockCompat;
import org.bukkit.Bukkit;
import org.bukkit.block.data.BlockData;

import java.util.*;
import java.util.logging.Logger;

/** Resolves block strings against the RUNNING server (Bukkit.createBlockData is the authority) using the pure BlockCompat rules. */
final class BlockResolver {
    private final Logger log; private final Map<String, BlockCompat.Resolution> cache = new HashMap<>(); private final Set<String> logged = new HashSet<>();
    BlockResolver(Logger log) { this.log = log; }

    static boolean serverAccepts(String s) { try { Bukkit.createBlockData(s); return true; } catch (IllegalArgumentException e) { return false; } }

    BlockCompat.Resolution resolve(String requested, Map<String, List<String>> fallbacks) {
        String key = requested + "|" + (fallbacks == null ? "" : fallbacks);
        BlockCompat.Resolution r = cache.get(key);
        if (r == null) { r = BlockCompat.resolve(requested, fallbacks, BlockResolver::serverAccepts); cache.put(key, r); report(r); }
        return r;
    }
    /** @throws IllegalArgumentException (naming every spelling tried) when the server accepts none of them */
    BlockData data(String requested, Map<String, List<String>> fallbacks) {
        BlockCompat.Resolution r = resolve(requested, fallbacks);
        if (!r.ok()) throw new IllegalArgumentException("unknown block '" + requested + "' on this server (tried " + r.tried() + ")");
        return Bukkit.createBlockData(r.resolved());
    }
    private void report(BlockCompat.Resolution r) {
        if (r.kind() == BlockCompat.Kind.EXACT && r.resolved().equals(r.requested()) || !logged.add(r.requested())) return;
        switch (r.kind()) {
            case EXACT -> log.info("block compat: '" + r.requested() + "' accepted as '" + r.resolved() + "' (tried " + r.tried() + ")");
            case RENAMED -> log.info("block compat: '" + r.requested() + "' is not valid on this server; using renamed block '" + r.resolved() + "' (tried " + r.tried() + ")");
            case FALLBACK -> log.warning("block compat: '" + r.requested() + "' unavailable; using FALLBACK block '" + r.resolved() + "' (tried " + r.tried() + ")");
            case UNRESOLVED -> log.severe("block compat: '" + r.requested() + "' unavailable and no fallback worked (tried " + r.tried() + ")");
        }
    }
}
