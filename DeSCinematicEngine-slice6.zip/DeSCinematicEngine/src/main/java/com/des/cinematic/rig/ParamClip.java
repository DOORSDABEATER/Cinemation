package com.des.cinematic.rig;

import com.des.cinematic.core.Ease;
import com.des.cinematic.vael.P;

import java.util.*;

/** Keyframed animation over the rig's 28 pose parameters (see vael.P). Times in ticks. Authored in tools/gen_azrathiel_clips.py. */
public final class ParamClip {
    public record Key(double tick, float[] v) {}
    private final String id; private final double duration; private final boolean loop; private final Ease ease; private final List<Key> keys;

    public ParamClip(String id, double durationTicks, boolean loop, Ease ease, List<Key> keys) {
        if (keys.isEmpty()) throw new IllegalArgumentException("clip '" + id + "' has no keys");
        this.id = id; this.duration = Math.max(1, durationTicks); this.loop = loop; this.ease = ease;
        List<Key> k = new ArrayList<>(keys); k.sort(Comparator.comparingDouble(Key::tick)); this.keys = List.copyOf(k);
    }
    public String id() { return id; }
    public double duration() { return duration; }
    public boolean loops() { return loop; }
    public List<Key> keys() { return keys; }

    public float[] sample(double t) {
        float[] out = new float[P.COUNT];
        if (loop) t = ((t % duration) + duration) % duration; else t = Math.max(0, Math.min(duration, t));
        Key first = keys.get(0), last = keys.get(keys.size() - 1);
        if (!loop) { if (t <= first.tick()) return first.v().clone(); if (t >= last.tick()) return last.v().clone(); }
        Key a = null, b = null;
        for (Key k : keys) if (k.tick() <= t) a = k;
        for (int i = keys.size() - 1; i >= 0; i--) if (keys.get(i).tick() > t) b = keys.get(i);
        double at, bt;
        if (a == null) { a = last; at = last.tick() - duration; } else at = a.tick();
        if (b == null) { b = first; bt = first.tick() + duration; } else bt = b.tick();
        double f = bt - at < 1e-9 ? 1 : (t - at) / (bt - at); float e = (float) ease.apply(f);
        for (int i = 0; i < out.length; i++) out[i] = a.v()[i] + (b.v()[i] - a.v()[i]) * e;
        return out;
    }
}
