package com.des.cinematic.api;

import com.des.cinematic.core.Spec;
import com.des.cinematic.core.Vec3;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.entity.Player;
import org.bukkit.plugin.Plugin;

import java.util.*;

/** Everything an {@link ActionModule} needs to know about the running production. Spec coordinates are origin-relative. */
public final class ProductionContext {
    private final Plugin plugin; private final Spec.Production spec; private final World world; private final Location origin;
    private final Map<String, Map<String, Object>> actorDefs, weaponDefs; private final double audienceRadius; private final Map<String, Object> productionRaw;

    public ProductionContext(Plugin plugin, Spec.Production spec, World world, Location origin, Map<String, Map<String, Object>> actorDefs,
                             Map<String, Map<String, Object>> weaponDefs, double audienceRadius, Map<String, Object> productionRaw) {
        this.productionRaw = productionRaw;
        this.plugin = plugin; this.spec = spec; this.world = world; this.origin = origin;
        this.actorDefs = actorDefs; this.weaponDefs = weaponDefs; this.audienceRadius = audienceRadius;
    }
    public Plugin plugin() { return plugin; }
    /** The raw production.yml map (sounds, dialogue, ...). */
    public Map<String, Object> productionRaw() { return productionRaw; }
    public Spec.Production spec() { return spec; }
    public World world() { return world; }
    public Location origin() { return origin.clone(); }
    public Map<String, Object> actorDef(String id) { return actorDefs.getOrDefault(id, Map.of()); }
    public Map<String, Object> weaponDef(String id) { return weaponDefs.getOrDefault(id, Map.of()); }

    /** Origin-relative -> absolute world location. */
    public Location abs(Vec3 rel) { return new Location(world, origin.getX() + rel.x(), origin.getY() + rel.y(), origin.getZ() + rel.z()); }
    public Location abs(Vec3 rel, double yaw, double pitch) { Location l = abs(rel); l.setYaw((float) yaw); l.setPitch((float) pitch); return l; }
    public Vec3 rel(Location l) { return new Vec3(l.getX() - origin.getX(), l.getY() - origin.getY(), l.getZ() - origin.getZ()); }

    /** Players who should see/hear positional effects. Players are observers: this never moves, mounts or restricts them. */
    public List<Player> audience() {
        List<Player> out = new ArrayList<>();
        double r2 = audienceRadius * audienceRadius;
        for (Player p : world.getPlayers()) if (p.getLocation().distanceSquared(origin) <= r2) out.add(p);
        return out;
    }
}
