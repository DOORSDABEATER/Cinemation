package com.des.cinematic.core;

/** Pure geometry shared by CombatModule (live) and the offline choreography simulation, so they cannot drift apart. */
public final class CombatGeometry {
    private CombatGeometry() {}
    /** Centre-to-centre distance at which a strike of the given reach touches the target's surface. */
    public static double wantedDistance(double reach, double targetRadius) { return reach + targetRadius; }
    /** Whether the attacker must reposition before striking. */
    public static boolean needsRepositioning(double dist, double want) { return Math.abs(dist - want) > 0.45; }
    /** The point (same Y as the attacker) on the line target->attacker at the wanted distance. */
    public static Vec3 stepInPoint(Vec3 attacker, Vec3 target, double want) {
        Vec3 d = new Vec3(attacker.x() - target.x(), 0, attacker.z() - target.z());
        Vec3 dir = d.lengthXZ() < 1e-6 ? new Vec3(0, 0, -1) : d.normalizedXZ();
        return new Vec3(target.x() + dir.x() * want, attacker.y(), target.z() + dir.z() * want);
    }
    public static int stepInTicks(int impactTicks) { return Math.max(2, Math.min(impactTicks, 8)); }
    /** True when a blow that is supposed to connect would not (attacker too far from the target's surface). */
    public static boolean missesGeometrically(double gap, double want) { return gap > want + 1.2; }
}
