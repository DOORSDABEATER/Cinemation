package com.des.cinematic.rig;

import com.des.cinematic.rig.Quat.Xf;

/**
 * Solves a Pose into per-bone display transforms for the standard player rig. Output translations are in BLOCKS relative to the
 * actor's feet; the actor's world yaw is baked in, so the display entities themselves are never rotated.
 */
public final class RigSolver {
    public record BoneXf(double tx, double ty, double tz, Quat q) {}
    // joint positions in px, relative to the parent pivot (body pivot = root pivot = waist at y=12)
    private static final double WAIST = 12;

    private static Xf rot(Pose p, int bone, double fwdSign) {
        double rx = p.get(bone, 0), ry = p.get(bone, 1), rz = p.get(bone, 2);
        Quat q = Quat.axis(0, 1, 0, ry).mul(Quat.axis(0, 0, 1, rz)).mul(Quat.axis(1, 0, 0, fwdSign * rx));
        return Xf.r(q);
    }
    private static Xf off(Pose p, int bone, double x, double y, double z) { return Xf.t(x + p.get(bone, 3), y + p.get(bone, 4), z + p.get(bone, 5)); }

    /** @return transforms for head, body, arm_r, arm_l, leg_r, leg_l (in that order). */
    public static BoneXf[] solve(Pose p, double actorYawDeg, double scale) {
        Xf yaw = Xf.r(Quat.axis(0, 1, 0, -actorYawDeg));        // MC yaw is clockwise-positive; our rotY is counter-clockwise
        Xf root = yaw.mul(off(p, 0, 0, WAIST, 0)).mul(rot(p, 0, +1));
        Xf body = root.mul(rot(p, 2, +1)).mul(Xf.t(p.get(2, 3), p.get(2, 4), p.get(2, 5)));
        Xf head = body.mul(off(p, 1, 0, WAIST, 0)).mul(rot(p, 1, +1));
        Xf armR = body.mul(off(p, 3, -6, WAIST, 0)).mul(rot(p, 3, -1));
        Xf armL = body.mul(off(p, 4, 6, WAIST, 0)).mul(rot(p, 4, -1));
        Xf legR = root.mul(off(p, 5, -2, 0, 0)).mul(rot(p, 5, -1));
        Xf legL = root.mul(off(p, 6, 2, 0, 0)).mul(rot(p, 6, -1));
        Xf[] all = {head, body, armR, armL, legR, legL};
        BoneXf[] out = new BoneXf[6];
        double k = scale / 16.0;
        for (int i = 0; i < 6; i++) out[i] = new BoneXf(all[i].tx() * k, all[i].ty() * k, all[i].tz() * k, all[i].q());
        return out;
    }
}
