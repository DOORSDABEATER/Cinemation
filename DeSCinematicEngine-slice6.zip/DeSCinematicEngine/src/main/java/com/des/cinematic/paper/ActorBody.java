package com.des.cinematic.paper;

import org.bukkit.Location;

/** What an Actor needs from its visible, animated body. Implementations: ClipBody (player rig), VaelBody (AZRATHIEL bone rig). */
public interface ActorBody {
    /** Plays a LOGICAL animation. Throws IllegalArgumentException/IllegalStateException for unknown/missing ones (never silent). Returns true if it loops. */
    boolean play(String logical, int blendTicks);
    boolean hasAnimation(String logical);
    /** Advance exactly one production tick. */
    void tick();
    void render(Location feet, double yaw);
    boolean animationFinished();
    String currentAnimation();
    void remove();
    boolean isValid();
    default void look(double yawDeg, double pitchDeg) {}
    default void reveal(String level) {}
}
