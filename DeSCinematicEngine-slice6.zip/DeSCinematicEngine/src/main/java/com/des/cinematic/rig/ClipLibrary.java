package com.des.cinematic.rig;

import com.des.cinematic.core.*;
import java.util.*;

/** Parses clips from YAML-derived maps (see tools/gen_error_clips.py for the schema). Problems are returned, never thrown. */
public final class ClipLibrary {
    private final Map<String, Clip> clips = new LinkedHashMap<>();
    public Optional<Clip> get(String id) { return Optional.ofNullable(clips.get(id)); }
    public Set<String> ids() { return clips.keySet(); }

    @SuppressWarnings("unchecked")
    public List<Issue> load(Map<String, Object> root) {
        List<Issue> issues = new ArrayList<>();
        Object cs = root.get("clips");
        if (!(cs instanceof Map<?, ?> m)) { issues.add(Issue.error("clips", "missing 'clips' map")); return issues; }
        for (Map.Entry<?, ?> e : m.entrySet()) {
            String id = String.valueOf(e.getKey());
            Params p = new Params((Map<String, Object>) e.getValue());
            double dur = p.dbl("duration", 0) * 20.0;
            if (dur <= 0) { issues.add(Issue.error("clip " + id, "duration (seconds) must be > 0")); continue; }
            List<Clip.Key> keys = new ArrayList<>();
            Object ko = ((Map<String, Object>) e.getValue()).get("keys");
            if (!(ko instanceof List<?> kl) || kl.isEmpty()) { issues.add(Issue.error("clip " + id, "no keys")); continue; }
            boolean ok = true;
            for (Object k : kl) {
                Map<String, Object> km = (Map<String, Object>) k;
                Pose pose = new Pose();
                for (Map.Entry<String, Object> be : km.entrySet()) {
                    if (be.getKey().equals("t")) continue;
                    int bi = Pose.index(be.getKey());
                    if (bi < 0 || !(be.getValue() instanceof Map<?, ?> cm)) { issues.add(Issue.error("clip " + id, "unknown bone/field '" + be.getKey() + "'")); ok = false; continue; }
                    for (Map.Entry<?, ?> ce : cm.entrySet()) {
                        int ci = Pose.channel(String.valueOf(ce.getKey()));
                        if (ci < 0 || !(ce.getValue() instanceof Number n)) { issues.add(Issue.error("clip " + id, "bad channel '" + ce.getKey() + "' on " + be.getKey())); ok = false; continue; }
                        pose.set(bi, ci, n.doubleValue());
                    }
                }
                keys.add(new Clip.Key(new Params(km).dbl("t", 0) * 20.0, pose));
            }
            if (ok) clips.put(id, new Clip(id, dur, p.bool("loop", false), p.ease("ease", Ease.IN_OUT_QUAD), keys));
        }
        return issues;
    }
}
