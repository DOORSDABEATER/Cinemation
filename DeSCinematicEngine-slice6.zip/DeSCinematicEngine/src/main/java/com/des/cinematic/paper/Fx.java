package com.des.cinematic.paper;

import org.bukkit.Bukkit;
import org.bukkit.Color;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Particle;
import org.bukkit.World;
import org.bukkit.block.data.BlockData;

import java.util.HashSet;
import java.util.Set;
import java.util.logging.Logger;

/**
 * Safe visual-effect helpers. Particles differ per Minecraft version (e.g. FLASH and DUST need extra data on recent versions); a raw
 * spawnParticle call with missing data THROWS. Every effect in the engine goes through here so a visual can never abort a production:
 * required data is supplied, and anything that still fails is logged once and skipped.
 */
public final class Fx {
    private Fx() {}
    static Logger log = Logger.getLogger("DeSCinematicEngine");
    private static final Set<String> warned = new HashSet<>();

    public static void spawn(World w, Particle p, Location l, int count, double dx, double dy, double dz, double speed) { spawn(w, p, l.getX(), l.getY(), l.getZ(), count, dx, dy, dz, speed, null); }
    public static void spawn(World w, Particle p, double x, double y, double z, int count, double dx, double dy, double dz, double speed) { spawn(w, p, x, y, z, count, dx, dy, dz, speed, null); }
    public static void spawn(World w, Particle p, Location l, int count, double dx, double dy, double dz, double speed, Object data) { spawn(w, p, l.getX(), l.getY(), l.getZ(), count, dx, dy, dz, speed, data); }

    @SuppressWarnings({"unchecked", "rawtypes"})
    public static void spawn(World w, Particle p, double x, double y, double z, int count, double dx, double dy, double dz, double speed, Object data) {
        try {
            Class<?> need = p.getDataType();
            if (need == null || need == Void.class) { w.spawnParticle(p, x, y, z, count, dx, dy, dz, speed); return; }
            Object d = data;
            if (d == null || !need.isInstance(d)) d = defaultData(need);
            if (d == null) { once("particle " + p + " needs unsupported data " + need.getSimpleName() + "; skipped"); return; }
            w.spawnParticle(p, x, y, z, count, dx, dy, dz, speed, d);
        } catch (RuntimeException e) { once("particle " + p + " failed (" + e.getClass().getSimpleName() + ": " + e.getMessage() + "); skipped"); }
    }

    /** Coloured dust (void-energy look). */
    public static void dust(World w, Location l, int count, double spread, int rgb, float size) {
        try { w.spawnParticle(Particle.DUST, l.getX(), l.getY(), l.getZ(), count, spread, spread, spread, 0, new Particle.DustOptions(Color.fromRGB(rgb & 0xFFFFFF), size)); }
        catch (RuntimeException e) { once("dust particle failed (" + e.getMessage() + "); skipped"); }
    }

    /** Visual-only lightning: no damage, no fire. */
    public static void lightning(World w, Location l) { try { w.strikeLightningEffect(l); } catch (RuntimeException e) { once("lightning effect failed: " + e.getMessage()); } }

    private static Object defaultData(Class<?> need) {
        if (need == Color.class) return Color.WHITE;
        if (BlockData.class.isAssignableFrom(need)) return Bukkit.createBlockData(Material.DEEPSLATE_BRICKS);
        if (need == Particle.DustOptions.class) return new Particle.DustOptions(Color.fromRGB(0x5B3CC4), 1.2f);
        if (need == Float.class) return 1.0f;
        if (need == Integer.class) return 0;
        return null;
    }
    private static void once(String msg) { if (warned.add(msg)) log.warning("fx: " + msg); }
}
