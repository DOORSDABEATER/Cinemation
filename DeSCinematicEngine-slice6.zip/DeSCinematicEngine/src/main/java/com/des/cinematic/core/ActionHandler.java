package com.des.cinematic.core;

/** Executes parsed actions. Implemented by the server layer (and by recorders in tests). */
public interface ActionHandler {
    /** Start an action. Long-running work must be advanced from {@link #tick}. Returns OK or a failure. */
    Outcome begin(Spec.Action action);
    /** Called once per production tick AFTER all due actions began. Not called while paused. */
    void tick(int sceneTick, int globalTick);
    /** True while any started action is still animating. Used to hold scene transitions. */
    boolean busy();
    void sceneStarted(Spec.Scene scene);
    void sceneEnded(Spec.Scene scene);
    void pause();
    void resume();
    /** Cancel everything and release every temporary entity/effect. Must be idempotent. */
    void cleanup(boolean restoreWorld);

    record Outcome(boolean ok, String message) {
        public static final Outcome OK = new Outcome(true, "");
        public static Outcome fail(String msg) { return new Outcome(false, msg); }
    }
}
