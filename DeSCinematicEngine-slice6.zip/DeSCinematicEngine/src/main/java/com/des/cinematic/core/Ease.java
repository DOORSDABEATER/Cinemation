package com.des.cinematic.core;

public enum Ease {
    LINEAR, IN_QUAD, OUT_QUAD, IN_OUT_QUAD, IN_CUBIC, OUT_CUBIC, IN_OUT_CUBIC;
    public double apply(double t) {
        t = Math.max(0, Math.min(1, t));
        return switch (this) {
            case LINEAR -> t;
            case IN_QUAD -> t * t;
            case OUT_QUAD -> 1 - (1 - t) * (1 - t);
            case IN_OUT_QUAD -> t < 0.5 ? 2 * t * t : 1 - Math.pow(-2 * t + 2, 2) / 2;
            case IN_CUBIC -> t * t * t;
            case OUT_CUBIC -> 1 - Math.pow(1 - t, 3);
            case IN_OUT_CUBIC -> t < 0.5 ? 4 * t * t * t : 1 - Math.pow(-2 * t + 2, 3) / 2;
        };
    }
    public static Ease parse(Object o, Ease def) {
        if (o == null) return def;
        try { return valueOf(o.toString().trim().toUpperCase().replace('-', '_')); } catch (IllegalArgumentException e) { return def; }
    }
}
