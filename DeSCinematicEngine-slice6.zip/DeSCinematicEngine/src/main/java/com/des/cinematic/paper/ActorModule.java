package com.des.cinematic.paper;

import com.des.cinematic.api.ActionModule;
import com.des.cinematic.api.ProductionContext;
import com.des.cinematic.core.*;
import com.des.cinematic.motion.ActorMotion;
import com.des.cinematic.motion.MotionPlan;
import com.des.cinematic.rig.ClipLibrary;
import com.des.cinematic.rig.ParamClipLibrary;
import com.des.cinematic.vael.Form;
import com.des.cinematic.vael.VaelRig;
import org.bukkit.plugin.java.JavaPlugin;

import java.io.InputStreamReader;
import java.util.*;

/** Executes ACTOR actions: spawn/despawn, walking, running, dashing, jumping, leaping, launching, knockback, facing, animation. */
public final class ActorModule implements ActionModule, com.des.cinematic.api.TimeScaled {
    public static final String RIG_PLAYER = "error_player_rig", RIG_VAEL = "azrathiel_vaelzarion";
    private final JavaPlugin plugin;
    private final Map<String, Actor> actors = new LinkedHashMap<>();
    private final Map<String, ClipLibrary> clipCache = new HashMap<>();
    private final Map<String, ParamClipLibrary> paramCache = new HashMap<>();
    private boolean paused; private double timeScale = 1.0;

    public ActorModule(JavaPlugin plugin) { this.plugin = plugin; }

    @Override public String id() { return "actors"; }
    @Override public Set<ActionCatalog.Category> categories() { return EnumSet.of(ActionCatalog.Category.ACTOR); }
    public Optional<Actor> actor(String id) { return Optional.ofNullable(actors.get(id)); }
    public Collection<Actor> actors() { return actors.values(); }
    @Override public void timeScale(double s) { timeScale = Math.max(0, s); }

    @Override public void productionStarted(ProductionContext c) {
        paused = false; timeScale = 1.0;
        int swept = PlayerDisplayRig.sweepOrphans();
        if (swept > 0) plugin.getLogger().warning("Removed " + swept + " orphaned actor display entities from an earlier run.");
    }

    // ------------------------------------------------------------------ validation
    @Override public List<Issue> validate(Spec.Production p, Map<String, Map<String, Object>> actorDefs, Map<String, Map<String, Object>> weaponDefs) {
        List<Issue> out = new ArrayList<>();
        for (String id : p.actors()) out.addAll(validateActor(id, actorDefs.get(id)));
        return out;
    }

    @SuppressWarnings("unchecked")
    public List<Issue> validateActor(String actorId, Map<String, Object> def) {
        List<Issue> out = new ArrayList<>(); String w = "actors/" + actorId + ".yml";
        if (def == null) { out.add(Issue.error(w, "actor definition missing")); return out; }
        Map<String, Object> model = def.get("model") instanceof Map<?, ?> m ? (Map<String, Object>) m : Map.of();
        String backend = String.valueOf(model.getOrDefault("backend", "display_rig")), rig = String.valueOf(model.getOrDefault("rig", ""));
        if (backend.equals("modelengine")) { out.add(Issue.error(w, "backend 'modelengine' has no adapter in this build; use backend: display_rig")); return out; }
        Object anims = def.get("animations");
        if (!(anims instanceof Map<?, ?> am) || am.isEmpty()) { out.add(Issue.error(w, "no 'animations' mapping")); return out; }
        switch (rig) {
            case RIG_PLAYER -> {
                ClipLibrary lib = clips(model, out, w);
                if (lib != null) for (Map.Entry<?, ?> e : am.entrySet())
                    if (lib.get(String.valueOf(e.getValue())).isEmpty()) out.add(Issue.error(w, "animation '" + e.getKey() + "' -> clip '" + e.getValue() + "' does not exist in " + model.get("clips")));
                if (!(model.get("model_prefix") instanceof String)) out.add(Issue.error(w, "model.model_prefix missing"));
            }
            case RIG_VAEL -> {
                ParamClipLibrary lib = paramClips(model, out, w);
                if (lib != null) for (Map.Entry<?, ?> e : am.entrySet())
                    if (lib.get(String.valueOf(e.getValue())).isEmpty()) out.add(Issue.error(w, "animation '" + e.getKey() + "' -> clip '" + e.getValue() + "' does not exist in " + model.get("clips")));
                try { Form.valueOf(String.valueOf(model.getOrDefault("form", "APOCALYPSE"))); } catch (IllegalArgumentException ex) { out.add(Issue.error(w, "model.form must be DORMANT, RELEASED or APOCALYPSE")); }
            }
            default -> out.add(Issue.error(w, "rig '" + rig + "' has no adapter (known: " + RIG_PLAYER + ", " + RIG_VAEL + ")"));
        }
        return out;
    }

    private ClipLibrary clips(Map<String, Object> model, List<Issue> issues, String where) {
        String path = String.valueOf(model.getOrDefault("clips", ""));
        if (path.isBlank() || path.equals("null")) { issues.add(Issue.error(where, "model.clips is not set")); return null; }
        ClipLibrary cached = clipCache.get(path); if (cached != null) return cached;
        try (var in = plugin.getResource(path)) {
            if (in == null) { issues.add(Issue.error(where, "clip file '" + path + "' not found in the plugin jar")); return null; }
            ClipLibrary lib = new ClipLibrary();
            issues.addAll(lib.load(YamlIo.load(new InputStreamReader(in, java.nio.charset.StandardCharsets.UTF_8), path)));
            clipCache.put(path, lib); return lib;
        } catch (java.io.IOException | RuntimeException e) { issues.add(Issue.error(where, "cannot read " + path + ": " + e.getMessage())); return null; }
    }

    private ParamClipLibrary paramClips(Map<String, Object> model, List<Issue> issues, String where) {
        String path = String.valueOf(model.getOrDefault("clips", ""));
        if (path.isBlank() || path.equals("null")) { issues.add(Issue.error(where, "model.clips is not set")); return null; }
        ParamClipLibrary cached = paramCache.get(path); if (cached != null) return cached;
        try (var in = plugin.getResource(path)) {
            if (in == null) { issues.add(Issue.error(where, "clip file '" + path + "' not found in the plugin jar")); return null; }
            ParamClipLibrary lib = new ParamClipLibrary();
            issues.addAll(lib.load(YamlIo.load(new InputStreamReader(in, java.nio.charset.StandardCharsets.UTF_8), path)));
            paramCache.put(path, lib); return lib;
        } catch (java.io.IOException | RuntimeException e) { issues.add(Issue.error(where, "cannot read " + path + ": " + e.getMessage())); return null; }
    }

    // ------------------------------------------------------------------ actions
    @Override public ActionHandler.Outcome begin(Spec.Action a, ProductionContext c) {
        try { return run(a, c); }
        catch (IllegalArgumentException | IllegalStateException e) { return ActionHandler.Outcome.fail(e.getMessage()); }
    }

    private ActionHandler.Outcome run(Spec.Action a, ProductionContext c) {
        Params p = a.params(); String id = a.actor();
        if (a.action().equals("spawn")) return spawn(a, c);
        Actor actor = actors.get(id);
        if (actor == null) return ActionHandler.Outcome.fail("actor '" + id + "' is not spawned");
        Vec3 pos = actor.pos();
        switch (a.action()) {
            case "despawn" -> { actor.remove(); actors.remove(id); }
            case "walk_to" -> actor.move(speedPlan(p, pos, p.vec("to"), actor.speeds().walk()), true, anim(actor, p, "walk"));
            case "run_to" -> actor.move(speedPlan(p, pos, p.vec("to"), actor.speeds().run()), true, anim(actor, p, "run"));
            case "dash_to" -> actor.move(new MotionPlan.Linear(pos, p.vec("to"), a.durationTicks(), Ease.OUT_CUBIC), true, anim(actor, p, "run"));
            case "jump_to" -> actor.move(new MotionPlan.Arc(pos, p.vec("to"), p.dbl("apex", 1.3), a.durationTicks(), Ease.LINEAR), true, anim(actor, p, "jump"));
            case "leap_to" -> actor.move(new MotionPlan.Arc(pos, p.vec("to"), p.dbl("apex", 3.0), a.durationTicks(), Ease.OUT_QUAD), true, anim(actor, p, "jump"));
            case "follow_path" -> {
                List<Vec3> pts = new ArrayList<>(); pts.add(pos); pts.addAll(p.path("path"));
                actor.move(new MotionPlan.Path(pts, p.dbl("speed", actor.speeds().walk()), p.ease("ease", Ease.LINEAR)), true, anim(actor, p, "walk"));
            }
            case "teleport" -> { actor.motion().teleport(p.vec("to")); if (p.has("yaw")) actor.motion().setYawImmediate(p.dbl("yaw", 0)); }
            case "face" -> face(actor, p);
            case "animate" -> {
                look(actor, p); boolean base = p.bool("as_base", false);          // as_base: this loop becomes what the actor returns to after one-shots
                actor.play(p.str("anim", "idle"), p.integer("blend", 4), base || p.bool("hold", false), a.durationTicks() > 0 && p.has("duration") ? a.durationTicks() : 0);
                if (base) actor.setBase(p.str("anim", "idle"));
            }
            case "pose" -> { look(actor, p); actor.play(p.str("anim", "idle"), p.integer("blend", 4), true); }
            case "launch" -> actor.move(new MotionPlan.Arc(pos, p.vec("to"), p.dbl("apex", 12), a.durationTicks(), Ease.OUT_QUAD), false, anim(actor, p, "launch_fly"));
            case "knockback" -> actor.move(new MotionPlan.Linear(pos, p.vec("to"), a.durationTicks(), Ease.OUT_QUAD), false, anim(actor, p, "knockback"));
            case "land" -> actor.play(anim(actor, p, "land"), 3, false);
            case "get_up" -> actor.play(anim(actor, p, "get_up"), 4, false);
            case "hit_reaction" -> actor.play(anim(actor, p, "hit"), 2, false);
            case "float" -> actor.hover(p.dbl("height", 0), Math.max(1, a.durationTicks()));
            default -> { return ActionHandler.Outcome.fail("ActorModule does not implement action '" + a.action() + "'"); }
        }
        return ActionHandler.Outcome.OK;
    }

    /** Explicit 'anim' is used verbatim (strict); otherwise the default degrades to the closest animation the actor has. */
    private static String anim(Actor actor, Params p, String dflt) { return p.has("anim") ? p.str("anim", dflt) : actor.resolveDefault(dflt); }
    private static void look(Actor actor, Params p) { actor.body().look(p.dbl("head_yaw", 0), p.dbl("head_pitch", 0)); }
    private static MotionPlan speedPlan(Params p, Vec3 from, Vec3 to, double defSpeed) { return new MotionPlan.Path(List.of(from, to), p.dbl("speed", defSpeed), p.ease("ease", Ease.LINEAR)); }

    private void face(Actor actor, Params p) {
        if (p.has("target")) {
            Actor t = actors.get(p.str("target", ""));
            if (t == null) throw new IllegalStateException("face target '" + p.str("target", "") + "' is not spawned");
            actor.motion().faceTarget(t::pos);
        } else if (p.has("at")) { Vec3 at = p.vec("at"); actor.motion().faceTarget(() -> at); }
        else actor.motion().faceYaw(p.dbl("yaw", 0));
    }

    @SuppressWarnings("unchecked")
    private ActionHandler.Outcome spawn(Spec.Action a, ProductionContext c) {
        String id = a.actor(); Params p = a.params();
        Actor existing = actors.get(id);
        if (existing != null) {                 // a repeated spawn is a staged reveal (silhouette -> partial -> full)
            if (p.has("reveal")) existing.body().reveal(p.str("reveal", "full"));
            return ActionHandler.Outcome.OK;
        }
        if (actors.size() >= plugin.getConfig().getInt("performance.max-active-actors", 8)) return ActionHandler.Outcome.fail("max-active-actors reached");
        Map<String, Object> def = c.actorDef(id);
        List<Issue> issues = validateActor(id, def);
        if (Validator.hasErrors(issues)) return ActionHandler.Outcome.fail(issues.get(0).message());
        Map<String, Object> model = (Map<String, Object>) def.get("model");
        Params dp = new Params(def), mp = new Params(model);
        Map<String, String> animMap = new HashMap<>();
        for (Map.Entry<?, ?> e : ((Map<?, ?>) def.get("animations")).entrySet()) animMap.put(String.valueOf(e.getKey()), String.valueOf(e.getValue()));
        Vec3 at = p.vec("at");
        float viewRange = Math.max(1f, (float) plugin.getConfig().getDouble("engine.audience-radius", 128) / 64f);
        String owner = c.spec().id();
        ActorBody body;
        if (mp.str("rig", "").equals(RIG_PLAYER)) {
            double scale = dp.dbl("scale", 1.0) * 0.9;     // 0.9 => 1.8-block-tall player
            PlayerDisplayRig rig = new PlayerDisplayRig(c.abs(at), mp.str("model_prefix", ""), scale, owner, viewRange, 2);
            body = new ClipBody(clips(model, new ArrayList<>(), id), animMap, rig);
        } else {
            Form form = Form.valueOf(mp.str("form", "APOCALYPSE"));
            VaelRig rig = VaelRig.spawn(c.abs(at), form, owner, (int) Long.parseLong(mp.str("tint_hex", "5B3CC4"), 16), viewRange);
            rig.extraScale((float) dp.dbl("scale", 1.0));
            body = new VaelBody(rig, paramClips(model, new ArrayList<>(), id), animMap, dp.dbl("ground_offset", 1.7), (int) Long.parseLong(mp.str("tint_hex", "5B3CC4"), 16));
            if (p.has("reveal")) body.reveal(p.str("reveal", "full"));
        }
        MotionPlan.Speeds speeds = new MotionPlan.Speeds(new Params(sp(def)).dbl("walk", MotionPlan.Speeds.DEFAULT.walk()), new Params(sp(def)).dbl("run", MotionPlan.Speeds.DEFAULT.run()));
        ActorMotion motion = new ActorMotion(at, p.dbl("yaw", 0)); motion.turnRate(dp.dbl("turn_rate", 18));
        Actor actor = new Actor(id, dp.str("display_name", id), body, motion, speeds);
        actor.dims(dp.dbl("chest_height", 1.2), dp.dbl("body_radius", 0.4));
        actor.trailRgb((int) Long.parseLong(dp.str("trail_hex", "5B3CC4"), 16));
        actors.put(id, actor);
        actor.play(p.str("anim", "idle"), 0, true);
        actor.render(c);
        return ActionHandler.Outcome.OK;
    }
    @SuppressWarnings("unchecked") private static Map<String, Object> sp(Map<String, Object> def) { return def.get("speeds") instanceof Map<?, ?> m ? (Map<String, Object>) m : Map.of(); }

    // ------------------------------------------------------------------ lifecycle
    @Override public void tick(ProductionContext c, int sceneTick, int globalTick) {
        if (paused) return;
        for (Actor a : new ArrayList<>(actors.values())) {
            if (!a.valid()) { plugin.getLogger().severe("actor '" + a.id + "' lost its display entities (chunk unloaded or entity removed); despawning"); a.remove(); actors.remove(a.id); continue; }
            a.tick(c, timeScale);
            trail(c, a);
        }
    }
    /** Fast movement leaves an energy trail (dashes, leaps, launches, runs): speed is blocks per tick. */
    private void trail(ProductionContext c, Actor a) {
        double v = a.motion().velocity().length(); if (v < 0.26 || timeScale <= 0) return;
        Vec3 p = a.pos(); int n = (int) Math.min(10, 2 + v * 12);
        for (int i = 0; i < n; i++) {
            double h = (i / (double) n) * a.chest() * 1.7;
            Fx.dust(c.world(), c.abs(new Vec3(p.x(), p.y() + h, p.z())), 1, 0.22, a.trailRgb(), 1.5f);
        }
        Fx.spawn(c.world(), org.bukkit.Particle.SOUL_FIRE_FLAME, c.abs(new Vec3(p.x(), p.y() + a.chest() * 0.6, p.z())), 2, 0.2, 0.3, 0.2, 0.01);
        if (v > 0.5) Fx.spawn(c.world(), org.bukkit.Particle.CLOUD, c.abs(new Vec3(p.x(), p.y() + 0.2, p.z())), 2, 0.2, 0.05, 0.2, 0.01);
    }
    @Override public boolean busy() { for (Actor a : actors.values()) if (a.moving()) return true; return false; }
    @Override public void pause() { paused = true; }
    @Override public void resume() { paused = false; }
    @Override public void cleanup(boolean restoreWorld) { for (Actor a : actors.values()) a.remove(); actors.clear(); PlayerDisplayRig.sweepOrphans(); }
    @Override public void reset(String productionId) { cleanup(true); }
}
