package com.des.cinematic.core;

import java.util.*;

/**
 * Turns a data-driven structure definition into an ordered list of block placements (origin-relative). Pure Java: no server needed,
 * so region compliance and counts are unit-tested offline. Later steps override earlier ones at the same position.
 */
public final class StructureBuilder {
    public record Op(int x, int y, int z, String block) {}
    public record Result(String id, String region, List<Op> ops, Map<String, List<int[]>> groups, List<int[]> lights, int lightLevel,
                         Vec3 clearMin, Vec3 clearMax, double maxSolidRatio, int samples, Map<String, List<String>> fallbacks, List<Issue> issues) {}

    @SuppressWarnings("unchecked") private static Map<String, Object> map(Object o) { return o instanceof Map<?, ?> m ? (Map<String, Object>) m : Map.of(); }

    public static Result build(Map<String, Object> def, Spec.Region region) {
        List<Issue> issues = new ArrayList<>();
        String id = String.valueOf(def.getOrDefault("id", "?"));
        LinkedHashMap<Long, Op> ops = new LinkedHashMap<>();
        Map<String, List<int[]>> groups = new LinkedHashMap<>();
        List<int[]> lights = new ArrayList<>(); int[] lightLevel = {6};
        int idx = 0;
        for (Object so : def.get("steps") instanceof List<?> l ? l : List.<Object>of()) {
            Params p = new Params(map(so)); String t = p.str("type", "?"); String where = id + ".steps[" + (idx++) + "] " + t;
            try {
                switch (t) {
                    case "fill" -> box(ops, p.vec("min"), p.vec("max"), p.str("block", "minecraft:air"), null, groups);
                    case "disc" -> { Vec3 c = p.vec("center"); int r = p.integer("radius", 1); for (int dx = -r; dx <= r; dx++) for (int dz = -r; dz <= r; dz++) if (dx * dx + dz * dz <= r * r) put(ops, (int) c.x() + dx, (int) c.y(), (int) c.z() + dz, p.str("block", "")); }
                    case "ring" -> { Vec3 c = p.vec("center"); int r = p.integer("radius", 1); for (int dx = -r - 1; dx <= r + 1; dx++) for (int dz = -r - 1; dz <= r + 1; dz++) { double d = Math.sqrt(dx * dx + dz * dz); if (d >= r - 0.5 && d < r + 0.5) put(ops, (int) c.x() + dx, (int) c.y(), (int) c.z() + dz, p.str("block", "")); } }
                    case "pillars" -> {
                        int h = p.integer("height", 12);
                        for (Object xo : (List<?>) map(so).get("xs")) for (Object zo : (List<?>) map(so).get("zs")) {
                            int cx = ((Number) xo).intValue(), cz = ((Number) zo).intValue();
                            for (int dx = -2; dx <= 2; dx++) for (int dz = -2; dz <= 2; dz++) put(ops, cx + dx, 0, cz + dz, p.str("base", ""));                      // 5x5 plinth
                            for (int y = 1; y <= h - 2; y++) for (int dx = -1; dx <= 1; dx++) for (int dz = -1; dz <= 1; dz++) put(ops, cx + dx, y, cz + dz, p.str("shaft", ""));
                            for (int dx = -2; dx <= 2; dx++) for (int dz = -2; dz <= 2; dz++) put(ops, cx + dx, h - 1, cz + dz, p.str("cap", ""));
                            groups.computeIfAbsent("pillar:" + cx + ":" + cz, k -> new ArrayList<>()).add(new int[]{cx, 0, cz});
                        }
                    }
                    case "pedestal" -> { Vec3 a = p.vec("at"); int ax = (int) a.x(), ay = (int) a.y(), az = (int) a.z();
                        for (int dx = -1; dx <= 1; dx++) for (int dz = -1; dz <= 1; dz++) put(ops, ax + dx, ay, az + dz, p.str("block", "")); put(ops, ax, ay, az, p.str("top", p.str("block", ""))); }
                    case "line" -> { Vec3 a = p.vec("from"), b = p.vec("to"); int n = (int) Math.max(Math.abs(b.x() - a.x()), Math.max(Math.abs(b.y() - a.y()), Math.abs(b.z() - a.z())));
                        for (int i = 0; i <= n; i++) { double f = n == 0 ? 0 : (double) i / n; int x = (int) Math.round(a.x() + (b.x() - a.x()) * f), y = (int) Math.round(a.y() + (b.y() - a.y()) * f), z = (int) Math.round(a.z() + (b.z() - a.z()) * f);
                            put(ops, x, y, z, p.str("block", "")); if (p.has("group")) groups.computeIfAbsent(p.str("group", ""), k -> new ArrayList<>()).add(new int[]{x, y, z}); } }
                    case "chains" -> { int len = p.integer("length", 4); for (Object po : (List<?>) map(so).get("positions")) { Vec3 v = Params.parseVec(po); for (int i = 0; i < len; i++) put(ops, (int) v.x(), (int) v.y() - i, (int) v.z(), p.str("block", "")); } }
                    case "lights" -> { lightLevel[0] = p.integer("level", 6); for (Object po : (List<?>) map(so).get("positions")) { Vec3 v = Params.parseVec(po); int[] c = {(int) v.x(), (int) v.y(), (int) v.z()}; lights.add(c); put(ops, c[0], c[1], c[2], "minecraft:light[level=" + lightLevel[0] + "]"); } }
                    case "block" -> { Vec3 a = p.vec("at"); put(ops, (int) a.x(), (int) a.y(), (int) a.z(), p.str("block", "")); }
                    default -> issues.add(Issue.error(where, "unknown structure step type"));
                }
            } catch (RuntimeException e) { issues.add(Issue.error(where, "malformed step: " + e.getClass().getSimpleName() + " " + e.getMessage())); }
        }
        // region compliance: EVERY placement must be inside the declared destructible region
        int outside = 0;
        for (Op o : ops.values()) if (!region.contains(new Vec3(o.x(), o.y(), o.z()))) { if (outside++ < 3) issues.add(Issue.error(id, "placement (" + o.x() + "," + o.y() + "," + o.z() + ") is outside region '" + region.id() + "'")); }
        if (outside > 3) issues.add(Issue.error(id, (outside - 3) + " more placements outside region '" + region.id() + "'"));
        for (Op o : ops.values()) if (o.block().isBlank()) { issues.add(Issue.error(id, "empty block name in a step")); break; }
        Map<String, List<String>> fallbacks = new LinkedHashMap<>();
        for (Map.Entry<String, Object> fe : map(def.get("block_fallbacks")).entrySet()) fallbacks.put(fe.getKey(), new Params(Map.of("v", fe.getValue())).strList("v"));
        Params cc = new Params(map(def.get("interior_clear_check")));
        Vec3 cmin = cc.vec("min"), cmax = cc.vec("max");
        return new Result(id, String.valueOf(def.getOrDefault("region", "")), new ArrayList<>(ops.values()), groups, lights, lightLevel[0], cmin, cmax, cc.dbl("max_solid_ratio", 0.1), cc.integer("samples", 200), fallbacks, issues);
    }

    private static void box(Map<Long, Op> ops, Vec3 a, Vec3 b, String block, String unused, Map<String, List<int[]>> groups) {
        if (a == null || b == null) throw new IllegalArgumentException("fill needs min and max");
        for (int y = (int) Math.min(a.y(), b.y()); y <= (int) Math.max(a.y(), b.y()); y++)
            for (int x = (int) Math.min(a.x(), b.x()); x <= (int) Math.max(a.x(), b.x()); x++)
                for (int z = (int) Math.min(a.z(), b.z()); z <= (int) Math.max(a.z(), b.z()); z++) put(ops, x, y, z, block);
    }
    private static void put(Map<Long, Op> ops, int x, int y, int z, String block) {
        long k = ((long) (x + 4096) << 40) | ((long) (y + 4096) << 20) | (z + 4096);
        ops.put(k, new Op(x, y, z, block));
    }
}
