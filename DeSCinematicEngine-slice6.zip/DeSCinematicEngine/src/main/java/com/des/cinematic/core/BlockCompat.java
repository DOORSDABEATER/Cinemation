package com.des.cinematic.core;

import java.util.*;
import java.util.function.Predicate;

/**
 * Block-name compatibility across Minecraft versions. Pure logic: the server layer supplies the "does this server accept this block
 * string" predicate (Bukkit.createBlockData), tests supply simulated registries.
 *
 * Order tried for a requested block: (1) as written, (2) with an explicit default axis state for axis blocks (chain), (3) the known
 * renamed spelling (chain <-> iron_chain), (4) the structure's own declared fallbacks. Nothing is ever silently dropped: the result says
 * exactly which kind of match was used so callers can log/validate it.
 */
public final class BlockCompat {
    private BlockCompat() {}
    public enum Kind { EXACT, RENAMED, FALLBACK, UNRESOLVED }
    public record Resolution(String requested, String resolved, Kind kind, List<String> tried) {
        public boolean ok() { return kind != Kind.UNRESOLVED; }
    }

    /** Known renames between versions (both directions so structures written for either spelling work on either server). */
    private static final Map<String, String> RENAMES = Map.of("minecraft:chain", "minecraft:iron_chain", "minecraft:iron_chain", "minecraft:chain");
    private static final Set<String> AXIS_BLOCKS = Set.of("minecraft:chain", "minecraft:iron_chain");

    public static String base(String block) { int i = block.indexOf('['); return i < 0 ? block : block.substring(0, i); }
    public static String state(String block) { int i = block.indexOf('['); return i < 0 ? "" : block.substring(i); }

    public static List<String> candidates(String requested, Map<String, List<String>> fallbacks) {
        LinkedHashMap<String, Kind> out = new LinkedHashMap<>();
        String b = base(requested), st = state(requested);
        out.put(requested, Kind.EXACT);
        if (st.isEmpty() && AXIS_BLOCKS.contains(b)) out.putIfAbsent(b + "[axis=y]", Kind.EXACT);
        String renamed = RENAMES.get(b);
        if (renamed != null) {
            out.putIfAbsent(renamed + st, Kind.RENAMED);
            if (st.isEmpty() && AXIS_BLOCKS.contains(renamed)) out.putIfAbsent(renamed + "[axis=y]", Kind.RENAMED);
        }
        List<String> fb = fallbacks == null ? List.of() : fallbacks.getOrDefault(requested, fallbacks.getOrDefault(b, List.of()));
        for (String f : fb) out.putIfAbsent(f, Kind.FALLBACK);
        return new ArrayList<>(out.keySet());
    }

    public static Resolution resolve(String requested, Map<String, List<String>> fallbacks, Predicate<String> serverAccepts) {
        List<String> tried = new ArrayList<>();
        String b = base(requested), renamed = RENAMES.get(b);
        List<String> declared = fallbacks == null ? List.of() : fallbacks.getOrDefault(requested, fallbacks.getOrDefault(b, List.of()));
        for (String c : candidates(requested, fallbacks)) {
            tried.add(c);
            boolean ok;
            try { ok = serverAccepts.test(c); } catch (RuntimeException e) { ok = false; }
            if (!ok) continue;
            Kind k = declared.contains(c) && !base(c).equals(b) && !base(c).equals(renamed) ? Kind.FALLBACK : base(c).equals(b) ? Kind.EXACT : renamed != null && base(c).equals(renamed) ? Kind.RENAMED : Kind.FALLBACK;
            return new Resolution(requested, c, k, tried);
        }
        return new Resolution(requested, null, Kind.UNRESOLVED, tried);
    }
}
