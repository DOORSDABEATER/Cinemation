package com.des.cinematic.rig;

/**
 * A full-body pose for the 6-bone player rig. 7 "bones" (root + 6) x 6 channels.
 * Channels: rx, ry, rz in degrees; x, y, z in model pixels (1 px = 1/16 block before actor scale).
 * Sign conventions: arms/legs rx>0 swing FORWARD; head/body/root rx>0 tilt FORWARD/DOWN. ry>0 turns counter-clockwise seen from above
 * (so a right-hand punch twists the body with ry>0). rz>0 rolls toward the character's left. root.y<0 lowers the whole body.
 */
public final class Pose {
    public static final String[] BONES = {"root", "head", "body", "arm_r", "arm_l", "leg_r", "leg_l"};
    public static final String[] CHANNELS = {"rx", "ry", "rz", "x", "y", "z"};
    public static final int N = BONES.length * CHANNELS.length;
    public final double[] v = new double[N];

    public static int index(String bone) { for (int i = 0; i < BONES.length; i++) if (BONES[i].equals(bone)) return i; return -1; }
    public static int channel(String ch) { for (int i = 0; i < CHANNELS.length; i++) if (CHANNELS[i].equals(ch)) return i; return -1; }
    public double get(int bone, int ch) { return v[bone * 6 + ch]; }
    public void set(int bone, int ch, double val) { v[bone * 6 + ch] = val; }
    public Pose copy() { Pose p = new Pose(); System.arraycopy(v, 0, p.v, 0, N); return p; }
    public static Pose lerp(Pose a, Pose b, double t) { Pose p = new Pose(); for (int i = 0; i < N; i++) p.v[i] = a.v[i] + (b.v[i] - a.v[i]) * t; return p; }
}
