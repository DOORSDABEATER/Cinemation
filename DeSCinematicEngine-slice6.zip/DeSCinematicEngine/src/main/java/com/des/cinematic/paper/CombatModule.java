package com.des.cinematic.paper;

import com.des.cinematic.api.ActionModule;
import com.des.cinematic.api.ProductionContext;
import com.des.cinematic.core.*;
import com.des.cinematic.motion.MotionPlan;
import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.SoundCategory;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.*;

/**
 * COMBAT actions. Every exchange is an explicit, deterministic choreography: the attacker steps in until the strike can physically
 * reach the target's surface, the impact lands at its scripted tick, and the result (hit/blocked/dodged/clashed) decides the visible
 * feedback. Nothing here deals damage to anyone; players are never touched. Geometry problems are logged, never silently ignored.
 */
public final class CombatModule implements ActionModule {
    private interface Effect { boolean tick(); }
    private record Due(int tick, Runnable run) {}
    private final JavaPlugin plugin; private final ActorModule actors;
    private final List<Due> due = new ArrayList<>(); private final List<Effect> effects = new ArrayList<>();
    private int now; private boolean paused; private int particleBudget; private PresentationModule presentation;
    public void setPresentation(PresentationModule p) { this.presentation = p; }

    public CombatModule(JavaPlugin plugin, ActorModule actors) { this.plugin = plugin; this.actors = actors; }
    @Override public String id() { return "combat"; }
    @Override public Set<ActionCatalog.Category> categories() { return EnumSet.of(ActionCatalog.Category.COMBAT); }
    @Override public void productionStarted(ProductionContext c) { due.clear(); effects.clear(); now = 0; paused = false; }

    private Actor actor(String id, String what) { return actors.actor(id).orElseThrow(() -> new IllegalStateException(what + " '" + id + "' is not spawned")); }
    private void later(int ticks, Runnable r) { due.add(new Due(now + Math.max(0, ticks), r)); }
    private static Vec3 flat(Vec3 v) { return new Vec3(v.x(), 0, v.z()); }

    @Override public ActionHandler.Outcome begin(Spec.Action a, ProductionContext c) {
        try {
            switch (a.action()) {
                case "attack" -> { return attack(a, c, false); }
                case "counter" -> { return attack(a, c, false); }
                case "block" -> block(a);
                case "dodge" -> dodge(a);
                case "clash" -> clash(a, c);
                case "projectile" -> projectile(a, c);
                case "area_attack" -> area(a, c);
                case "teleport_attack" -> teleportAttack(a, c);
                default -> { return ActionHandler.Outcome.fail("CombatModule does not implement '" + a.action() + "'"); }
            }
        } catch (IllegalArgumentException | IllegalStateException | NullPointerException e) { return ActionHandler.Outcome.fail(a.action() + ": " + e.getClass().getSimpleName() + " " + e.getMessage()); }
        return ActionHandler.Outcome.OK;
    }

    // ------------------------------------------------------------------ attack
    /** Also used by WeaponModule for weapon_attack. */
    ActionHandler.Outcome attack(Spec.Action a, ProductionContext c, boolean weapon) {
        Params p = a.params(); Actor atk = actor(a.actor(), "attacker"), tgt = actor(p.str("target", ""), "target");
        double reach = p.dbl("reach", weapon ? 2.7 : 1.9);
        double want = CombatGeometry.wantedDistance(reach, tgt.radius());   // centre distance at which the strike touches the target's surface
        atk.motion().faceTarget(tgt::pos);
        double dist = atk.pos().distXZ(tgt.pos());
        int impact = Math.max(1, (int) Math.round(p.dbl("impact", 0.3) * 20));
        if (p.bool("move_in", true) && CombatGeometry.needsRepositioning(dist, want)) {   // step in (or back off): never from across the room, never inside a giant
            Vec3 to = CombatGeometry.stepInPoint(atk.pos(), tgt.pos(), want);
            atk.move(new MotionPlan.Linear(atk.pos(), to, CombatGeometry.stepInTicks(impact), Ease.OUT_QUAD), false, null);
        }
        String anim = p.str("anim", null);
        if (anim != null) atk.play(anim, 2, false);
        final String result = p.str("result", "hit"); final String type = p.str("type", a.action());
        later(impact, () -> impact(c, a, atk, tgt, want, result, type, weapon));
        return ActionHandler.Outcome.OK;
    }

    private void impact(ProductionContext c, Spec.Action a, Actor atk, Actor tgt, double want, String result, String type, boolean weapon) {
        double gap = atk.pos().distXZ(tgt.pos());
        if (!result.equals("dodged") && CombatGeometry.missesGeometrically(gap, want))
            plugin.getLogger().warning("CHOREOGRAPHY: " + a.where() + " result=" + result + " but the attacker is " + String.format("%.1f", gap) + " blocks from the target (needs about " + String.format("%.1f", want) + "): the blow would not connect. Adjust positions/timing in the scene file.");
        Vec3 dir = flat(tgt.pos().minus(atk.pos())).normalizedXZ();
        Vec3 hit = new Vec3(tgt.pos().x() - dir.x() * Math.max(0.2, tgt.radius() * 0.9), tgt.pos().y() + tgt.chest(), tgt.pos().z() - dir.z() * Math.max(0.2, tgt.radius() * 0.9));
        Location at = c.abs(hit); Params ip = a.params();
        Location ground = c.abs(new Vec3(hit.x(), tgt.pos().y() + 0.15, hit.z()));
        switch (result) {
            case "hit", "countered" -> {
                spawn(c, Particle.CRIT, at, 45, 0.5, 0.5, 0.5, 0.5); spawn(c, Particle.EXPLOSION, at, 1, 0, 0, 0, 0); spawn(c, weapon ? Particle.SWEEP_ATTACK : Particle.DAMAGE_INDICATOR, at, 4, 0.4, 0.3, 0.4, 0);
                Fx.dust(c.world(), at, 40, 0.55, 0x8A4DFF, 1.8f); spawn(c, Particle.SOUL_FIRE_FLAME, at, 18, 0.3, 0.3, 0.3, 0.18);
                ring(c, ground, 2.8, 0.35); sound(c, at, 1.3f, weapon ? 0.8f : 1.0f); stop(ip, weapon ? 3 : 2); }
            case "blocked" -> { spawn(c, Particle.ELECTRIC_SPARK, at, 55, 0.6, 0.6, 0.6, 0.35); spawn(c, Particle.CRIT, at, 18, 0.35, 0.35, 0.35, 0.25); Fx.dust(c.world(), at, 18, 0.4, 0xC9A8FF, 1.4f); ring(c, ground, 1.8, 0.25); sound(c, at, 0.9f, 1.25f); stop(ip, 1); }
            case "dodged" -> { Location air = c.abs(new Vec3(atk.pos().x() + dir.x() * 1.2, atk.pos().y() + atk.chest(), atk.pos().z() + dir.z() * 1.2)); spawn(c, Particle.CLOUD, air, 14, 0.35, 0.2, 0.35, 0.06); if (weapon) spawn(c, Particle.SWEEP_ATTACK, air, 3, 0.5, 0.3, 0.5, 0); c.world().playSound(air, "minecraft:entity.player.attack.sweep", SoundCategory.MASTER, 1.4f, 0.7f); }
            case "clashed" -> { spawn(c, Particle.FLASH, at, 1, 0, 0, 0, 0); spawn(c, Particle.ELECTRIC_SPARK, at, 90, 0.8, 0.8, 0.8, 0.6); Fx.dust(c.world(), at, 50, 0.7, 0xB88CFF, 2.0f); ring(c, ground, 4.0, 0.4); c.world().playSound(at, "minecraft:item.shield.break", SoundCategory.MASTER, 2.2f, 0.55f); sound(c, at, 1.4f, 0.7f); stop(ip, 3); }
            default -> plugin.getLogger().warning(a.where() + ": unknown result '" + result + "' (use hit, blocked, dodged, clashed)");
        }
    }
    private void stop(Params p, int dflt) { if (presentation != null) presentation.hitstop(p.integer("hitstop", dflt)); }
    /** Ground ring of dust + block debris particles at an impact. */
    private void ring(ProductionContext c, Location at, double r, double speed) {
        int pts = (int) Math.min(40, 14 + r * 6);
        for (int i = 0; i < pts; i++) { double ang = i * Math.PI * 2 / pts; spawn(c, Particle.CLOUD, at.clone().add(Math.cos(ang) * 0.4, 0, Math.sin(ang) * 0.4), 0, Math.cos(ang) * speed, 0.05, Math.sin(ang) * speed, 1.0); if (i % 3 == 0) Fx.spawn(c.world(), Particle.BLOCK, at.clone().add(Math.cos(ang) * r * 0.5, 0.1, Math.sin(ang) * r * 0.5), 3, 0.15, 0.1, 0.15, 0.05); }
    }
    /** Plays the production's 'combat_impacts' sound slot at the impact (positional, audience in range only). */
    private void sound(ProductionContext c, Location at, float vol, float pitch) {
        Object so = c.productionRaw().get("sounds"); if (!(so instanceof Map<?, ?> m) || !(m.get("combat_impacts") instanceof Map<?, ?> d) || d.get("event") == null) return;
        for (org.bukkit.entity.Player pl : c.audience()) pl.playSound(at, String.valueOf(d.get("event")), SoundCategory.MASTER, vol, pitch);
    }
    private void spawn(ProductionContext c, Particle p, Location l, int n, double dx, double dy, double dz, double speed) { int k = Math.min(n, Math.max(1, particleBudget)); particleBudget -= k; Fx.spawn(c.world(), p, l, k, dx, dy, dz, speed); }

    // ------------------------------------------------------------------ defence & movement
    private void block(Spec.Action a) {
        Actor d = actor(a.actor(), "actor"); String t = a.params().str("target", null);
        if (t != null) d.motion().faceTarget(actor(t, "target")::pos);
        d.play(a.params().str("anim", "block"), 2, false, Math.max(6, a.durationTicks()));
    }
    private void dodge(Spec.Action a) {
        Actor d = actor(a.actor(), "actor"); Params p = a.params(); String t = p.str("target", null);
        if (t != null) d.motion().faceTarget(actor(t, "target")::pos);
        d.move(new MotionPlan.Linear(d.pos(), p.vec("to"), Math.max(3, a.durationTicks()), Ease.OUT_QUAD), false, null);
        d.play(p.str("anim", "dodge"), 2, false, Math.max(6, a.durationTicks()));
        Vec3 from = d.pos(); later(0, () -> { if (ctxNow != null) spawn(ctxNow, Particle.PORTAL, ctxNow.abs(new Vec3(from.x(), from.y() + d.chest(), from.z())), 25, 0.3, 0.6, 0.3, 0.4); });
    }
    private ProductionContext ctxNow;

    private void clash(Spec.Action a, ProductionContext c) {
        Params p = a.params(); Actor x = actor(a.actor(), "actor"), y = actor(p.str("target", ""), "target"); Vec3 at = p.vec("at");
        x.motion().faceTarget(y::pos); y.motion().faceTarget(x::pos);
        if (p.has("anim")) x.play(p.str("anim", ""), 2, false, Math.max(6, a.durationTicks()));
        Vec3 axis = flat(x.pos().minus(y.pos())).normalizedXZ();
        later(2, () -> {                      // the weapons meet at 'at': sparks, flash, then both are driven apart
            Location l = c.abs(at); spawn(c, Particle.FLASH, l, 1, 0, 0, 0, 0); spawn(c, Particle.ELECTRIC_SPARK, l, 80, 0.7, 0.7, 0.7, 0.6); spawn(c, Particle.END_ROD, l, 30, 0.5, 0.5, 0.5, 0.25);
            c.world().playSound(l, "minecraft:item.shield.break", SoundCategory.MASTER, 2.5f, 0.5f);
            x.move(new MotionPlan.Linear(x.pos(), new Vec3(x.pos().x() + axis.x() * 0.7, x.pos().y(), x.pos().z() + axis.z() * 0.7), 6, Ease.OUT_QUAD), false, null);
            y.move(new MotionPlan.Linear(y.pos(), new Vec3(y.pos().x() - axis.x() * 0.7, y.pos().y(), y.pos().z() - axis.z() * 0.7), 6, Ease.OUT_QUAD), false, null);
        });
    }

    private void area(Spec.Action a, ProductionContext c) {
        Params p = a.params(); Actor x = actor(a.actor(), "actor"); Vec3 at = p.vec("at"); double r = p.dbl("radius", 4);
        if (p.has("anim")) x.play(p.str("anim", ""), 2, false);
        int impact = Math.max(1, (int) Math.round(p.dbl("impact", 0.4) * 20));
        later(impact, () -> { for (int i = 0; i < 48; i++) { double ang = i * Math.PI * 2 / 48; spawn(c, Particle.SWEEP_ATTACK, c.abs(new Vec3(at.x() + Math.cos(ang) * r, at.y() + 0.6, at.z() + Math.sin(ang) * r)), 1, 0, 0, 0, 0); } spawn(c, Particle.EXPLOSION, c.abs(new Vec3(at.x(), at.y() + 0.6, at.z())), 3, r * 0.3, 0.2, r * 0.3, 0); });
    }

    private void teleportAttack(Spec.Action a, ProductionContext c) {
        Params p = a.params(); Actor atk = actor(a.actor(), "attacker"), tgt = actor(p.str("target", ""), "target");
        double want = p.dbl("reach", 2.7) + tgt.radius();
        double fy = Math.toRadians(tgt.yaw()); Vec3 fwd = new Vec3(-Math.sin(fy), 0, Math.cos(fy));       // direction the target faces
        double s = p.bool("behind", false) ? -1 : 1;
        Vec3 to = new Vec3(tgt.pos().x() + fwd.x() * want * s, atk.pos().y(), tgt.pos().z() + fwd.z() * want * s);
        spawn(c, Particle.REVERSE_PORTAL, c.abs(new Vec3(atk.pos().x(), atk.pos().y() + atk.chest(), atk.pos().z())), 50, 0.3, 0.7, 0.3, 0.5);
        atk.motion().teleport(to);
        spawn(c, Particle.REVERSE_PORTAL, c.abs(new Vec3(to.x(), to.y() + atk.chest(), to.z())), 50, 0.3, 0.7, 0.3, 0.5);
        c.world().playSound(c.abs(to), "minecraft:entity.enderman.teleport", SoundCategory.MASTER, 1.5f, 0.6f);
        Map<String, Object> raw = new LinkedHashMap<>(p.raw()); raw.put("move_in", false);
        attack(new Spec.Action(a.production(), a.scene(), a.index(), a.tick(), a.actor(), a.action(), new Params(raw), a.durationTicks(), a.critical()), c, true);
    }

    // ------------------------------------------------------------------ projectiles
    private void projectile(Spec.Action a, ProductionContext c) {
        Params p = a.params(); Actor x = actor(a.actor(), "actor"); String kind = p.str("impact_effect", "crescent");
        if (p.has("anim")) x.play(p.str("anim", ""), 2, false);
        Vec3 from = new Vec3(x.pos().x(), x.pos().y() + x.chest(), x.pos().z()), to = p.vec("to");
        int dur = Math.max(2, a.durationTicks()); final int[] t = {0};
        Vec3 dir = to.minus(from); double len = dir.length(); Vec3 unit = len < 1e-6 ? new Vec3(0, 0, 1) : dir.scale(1.0 / len);
        Vec3 side = new Vec3(-unit.z(), 0, unit.x());
        effects.add(() -> {
            double f = (t[0] + 1.0) / dur; Vec3 head = from.lerp(to, f);
            switch (kind) {
                case "ultimate_beam" -> { int n = 36; for (int i = 0; i < n; i++) { Vec3 q = from.lerp(head, (double) i / n); spawn(c, Particle.END_ROD, c.abs(q), 2, 0.5, 0.5, 0.5, 0.02); } spawn(c, Particle.REVERSE_PORTAL, c.abs(head), 18, 0.9, 0.9, 0.9, 0.2); spawn(c, Particle.SOUL_FIRE_FLAME, c.abs(head), 10, 0.6, 0.6, 0.6, 0.05); }
                case "crescent" -> { for (int i = -6; i <= 6; i++) { double off = i * 0.18, back = Math.abs(i) * 0.12; Vec3 q = new Vec3(head.x() + side.x() * off - unit.x() * back, head.y() + 0.0, head.z() + side.z() * off - unit.z() * back); spawn(c, Particle.SOUL_FIRE_FLAME, c.abs(q), 1, 0.02, 0.02, 0.02, 0.0); } spawn(c, Particle.SWEEP_ATTACK, c.abs(head), 1, 0, 0, 0, 0); }
                default -> { spawn(c, Particle.FLAME, c.abs(head), 12, 0.2, 0.2, 0.2, 0.02); spawn(c, Particle.SMOKE, c.abs(head), 4, 0.15, 0.15, 0.15, 0.01); }
            }
            if (++t[0] >= dur) {
                Location l = c.abs(to);
                switch (kind) { case "ultimate_beam" -> { spawn(c, Particle.EXPLOSION_EMITTER, l, 1, 0, 0, 0, 0); spawn(c, Particle.FLASH, l, 1, 0, 0, 0, 0); } case "crescent" -> { spawn(c, Particle.CRIT, l, 30, 0.6, 0.6, 0.6, 0.4); spawn(c, Particle.EXPLOSION, l, 1, 0, 0, 0, 0); } default -> { spawn(c, Particle.EXPLOSION, l, 2, 0.4, 0.4, 0.4, 0); spawn(c, Particle.CLOUD, l, 20, 0.5, 0.5, 0.5, 0.1); } }
                return true;
            }
            return false; });
    }

    // ------------------------------------------------------------------ per tick
    @Override public void tick(ProductionContext c, int sceneTick, int globalTick) {
        if (paused) return; now++; ctxNow = c; particleBudget = plugin.getConfig().getInt("performance.max-particles-per-tick", 600) / 2;
        List<Due> ready = new ArrayList<>();
        for (Iterator<Due> it = due.iterator(); it.hasNext(); ) { Due d = it.next(); if (d.tick() <= now) { ready.add(d); it.remove(); } }
        for (Due d : ready) { try { d.run().run(); } catch (RuntimeException e) { plugin.getLogger().severe("combat event failed: " + e); } }
        effects.removeIf(Effect::tick);
    }
    @Override public boolean busy() { return !due.isEmpty() || !effects.isEmpty(); }
    @Override public void pause() { paused = true; }
    @Override public void resume() { paused = false; }
    @Override public void cleanup(boolean restoreWorld) { due.clear(); effects.clear(); }
}
