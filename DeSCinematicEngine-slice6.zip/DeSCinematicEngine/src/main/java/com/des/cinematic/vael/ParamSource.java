package com.des.cinematic.vael;

/** Anything that can supply the rig's continuous pose parameters (indices in {@link P}). */
public interface ParamSource { float get(int param); }
