package com.des.cinematic.rig;

/** Minimal quaternion + rigid transform maths (no JOML dependency so the solver is unit-testable offline). */
public record Quat(double x, double y, double z, double w) {
    public static final Quat ID = new Quat(0, 0, 0, 1);
    public static Quat axis(double ax, double ay, double az, double deg) {
        double h = Math.toRadians(deg) / 2, s = Math.sin(h); return new Quat(ax * s, ay * s, az * s, Math.cos(h));
    }
    public Quat mul(Quat o) {
        return new Quat(w * o.x + x * o.w + y * o.z - z * o.y, w * o.y - x * o.z + y * o.w + z * o.x,
                        w * o.z + x * o.y - y * o.x + z * o.w, w * o.w - x * o.x - y * o.y - z * o.z);
    }
    public double[] rotate(double vx, double vy, double vz) {
        // v' = q * v * q^-1
        double tx = 2 * (y * vz - z * vy), ty = 2 * (z * vx - x * vz), tz = 2 * (x * vy - y * vx);
        return new double[]{vx + w * tx + (y * tz - z * ty), vy + w * ty + (z * tx - x * tz), vz + w * tz + (x * ty - y * tx)};
    }
    /** Rigid transform: rotate then translate. */
    public record Xf(Quat q, double tx, double ty, double tz) {
        public static final Xf ID = new Xf(Quat.ID, 0, 0, 0);
        public Xf mul(Xf o) { double[] p = q.rotate(o.tx, o.ty, o.tz); return new Xf(q.mul(o.q), tx + p[0], ty + p[1], tz + p[2]); }
        public static Xf t(double x, double y, double z) { return new Xf(Quat.ID, x, y, z); }
        public static Xf r(Quat q) { return new Xf(q, 0, 0, 0); }
    }
}
