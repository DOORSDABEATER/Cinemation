package com.des.cinematic.rig;

import com.des.cinematic.core.*;
import com.des.cinematic.vael.P;

import java.util.*;

/**
 * Parses parameter clips: a shared 'base' pose (every channel's neutral value) plus clips of sparse keys. Channel names: see NAMES.
 * 4-armed channels (arm_raise, arm_spread, fore_bend) take a scalar (all four arms) or a list of 4 [UL, UR, LL, LR].
 */
public final class ParamClipLibrary {
    /** name -> first index, and width (4 for arm channels). */
    public static final Map<String, int[]> NAMES = new LinkedHashMap<>();
    static {
        NAMES.put("torso_pitch", new int[]{P.TORSO_PITCH, 1}); NAMES.put("torso_roll", new int[]{P.TORSO_ROLL, 1}); NAMES.put("lean", new int[]{P.LEAN, 1}); NAMES.put("sink", new int[]{P.SINK, 1});
        NAMES.put("arm_raise", new int[]{P.ARM_RAISE, 4}); NAMES.put("arm_spread", new int[]{P.ARM_SPREAD, 4}); NAMES.put("fore_bend", new int[]{P.FORE_BEND, 4});
        NAMES.put("halo_speed", new int[]{P.HALO_SPEED, 1}); NAMES.put("halo_radius", new int[]{P.HALO_RADIUS, 1}); NAMES.put("halo_tilt", new int[]{P.HALO_TILT, 1});
        NAMES.put("frag_radius", new int[]{P.FRAG_RADIUS, 1}); NAMES.put("frag_speed", new int[]{P.FRAG_SPEED, 1}); NAMES.put("frag_bob", new int[]{P.FRAG_BOB, 1});
        NAMES.put("core_scale", new int[]{P.CORE_SCALE, 1}); NAMES.put("core_pulse", new int[]{P.CORE_PULSE, 1}); NAMES.put("hover_amp", new int[]{P.HOVER_AMP, 1}); NAMES.put("hover_hz", new int[]{P.HOVER_HZ, 1});
        NAMES.put("body_scale", new int[]{P.BODY_SCALE, 1}); NAMES.put("glow", new int[]{P.GLOW, 1});
    }
    private final Map<String, ParamClip> clips = new LinkedHashMap<>();
    public Optional<ParamClip> get(String id) { return Optional.ofNullable(clips.get(id)); }
    public Set<String> ids() { return clips.keySet(); }

    @SuppressWarnings("unchecked")
    public List<Issue> load(Map<String, Object> root) {
        List<Issue> issues = new ArrayList<>();
        float[] base = new float[P.COUNT];
        if (!applyChannels(base, root.get("base") instanceof Map<?, ?> bm ? (Map<String, Object>) bm : Map.of(), "base", issues)) return issues;
        if (!(root.get("clips") instanceof Map<?, ?> cs)) { issues.add(Issue.error("clips", "missing 'clips' map")); return issues; }
        for (Map.Entry<?, ?> e : cs.entrySet()) {
            String id = String.valueOf(e.getKey()); Map<String, Object> cm = (Map<String, Object>) e.getValue(); Params p = new Params(cm);
            double dur = p.dbl("duration", 0) * 20.0; if (dur <= 0) { issues.add(Issue.error("clip " + id, "duration must be > 0")); continue; }
            List<ParamClip.Key> keys = new ArrayList<>(); boolean ok = true;
            if (!(cm.get("keys") instanceof List<?> kl) || kl.isEmpty()) { issues.add(Issue.error("clip " + id, "no keys")); continue; }
            for (Object ko : kl) {
                Map<String, Object> km = (Map<String, Object>) ko; float[] v = base.clone();
                Map<String, Object> ch = new LinkedHashMap<>(km); ch.remove("t");
                if (!applyChannels(v, ch, "clip " + id, issues)) ok = false;
                keys.add(new ParamClip.Key(new Params(km).dbl("t", 0) * 20.0, v));
            }
            if (ok) clips.put(id, new ParamClip(id, dur, p.bool("loop", false), p.ease("ease", Ease.IN_OUT_QUAD), keys));
        }
        return issues;
    }

    private static boolean applyChannels(float[] v, Map<String, Object> ch, String where, List<Issue> issues) {
        boolean ok = true;
        for (Map.Entry<String, Object> e : ch.entrySet()) {
            int[] spec = NAMES.get(e.getKey());
            if (spec == null) { issues.add(Issue.error(where, "unknown channel '" + e.getKey() + "'")); ok = false; continue; }
            Object o = e.getValue();
            if (o instanceof Number n) { for (int i = 0; i < spec[1]; i++) v[spec[0] + i] = n.floatValue(); }
            else if (o instanceof List<?> l && l.size() == spec[1] && l.stream().allMatch(x -> x instanceof Number)) { for (int i = 0; i < spec[1]; i++) v[spec[0] + i] = ((Number) l.get(i)).floatValue(); }
            else { issues.add(Issue.error(where, "channel '" + e.getKey() + "' needs a number" + (spec[1] == 4 ? " or a list of 4" : ""))); ok = false; }
        }
        return ok;
    }
}
