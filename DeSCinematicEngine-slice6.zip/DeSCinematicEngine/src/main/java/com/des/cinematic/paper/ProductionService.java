package com.des.cinematic.paper;

import com.des.cinematic.api.*;
import com.des.cinematic.core.*;
import org.bukkit.Bukkit;
import org.bukkit.World;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.scheduler.BukkitTask;

import java.util.*;
import java.util.logging.Level;

/** Owns the (single, by default) active production and the per-tick scheduler task. Main-thread only. */
public final class ProductionService implements CinematicApi {
    private final JavaPlugin plugin; private final ProductionLibrary library;
    private final List<ActionModule> modules = new ArrayList<>();
    private TimelineRunner runner; private BukkitTask task; private String activeId; private ProductionContext activeCtx; private RunLog runLog;

    public ProductionService(JavaPlugin plugin, ProductionLibrary library) { this.plugin = plugin; this.library = library; }
    public ProductionLibrary library() { return library; }
    public List<ActionModule> modules() { return Collections.unmodifiableList(modules); }

    @Override public void registerModule(ActionModule m) {
        modules.removeIf(x -> x.id().equals(m.id()));
        modules.add(m);
        plugin.getLogger().info("Registered action module '" + m.id() + "' for " + m.categories());
    }
    @Override public List<String> productionIds() { return new ArrayList<>(library.ids()); }
    @Override public Optional<String> activeProduction() { return runner != null && runner.active() ? Optional.of(activeId) : Optional.empty(); }
    @Override public String status() { return runner == null ? "IDLE" : activeId + " " + runner.status() + (runner.failureReason() != null ? " | FAILED: " + runner.failureReason() : ""); }

    /** Static validation plus every module's asset validation. */
    public List<Issue> validate(String id) {
        ProductionLibrary.Loaded l = library.get(id).orElse(null);
        if (l == null) return List.of(Issue.error(id, "unknown production"));
        List<Issue> out = new ArrayList<>(library.validate(l));
        for (ActionModule m : modules) out.addAll(m.validate(l.spec(), l.actorDefs(), l.weaponDefs()));
        if (modules.isEmpty()) out.add(Issue.warn(id, "no action modules are registered: nothing could execute this production"));
        else {
            Set<ActionCatalog.Category> used = new HashSet<>(), have = new HashSet<>();
            for (Spec.Scene s : l.spec().scenes()) for (Spec.Action a : s.actions()) ActionCatalog.get(a.action()).ifPresent(d -> used.add(d.category()));
            for (ActionModule m : modules) have.addAll(m.categories());
            used.remove(ActionCatalog.Category.FLOW);
            for (ActionCatalog.Category c : used) if (!have.contains(c)) out.add(Issue.error(id, "production uses " + c + " actions but no module handles them"));
        }
        return out;
    }

    @Override public Started start(String id) { return start(id, null); }

    @Override public Started start(String id, String untilScene) {
        if (runner != null && runner.active() && !plugin.getConfig().getBoolean("engine.allow-concurrent-productions", false))
            return new Started(StartResult.ALREADY_RUNNING, "production '" + activeId + "' is already running");
        for (ActionModule m : modules) { String why = m.preflight(id); if (why != null) return new Started(StartResult.ERROR, m.id() + ": " + why); }
        ProductionLibrary.Loaded l = library.get(id).orElse(null);
        if (l == null) return new Started(StartResult.UNKNOWN_PRODUCTION, "unknown production '" + id + "'");
        List<Issue> issues = validate(id);
        if (Validator.hasErrors(issues)) return new Started(StartResult.INVALID, issues.stream().filter(i -> i.severity() == Issue.Severity.ERROR).count() + " validation error(s); run /descinematic validate " + id);
        World w = Bukkit.getWorld(l.spec().world());
        if (w == null) return new Started(StartResult.WORLD_MISSING, "world '" + l.spec().world() + "' is not loaded");
        try {
            Vec3 o = l.spec().origin();
            org.bukkit.Location origin = new org.bukkit.Location(w, o.x(), o.y(), o.z());
            activeCtx = new ProductionContext(plugin, l.spec(), w, origin, l.actorDefs(), l.weaponDefs(), plugin.getConfig().getDouble("engine.audience-radius", 128), l.raw());
            try { runLog = new RunLog(new java.io.File(plugin.getDataFolder(), "logs"), id); } catch (java.io.IOException e) { runLog = null; plugin.getLogger().warning("cannot create run log: " + e.getMessage()); }
            ModuleDispatcher disp = new ModuleDispatcher(activeCtx, modules, plugin.getConfig().getBoolean("engine.log-every-action", false), plugin.getLogger(), runLog);
            runner = new TimelineRunner(l.spec(), disp, listener(), plugin.getConfig().getInt("engine.scene-grace-ticks", 200));
            runner.abortOnCriticalFailure(plugin.getConfig().getBoolean("engine.abort-on-critical-failure", false));
            activeId = id;
            if (untilScene != null) {
                int idx = -1; for (int i = 0; i < l.spec().scenes().size(); i++) if (l.spec().scenes().get(i).id().equals(untilScene)) idx = i;
                if (idx < 0) { runner = null; return new Started(StartResult.INVALID, "unknown scene '" + untilScene + "' (scenes: " + l.spec().scenes().stream().map(Spec.Scene::id).toList() + ")"); }
                runner.stopAfterScene(idx);
            }
            runner.start();
            task = Bukkit.getScheduler().runTaskTimer(plugin, this::tickSafely, 1L, 1L);
            plugin.getLogger().info("Production '" + id + "' started (" + String.format("%.1f", l.spec().totalTicks() / 20.0) + "s scheduled).");
            return new Started(StartResult.STARTED, "started '" + id + "'");
        } catch (RuntimeException e) {
            plugin.getLogger().log(Level.SEVERE, "start failed for " + id, e);
            stop(true);
            return new Started(StartResult.ERROR, e.toString());
        }
    }

    private void tickSafely() {
        try { runner.tick(); }
        catch (Throwable t) { plugin.getLogger().log(Level.SEVERE, "tick failure in '" + activeId + "' at " + runner.status() + " - aborting and cleaning up", t); stop(true); }
        if (runner != null && !runner.active()) cancelTask();
    }
    private void cancelTask() { if (task != null) { task.cancel(); task = null; } }

    @Override public boolean stop(boolean restoreWorld) {
        cancelTask();
        if (runner == null || !runner.active()) return false;
        runner.stop(restoreWorld);
        return true;
    }
    @Override public boolean pause() { if (runner != null && runner.state() == TimelineRunner.State.RUNNING) { runner.pause(); return true; } return false; }
    @Override public boolean resume() { if (runner != null && runner.state() == TimelineRunner.State.PAUSED) { runner.resume(); return true; } return false; }

    public void reset(String id) {
        if (activeProduction().filter(id::equals).isPresent()) stop(true);
        for (ActionModule m : modules) m.reset(id);
    }
    public void shutdown() {
        stop(true);
        for (ActionModule m : modules) { try { m.shutdown(); } catch (RuntimeException e) { plugin.getLogger().severe("module '" + m.id() + "' shutdown failed: " + e); } }
    }

    /** Dry run: returns the timeline as text, executing nothing. */
    public List<String> preview(String id) {
        ProductionLibrary.Loaded l = library.get(id).orElse(null);
        if (l == null) return List.of("unknown production '" + id + "'");
        DryRunHandler h = new DryRunHandler();
        TimelineRunner r = new TimelineRunner(l.spec(), h, new TimelineRunner.Listener() {}, 0);
        r.start();
        int guard = 0;
        while (r.active() && guard++ < 20 * 60 * 60) r.tick();
        h.lines.add(String.format("TOTAL %.1fs over %d scene(s)", r.globalTick() / 20.0, l.spec().scenes().size()));
        return h.lines;
    }

    private TimelineRunner.Listener listener() {
        return new TimelineRunner.Listener() {
            public void onSceneStart(Spec.Scene s) { plugin.getLogger().info("[" + activeId + "] scene start: " + s.id()); }
            public void onSceneEnd(Spec.Scene s) { plugin.getLogger().info("[" + activeId + "] scene end: " + s.id()); }
            public void onActionFailed(Spec.Action a, String reason, boolean aborting) {
                plugin.getLogger().severe("ACTION FAILED " + a.where() + " -> " + reason + (aborting ? "  (critical: aborting production)" : "  (non-critical: continuing)"));
            }
            public void onWarning(String msg) { plugin.getLogger().warning("[" + activeId + "] " + msg); }
            public void onFinished(TimelineRunner.State s) {
                plugin.getLogger().info("[" + activeId + "] finished: " + s);
                java.util.List<String> fails = runner == null ? java.util.List.of() : runner.failures();
                String where = runLog == null ? "" : " Run log: plugins/DeSCinematicEngine/logs/" + runLog.file.getName();
                if (runLog != null) { runLog.line("FINISHED " + s + " failures=" + fails.size()); fails.forEach(f -> runLog.line("  FAIL " + f)); runLog.close(); }
                String msg = "Production '" + activeId + "' " + s + (fails.isEmpty() ? " with no action failures." : " with " + fails.size() + " failed action(s); first: " + fails.get(0)) + where;
                plugin.getLogger().info(msg);
                for (org.bukkit.entity.Player p : Bukkit.getOnlinePlayers()) if (p.isOp()) p.sendMessage(net.kyori.adventure.text.Component.text(msg, fails.isEmpty() ? net.kyori.adventure.text.format.NamedTextColor.GREEN : net.kyori.adventure.text.format.NamedTextColor.YELLOW));
            }
        };
    }
}
