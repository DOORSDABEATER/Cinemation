package com.des.cinematic.paper;

import com.des.cinematic.core.ActionHandler;
import com.des.cinematic.core.Spec;

import java.util.ArrayList;
import java.util.List;

/** /descinematic preview: executes the schedule with no entities or blocks, to verify order and timing. */
final class DryRunHandler implements ActionHandler {
    final List<String> lines = new ArrayList<>();
    @Override public Outcome begin(Spec.Action a) { lines.add(String.format("  %6.2fs  %-20s %-14s %s", a.tick() / 20.0, a.action(), a.actor() == null ? "-" : a.actor(), a.params().raw().keySet())); return Outcome.OK; }
    @Override public void tick(int s, int g) {}
    @Override public boolean busy() { return false; }
    @Override public void sceneStarted(Spec.Scene s) { lines.add("SCENE " + s.id() + "  (" + s.name() + ", " + String.format("%.1fs", s.endTick() / 20.0) + ", " + s.actions().size() + " actions)"); }
    @Override public void sceneEnded(Spec.Scene s) {}
    @Override public void pause() {}
    @Override public void resume() {}
    @Override public void cleanup(boolean restoreWorld) {}
}
