package com.des.cinematic.rig;

import com.des.cinematic.core.Ease;
import java.util.*;

/** Keyframed animation. Times in ticks. Poses between keys are eased; looping clips wrap from the last key to the first. */
public final class Clip {
    public record Key(double tick, Pose pose) {}
    private final String id; private final double durationTicks; private final boolean loop; private final Ease ease; private final List<Key> keys;

    public Clip(String id, double durationTicks, boolean loop, Ease ease, List<Key> keys) {
        if (keys.isEmpty()) throw new IllegalArgumentException("clip '" + id + "' has no keys");
        this.id = id; this.durationTicks = Math.max(1, durationTicks); this.loop = loop; this.ease = ease;
        List<Key> k = new ArrayList<>(keys); k.sort(Comparator.comparingDouble(Key::tick)); this.keys = List.copyOf(k);
    }
    public String id() { return id; }
    public double duration() { return durationTicks; }
    public boolean loops() { return loop; }
    public List<Key> keys() { return keys; }

    public Pose sample(double t) {
        if (loop) t = ((t % durationTicks) + durationTicks) % durationTicks; else t = Math.max(0, Math.min(durationTicks, t));
        Key first = keys.get(0), last = keys.get(keys.size() - 1);
        if (!loop) { if (t <= first.tick()) return first.pose().copy(); if (t >= last.tick()) return last.pose().copy(); }
        Key a = null, b = null;
        for (int i = 0; i < keys.size(); i++) if (keys.get(i).tick() <= t) a = keys.get(i);
        for (int i = keys.size() - 1; i >= 0; i--) if (keys.get(i).tick() > t) b = keys.get(i);
        double at, bt; Pose ap, bp;
        if (a == null) { a = last; at = last.tick() - durationTicks; } else at = a.tick();
        if (b == null) { b = first; bt = first.tick() + durationTicks; } else bt = b.tick();
        ap = a.pose(); bp = b.pose();
        double f = bt - at < 1e-9 ? 1 : (t - at) / (bt - at);
        return Pose.lerp(ap, bp, ease.apply(f));
    }
}
