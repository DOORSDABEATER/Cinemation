package com.des.cinematic.paper;

import com.des.cinematic.api.ActionModule;
import com.des.cinematic.api.ProductionContext;
import com.des.cinematic.api.TimeScaled;
import com.des.cinematic.core.*;
import io.papermc.paper.entity.TeleportFlag;
import org.bukkit.*;
import org.bukkit.entity.ItemDisplay;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.util.RayTraceResult;
import org.bukkit.util.Transformation;
import org.bukkit.util.Vector;
import org.joml.Quaternionf;
import org.joml.Vector3f;

import java.io.InputStreamReader;
import java.util.*;

/**
 * WEAPON actions: pedestal display, taking, stowing, multi-stage summoning from real sub-models, equipping, trails, cracking and a
 * physical shatter into 24 fragments that fly, land and PERSIST on the battlefield. All geometry comes from the existing weapon models
 * (see tools/split_model.py); nothing is redesigned.
 */
public final class WeaponModule implements ActionModule, TimeScaled {
    private enum St { HIDDEN, PEDESTAL, FLYING, HELD, ASSEMBLING, FLOATING, CRACKING, SHATTERED }
    private record Tgt(Location loc, Quaternionf q, float scale) {}
    private static final class Part { ItemDisplay d; Vector3f c = new Vector3f(); Vector3f off = new Vector3f(); Quaternionf rot0 = new Quaternionf(); int group; String name; }
    private static final class Frag {
        ItemDisplay d; Vector3f c = new Vector3f(); org.joml.Vector3d p = new org.joml.Vector3d(), v = new org.joml.Vector3d(); Quaternionf q = new Quaternionf(); Vector3f spin = new Vector3f();
        boolean landed; double floor; int recheck; Vec3 dir;
    }
    private final class W {
        String id; Map<String, Object> def; St st = St.HIDDEN; ItemDisplay whole; List<Part> parts = new ArrayList<>(); List<Frag> frags = new ArrayList<>();
        Vec3 free; Actor holder; String anchor = "hand_r"; Params hold; int t, dur; Location from; Quaternionf fromQ = new Quaternionf(); float fromScale = 1f; boolean stowAfter;
        List<int[]> stages = new ArrayList<>(); List<String> stageNames = new ArrayList<>(); float gap; int crackStage; Params crackP; Random rnd;
    }

    private final JavaPlugin plugin; private final ActorModule actors; private final EnvironmentModule env; private CombatModule combat;
    private final Map<String, W> weapons = new LinkedHashMap<>(); private final Map<String, Map<String, Object>> metaCache = new HashMap<>();
    private final List<Runnable[]> trails = new ArrayList<>(); private final List<int[]> trailTimers = new ArrayList<>();
    private double timeScale = 1.0; private boolean paused; private ProductionContext ctx; private int now; private int particleBudget;

    public WeaponModule(JavaPlugin plugin, ActorModule actors, EnvironmentModule env) { this.plugin = plugin; this.actors = actors; this.env = env; }
    public void setCombat(CombatModule c) { this.combat = c; }
    @Override public String id() { return "weapons"; }
    @Override public Set<ActionCatalog.Category> categories() { return EnumSet.of(ActionCatalog.Category.WEAPON); }
    @Override public void timeScale(double s) { timeScale = Math.max(0, s); }
    @Override public void productionStarted(ProductionContext c) { ctx = c; paused = false; now = 0; timeScale = 1.0; }

    // ------------------------------------------------------------------ validation
    @SuppressWarnings("unchecked")
    @Override public List<Issue> validate(Spec.Production p, Map<String, Map<String, Object>> actorDefs, Map<String, Map<String, Object>> weaponDefs) {
        List<Issue> out = new ArrayList<>();
        for (String id : p.weapons()) {
            Map<String, Object> def = weaponDefs.get(id); String w = "weapons/" + id + ".yml";
            if (def == null) continue;
            if (!(def.get("item_model") instanceof String s) || NamespacedKey.fromString(s) == null) out.add(Issue.error(w, "item_model must be a namespaced key"));
            if (def.get("parts_file") instanceof String pf) {
                Map<String, Object> meta = parts(pf, out, w);
                if (meta != null) {
                    int nf = meta.get("fragments") instanceof List<?> l ? l.size() : 0;
                    out.add(Issue.info(w, "parts metadata OK: " + (meta.get("parts") instanceof Map<?, ?> m ? m.size() : 0) + " assembly parts, " + nf + " fragments (generated from the existing model by tools/split_model.py)"));
                }
            }
        }
        return out;
    }
    @SuppressWarnings("unchecked")
    private Map<String, Object> parts(String path, List<Issue> issues, String where) {
        Map<String, Object> c = metaCache.get(path); if (c != null) return c;
        try (var in = plugin.getResource(path)) {
            if (in == null) { issues.add(Issue.error(where, "parts file '" + path + "' not found (run tools/split_model.py)")); return null; }
            Map<String, Object> m = YamlIo.load(new InputStreamReader(in, java.nio.charset.StandardCharsets.UTF_8), path); metaCache.put(path, m); return m;
        } catch (java.io.IOException | RuntimeException e) { issues.add(Issue.error(where, "cannot read " + path + ": " + e.getMessage())); return null; }
    }

    // ------------------------------------------------------------------ helpers
    private ItemDisplay spawnItem(ProductionContext c, Location l, String model) {
        NamespacedKey key = NamespacedKey.fromString(model); if (key == null) throw new IllegalArgumentException("bad item model '" + model + "'");
        float vr = Math.max(1f, (float) plugin.getConfig().getDouble("engine.audience-radius", 128) / 64f);
        return c.world().spawn(l, ItemDisplay.class, d -> {
            ItemStack it = new ItemStack(Material.PAPER); ItemMeta m = it.getItemMeta(); m.setItemModel(key); it.setItemMeta(m); d.setItemStack(it);
            d.setItemDisplayTransform(ItemDisplay.ItemDisplayTransform.FIXED); d.setPersistent(false); d.setInvulnerable(true); d.setGravity(false); d.setViewRange(vr);
            d.addScoreboardTag(PlayerDisplayRig.TAG); d.setTeleportDuration(2);
            d.setTransformation(new Transformation(new Vector3f(), new Quaternionf(), new Vector3f(0f), new Quaternionf())); });
    }
    private void place(ItemDisplay d, Location at, Vector3f tr, Quaternionf q, float scale) {
        if (d == null || !d.isValid()) return;
        try { d.teleport(at); } catch (RuntimeException ignored) { }
        d.setInterpolationDelay(0); d.setInterpolationDuration(2);
        d.setTransformation(new Transformation(tr, new Quaternionf(q), new Vector3f(scale), new Quaternionf()));
    }
    private void remove(ItemDisplay d) { if (d != null && d.isValid()) d.remove(); }
    private void clearDisplays(W w) { remove(w.whole); w.whole = null; for (Part p : w.parts) remove(p.d); w.parts.clear(); for (Frag f : w.frags) if (w.st != St.SHATTERED) remove(f.d); if (w.st != St.SHATTERED) w.frags.clear(); }

    private float scaleOf(W w) { return (float) new Params(w.hold != null ? w.hold.raw() : Map.of()).dbl("scale", 1.0); }
    private Vector3f vec3(Params p, String key) { Vec3 v = p.vec(key); return v == null ? new Vector3f() : new Vector3f((float) v.x(), (float) v.y(), (float) v.z()); }
    private Quaternionf rotDeg(Params p, String key) { Vec3 v = p.vec(key); Quaternionf q = new Quaternionf(); if (v != null) q.rotateXYZ((float) Math.toRadians(v.x()), (float) Math.toRadians(v.y()), (float) Math.toRadians(v.z())); return q; }

    /** World placement of the weapon when held by its holder: display origin location, orientation, scale. */
    private Tgt heldTarget(W w, ProductionContext c) {
        Actor a = w.holder; if (a == null || !(a.body() instanceof ClipBody cb)) return null;
        Params h = w.hold; if (h == null) return null;
        PlayerDisplayRig.Anchor anc = "back".equals(w.anchor) ? PlayerDisplayRig.Anchor.BACK : PlayerDisplayRig.Anchor.HAND_R;
        PlayerDisplayRig.Frame f = cb.rig().frame(anc, vec3(h, "off_px")); if (f == null) return null;
        Quaternionf q = new Quaternionf(f.q()).mul(rotDeg(h, "rot_deg"));
        float s = (float) h.dbl("scale", 1.0); Vector3f grip = new Vector3f(0f, (float) (h.dbl("grip_y", 8) - 8) / 16f * s, 0f); q.transform(grip);
        Location feet = c.abs(a.pos());
        Vector3f pos = new Vector3f(f.pos()).sub(grip);
        return new Tgt(feet.clone().add(pos.x, pos.y, pos.z), q, s);
    }
    private Location handWorld(W w, ProductionContext c) { Tgt t = heldTarget(w, c); return t == null ? null : t.loc(); }

    // ------------------------------------------------------------------ actions
    @Override public ActionHandler.Outcome begin(Spec.Action a, ProductionContext c) {
        ctx = c;
        try { return run(a, c); }
        catch (IllegalArgumentException | IllegalStateException | NullPointerException | ClassCastException e) { return ActionHandler.Outcome.fail(a.action() + ": " + e.getClass().getSimpleName() + " " + e.getMessage()); }
    }
    private W weapon(Spec.Action a, ProductionContext c) {
        String id = a.params().str("weapon", ""); W w = weapons.get(id);
        if (w == null) { w = new W(); w.id = id; w.def = c.weaponDef(id); w.rnd = new Random(id.hashCode() ^ a.tick()); if (w.def.isEmpty()) throw new IllegalArgumentException("weapon '" + id + "' has no definition"); weapons.put(id, w); }
        return w;
    }
    @SuppressWarnings("unchecked") private Params sub(Map<String, Object> def, String key) { return new Params(def.get(key) instanceof Map<?, ?> m ? (Map<String, Object>) m : Map.of()); }

    private ActionHandler.Outcome run(Spec.Action a, ProductionContext c) {
        Params p = a.params();
        switch (a.action()) {
            case "weapon_show" -> { W w = weapon(a, c); clearDisplays(w); Params ped = sub(w.def, "pedestal"); Vec3 at = p.has("at") ? p.vec("at") : ped.vec("at");
                w.free = at; w.hold = ped; w.whole = spawnItem(c, c.abs(at), String.valueOf(w.def.get("item_model"))); w.st = St.PEDESTAL; w.t = 0; }
            case "weapon_hide" -> { W w = weapon(a, c); clearDisplays(w); w.st = St.HIDDEN; }
            case "weapon_take" -> { W w = weapon(a, c); Actor ac = actor(a); if (w.whole == null) throw new IllegalStateException("weapon '" + w.id + "' is not shown"); startFly(w, c, ac, sub(w.def, "stow"), "back", Math.max(8, a.durationTicks())); ac.play("reach", 4, false); }
            case "weapon_equip" -> { W w = weapon(a, c); Actor ac = actor(a); if (w.whole == null) throw new IllegalStateException("weapon '" + w.id + "' is not materialized"); startFly(w, c, ac, sub(w.def, "hold"), "hand_r", Math.max(6, a.durationTicks())); ac.play(p.str("anim", "weapon_draw"), 3, false); }
            case "weapon_summon" -> summon(a, c);
            case "weapon_attack" -> {
                if (combat == null) return ActionHandler.Outcome.fail("combat module is not registered");
                W aw = weapon(a, c); if (aw.st == St.HELD) trail(aw, Math.max(8, (int) Math.round(p.dbl("impact", 0.3) * 20) + 8));
                return combat.attack(a, c, true); }
            case "weapon_spin" -> { Actor ac = actor(a); ac.play(p.str("anim", "scythe_spin"), 4, false); trail(weapon(a, c), a.durationTicks()); }
            case "weapon_trail" -> trail(weapon(a, c), a.durationTicks());
            case "weapon_crack" -> crack(a, c);
            case "weapon_shatter" -> shatter(a, c);
            case "fragments_cleanup" -> { W w = weapons.get(p.str("weapon", "")); if (w != null) { for (Frag f : w.frags) remove(f.d); w.frags.clear(); w.st = St.HIDDEN; } }
            default -> { return ActionHandler.Outcome.fail("WeaponModule does not implement '" + a.action() + "'"); }
        }
        return ActionHandler.Outcome.OK;
    }
    private Actor actor(Spec.Action a) { return actors.actor(a.actor()).orElseThrow(() -> new IllegalStateException("actor '" + a.actor() + "' is not spawned")); }

    private void startFly(W w, ProductionContext c, Actor ac, Params hold, String anchor, int dur) {
        w.from = w.whole.getLocation(); Transformation tf = w.whole.getTransformation(); w.fromQ = new Quaternionf(tf.getLeftRotation()); w.fromScale = tf.getScale().x;
        w.holder = ac; w.hold = hold; w.anchor = anchor; w.st = St.FLYING; w.t = 0; w.dur = dur;
    }

    // ---- summoning: parts converge from scattered positions into the exact original geometry
    @SuppressWarnings("unchecked")
    private void summon(Spec.Action a, ProductionContext c) {
        Params p = a.params(); W w = weapon(a, c); Actor ac = actor(a); clearDisplays(w);
        List<Issue> iss = new ArrayList<>(); Map<String, Object> meta = parts(String.valueOf(w.def.get("parts_file")), iss, "weapon " + w.id); if (meta == null) throw new IllegalStateException(iss.get(0).message());
        w.holder = ac; w.hold = sub(w.def, "hold"); w.free = p.vec("at"); w.rnd = rng(a); w.t = 0; w.dur = a.durationTicks(); w.st = St.ASSEMBLING;
        w.stages.clear(); w.stageNames.clear();
        if (p.raw().get("stages") instanceof List<?> sl) for (Object so : sl) { Params sp = new Params((Map<String, Object>) so); w.stageNames.add(sp.str("name", "?")); w.stages.add(new int[]{(int) Math.round(sp.dbl("at", 0) * 20)}); }
        else throw new IllegalArgumentException("weapon_summon needs 'stages'");
        float s = scaleOf(w); double R = sub(w.def, "x").dbl("summon_radius", new Params(w.def).dbl("summon_radius", 3.6));
        for (Map.Entry<String, Object> e : ((Map<String, Object>) meta.get("parts")).entrySet()) {
            Params pp = new Params((Map<String, Object>) e.getValue()); Part part = new Part(); part.name = e.getKey(); part.group = e.getKey().startsWith("blade") ? 1 : 0;
            List<Object> cl = (List<Object>) pp.raw().get("centroid"); part.c.set(((Number) cl.get(0)).floatValue() - 8f, ((Number) cl.get(1)).floatValue() - 8f, ((Number) cl.get(2)).floatValue() - 8f).div(16f).mul(s);
            double th = w.rnd.nextDouble() * Math.PI * 2, ph = Math.acos(2 * w.rnd.nextDouble() - 1); part.off.set((float) (R * Math.sin(ph) * Math.cos(th)), (float) (R * Math.cos(ph)) + 1f, (float) (R * Math.sin(ph) * Math.sin(th)));
            part.rot0.rotateAxis((float) (Math.PI * (0.6 + w.rnd.nextDouble() * 0.8)), (float) w.rnd.nextGaussian(), (float) w.rnd.nextGaussian(), (float) w.rnd.nextGaussian()).normalize();
            part.d = spawnItem(c, c.abs(w.free), String.valueOf(pp.str("item_model", ""))); w.parts.add(part);
        }
    }
    private int stageAt(W w, String name, int dflt) { int i = w.stageNames.indexOf(name); return i < 0 ? dflt : w.stages.get(i)[0]; }

    private void tickAssembly(W w, ProductionContext c) {
        int t = w.t; float s = scaleOf(w); Location base = c.abs(w.free);
        int tGather = stageAt(w, "energy_gather", 40), tApp = stageAt(w, "components_appear", 90), tBlade = stageAt(w, "blade_formation", 120), tHandle = stageAt(w, "handle_formation", 160), tFinal = stageAt(w, "final_assembly", 190), tMat = stageAt(w, "materialized", w.dur);
        // energy: swirling motes that tighten as the weapon forms
        int n = Math.min(particleBudget, t < tGather ? 6 : 18); particleBudget -= n;
        for (int i = 0; i < n; i++) { double ang = w.rnd.nextDouble() * Math.PI * 2, r = (t < tApp ? 3.5 : 2.5) * (1.0 - 0.6 * Math.min(1.0, t / (double) Math.max(1, tMat))); Location l = base.clone().add(Math.cos(ang) * r, 1.2 + (w.rnd.nextDouble() - 0.5) * 3, Math.sin(ang) * r); Fx.spawn(c.world(), Particle.REVERSE_PORTAL, l, 0, (base.getX() - l.getX()) * 0.1, (base.getY() + 1.2 - l.getY()) * 0.1, (base.getZ() - l.getZ()) * 0.1, 1.0); }
        for (Part p : w.parts) {
            float appear = t < tApp ? 0f : Math.min(1f, (t - tApp) / 20f);
            int cs = p.group == 1 ? tBlade : tHandle, cd = p.group == 1 ? 40 : 30;
            float conv = t < cs ? 0f : (float) Ease.IN_OUT_CUBIC.apply(Math.min(1.0, (t - cs) / (double) cd));
            Quaternionf q = new Quaternionf(p.rot0).slerp(new Quaternionf(), conv, new Quaternionf());
            double orbit = t * 0.045 * (1 - conv); Vector3f off = new Vector3f(p.off).rotateY((float) orbit).mul(1f - conv);
            Vector3f cp = new Vector3f(p.c); Vector3f rc = new Vector3f(cp); q.transform(rc);
            Vector3f tr = new Vector3f(cp).sub(rc).add(off);
            float pulse = (t >= tFinal && t < tFinal + 8) ? 1f + 0.06f * (float) Math.sin((t - tFinal) / 8.0 * Math.PI) : 1f;
            place(p.d, base, tr, q, s * appear * pulse);
        }
        if (t >= tMat) {
            for (Part p : w.parts) remove(p.d); w.parts.clear();
            w.whole = spawnItem(c, base, String.valueOf(w.def.get("item_model"))); place(w.whole, base, new Vector3f(), new Quaternionf(), s);
            Fx.spawn(c.world(), Particle.FLASH, base.clone().add(0, 1.2, 0), 1, 0, 0, 0, 0); Fx.spawn(c.world(), Particle.END_ROD, base.clone().add(0, 1.2, 0), 60, 0.4, 1.2, 0.4, 0.15);
            w.st = St.FLOATING; w.t = 0;
        }
    }
    private Random rng(Spec.Action a) { return new Random(a.where().hashCode() * 31L + a.tick()); }

    // ---- crack + shatter
    @SuppressWarnings("unchecked")
    private void makeFragments(W w, ProductionContext c, Tgt t) {
        List<Issue> iss = new ArrayList<>(); Map<String, Object> meta = parts(String.valueOf(w.def.get("parts_file")), iss, "weapon " + w.id); if (meta == null) throw new IllegalStateException(iss.get(0).message());
        float s = t.scale(); List<Object> fl = (List<Object>) meta.get("fragments"); Vector3f center = new Vector3f(0f, 0f, 0f);
        for (Object fo : fl) {
            Params fp = new Params((Map<String, Object>) fo); Frag f = new Frag(); List<Object> cl = (List<Object>) fp.raw().get("centroid");
            f.c.set(((Number) cl.get(0)).floatValue() - 8f, ((Number) cl.get(1)).floatValue() - 8f, ((Number) cl.get(2)).floatValue() - 8f).div(16f).mul(s);
            Vector3f d = new Vector3f(f.c); if (d.lengthSquared() < 1e-6f) d.set(0, 1, 0); d.normalize(); f.dir = new Vec3(d.x, d.y, d.z);
            f.d = spawnItem(c, t.loc(), fp.str("item_model", "")); w.frags.add(f);
        }
        remove(w.whole); w.whole = null;
    }
    private void crack(Spec.Action a, ProductionContext c) {
        W w = weapon(a, c); if (w.st != St.HELD) throw new IllegalStateException("weapon '" + w.id + "' must be held by an actor to crack");
        Tgt t = heldTarget(w, c); if (t == null) throw new IllegalStateException("holder has no hand frame");
        makeFragments(w, c, t); w.st = St.CRACKING; w.t = 0; w.dur = Math.max(20, a.durationTicks()); w.crackP = a.params(); w.crackStage = 0; w.gap = 0;
    }
    private void tickCrack(W w, ProductionContext c) {
        Tgt t = heldTarget(w, c); if (t == null) return;
        int stages = Math.max(1, w.crackP.integer("stages", 3)); double prog = Math.min(1.0, w.t / (double) w.dur); int stage = Math.min(stages, (int) Math.floor(prog * stages + 1e-9) + (prog >= 1 ? 0 : 0));
        float target = (float) (0.16 * Math.pow(prog, 1.4)); w.gap = target;
        if (stage > w.crackStage) { w.crackStage = stage; c.world().playSound(t.loc(), "minecraft:block.amethyst_block.break", SoundCategory.MASTER, 3.0f, 0.5f); Fx.spawn(c.world(), Particle.CRIT, t.loc().clone().add(0, 1, 0), 40, 0.5, 1.0, 0.5, 0.3); }
        for (Frag f : w.frags) {
            Vector3f g = new Vector3f((float) f.dir.x(), (float) f.dir.y(), (float) f.dir.z()).mul(w.gap); t.q().transform(g);
            Vector3f jitter = new Vector3f((float) (w.rnd.nextGaussian() * 0.004 * prog), (float) (w.rnd.nextGaussian() * 0.004 * prog), (float) (w.rnd.nextGaussian() * 0.004 * prog));
            place(f.d, t.loc(), g.add(jitter), t.q(), t.scale());
            if (particleBudget > 0 && w.rnd.nextInt(Math.max(2, 8 - stages)) == 0) { particleBudget--; Vector3f cc = new Vector3f(f.c); t.q().transform(cc); Fx.spawn(c.world(), Particle.END_ROD, t.loc().clone().add(cc.x, cc.y, cc.z), 1, 0.03, 0.03, 0.03, 0.01); }
        }
    }
    @SuppressWarnings("unchecked")
    private void shatter(Spec.Action a, ProductionContext c) {
        Params p = a.params(); W w = weapon(a, c);
        if (w.st == St.HELD) { Tgt t = heldTarget(w, c); if (t == null) throw new IllegalStateException("holder has no hand frame"); makeFragments(w, c, t); w.gap = 0; }
        else if (w.st != St.CRACKING) throw new IllegalStateException("weapon '" + w.id + "' must be held or cracking to shatter (state " + w.st + ")");
        Tgt t = heldTarget(w, c); if (t == null) throw new IllegalStateException("holder has no hand frame");
        Random rnd = rng(a); List<Params> scatter = new ArrayList<>(); List<Double> share = new ArrayList<>(); double total = 0;
        if (p.raw().get("scatter") instanceof List<?> sl) for (Object so : sl) { Params sp = new Params((Map<String, Object>) so); scatter.add(sp); share.add(sp.dbl("share", 1.0)); total += sp.dbl("share", 1.0); }
        if (scatter.isEmpty()) { Params dflt = new Params(Map.of("at", List.of(0.0, 0.0, 0.0), "radius", sub(w.def, "shatter").dbl("scatter_radius", 14), "share", 1.0)); scatter.add(dflt); share.add(1.0); total = 1.0; }
        int idx = 0;
        for (Frag f : w.frags) {
            Vector3f cc = new Vector3f(f.c); Vector3f g = new Vector3f((float) f.dir.x(), (float) f.dir.y(), (float) f.dir.z()).mul(w.gap); t.q().transform(cc); t.q().transform(g);
            f.p.set(t.loc().getX() + cc.x + g.x, t.loc().getY() + cc.y + g.y, t.loc().getZ() + cc.z + g.z); f.q.set(t.q());
            double pick = (idx++ + 0.5) / w.frags.size() * total, acc = 0; Params sp = scatter.get(0); for (int i = 0; i < scatter.size(); i++) { acc += share.get(i); if (pick <= acc) { sp = scatter.get(i); break; } }
            Vec3 ctr = sp.vec("at"); double R = sp.dbl("radius", 8); double ang = rnd.nextDouble() * Math.PI * 2, rr = R * Math.sqrt(rnd.nextDouble());
            Location tgt = c.abs(new Vec3(ctr.x() + Math.cos(ang) * rr, ctr.y(), ctr.z() + Math.sin(ang) * rr)); double floor = floorBelow(c, tgt.getX(), c.origin().getY() + 20, tgt.getZ(), tgt.getY());
            f.floor = floor; double tf = 35 + rnd.nextDouble() * 35; double g0 = 0.045;
            f.v.set((tgt.getX() - f.p.x) / tf, (floor + 0.15 - f.p.y + 0.5 * g0 * tf * tf) / tf, (tgt.getZ() - f.p.z) / tf);
            f.spin.set((float) (rnd.nextGaussian() * 0.12), (float) (rnd.nextGaussian() * 0.12), (float) (rnd.nextGaussian() * 0.12)); f.landed = false;
        }
        w.st = St.SHATTERED;
        Fx.spawn(c.world(), Particle.FLASH, t.loc().clone().add(0, 1, 0), 1, 0, 0, 0, 0); Fx.spawn(c.world(), Particle.CRIT, t.loc().clone().add(0, 1, 0), 120, 1.0, 1.2, 1.0, 0.6);
    }
    /** Highest solid surface at (x,z) at or below startY (rayTrace down). Falls back to the given default. */
    private double floorBelow(ProductionContext c, double x, double startY, double z, double dflt) {
        RayTraceResult r = c.world().rayTraceBlocks(new Location(c.world(), x, startY, z), new Vector(0, -1, 0), 60, FluidCollisionMode.NEVER, true);
        return r == null || r.getHitPosition() == null ? dflt : r.getHitPosition().getY();
    }
    private void tickShattered(W w, ProductionContext c) {
        double dt = timeScale;
        for (Frag f : w.frags) {
            if (!f.d.isValid()) continue;
            if (!f.landed) {
                f.p.x += f.v.x * dt; f.p.y += f.v.y * dt; f.p.z += f.v.z * dt; f.v.y -= 0.045 * dt;
                f.q.rotateXYZ((float) (f.spin.x * dt), (float) (f.spin.y * dt), (float) (f.spin.z * dt));
                if (f.v.y < 0 && f.p.y <= f.floor + 0.15) { f.p.y = f.floor + 0.15; f.landed = true; f.v.set(0, 0, 0); Fx.spawn(c.world(), Particle.CAMPFIRE_COSY_SMOKE, f.p.x, f.p.y, f.p.z, 0, 0, 0.05, 0, 1.0); }
            } else if (++f.recheck % 10 == 0) {   // the ground may have been carved away (crater): fall again
                double fl = floorBelow(c, f.p.x, f.p.y + 1.0, f.p.z, f.floor);
                if (fl < f.floor - 0.3) { f.floor = fl; f.landed = false; f.v.set(0, 0, 0); }
            }
            Vector3f tr = new Vector3f(f.c).negate(); f.q.transform(tr);
            place(f.d, new Location(c.world(), f.p.x, f.p.y, f.p.z), tr, f.q, scaleOf(w));
        }
    }

    // ---- trails
    private void trail(W w, int dur) {
        final int[] t = {0}; final int d = Math.max(4, dur);
        trails.add(new Runnable[]{() -> {
            Tgt tg = heldTarget(w, ctx); if (tg == null || particleBudget < 6) return;
            for (float u : new float[]{-0.6f, 0.2f, 1.0f}) { Vector3f off = new Vector3f(-0.9f * u, 0.9f + 0.6f * u, 0f).mul(tg.scale()); tg.q().transform(off); Fx.spawn(ctx.world(), Particle.SOUL_FIRE_FLAME, tg.loc().clone().add(off.x, off.y, off.z), 3, 0.03, 0.03, 0.03, 0.0); Fx.dust(ctx.world(), tg.loc().clone().add(off.x, off.y, off.z), 3, 0.1, 0x9B6BFF, 1.7f); particleBudget -= 6; }
        }});
        trailTimers.add(new int[]{0, d});
    }

    // ------------------------------------------------------------------ per tick
    @Override public void tick(ProductionContext c, int sceneTick, int globalTick) {
        if (paused) return; ctx = c; now++; particleBudget = plugin.getConfig().getInt("performance.max-particles-per-tick", 600) / 2;
        for (W w : weapons.values()) { w.t++;
            switch (w.st) {
                case PEDESTAL, FLOATING -> {
                    if (w.whole == null || !w.whole.isValid()) break;
                    Params ped = w.hold == null ? new Params(Map.of()) : w.hold; double bob = Math.sin(w.t * 0.08) * ped.dbl("bob", 0.1);
                    Location l = c.abs(new Vec3(w.free.x(), w.free.y() + bob + (w.st == St.FLOATING ? 1.0 + Math.sin(w.t * 0.05) * 0.1 : 0), w.free.z()));
                    Quaternionf q = new Quaternionf().rotateY((float) Math.toRadians(ped.dbl("spin_deg_per_tick", 0) * w.t)); place(w.whole, l, new Vector3f(), q, (float) ped.dbl("scale", w.st == St.FLOATING ? scaleOf(w) : 1.0));
                    if (w.st == St.PEDESTAL && env.pedestalEnergy() && w.t % 3 == 0 && particleBudget > 0) { particleBudget--; Fx.spawn(c.world(), Particle.END_ROD, l.clone().add(0, 0.2, 0), 1, 0.25, 0.4, 0.25, 0.01); }
                }
                case FLYING -> {
                    Tgt tg = heldTarget(w, c); if (tg == null || w.whole == null) break;
                    double f = Ease.IN_OUT_QUAD.apply(Math.min(1.0, w.t / (double) w.dur));
                    Location l = w.from.clone().add(tg.loc().clone().subtract(w.from).toVector().multiply(f));
                    place(w.whole, l, new Vector3f(), new Quaternionf(w.fromQ).slerp(tg.q(), (float) f, new Quaternionf()), (float) (w.fromScale + (tg.scale() - w.fromScale) * f));
                    if (w.t >= w.dur) { w.st = St.HELD; w.t = 0; }
                }
                case HELD -> {
                    Tgt tg = heldTarget(w, c); if (tg == null) break; place(w.whole, tg.loc(), new Vector3f(), tg.q(), tg.scale());
                    Params au = sub(w.def, "aura");   // idle weapon energy: drifting motes along the blade
                    if (au.has("rgb") && particleBudget > 4 && timeScale > 0) for (float u : new float[]{-0.8f, 0.1f, 0.9f}) { if (w.rnd == null || w.rnd.nextInt(2) == 0) { Vector3f off = new Vector3f(-0.9f * u, 0.9f + 0.6f * u, 0f).mul(tg.scale()); tg.q().transform(off); Fx.dust(c.world(), tg.loc().clone().add(off.x, off.y, off.z), 1, 0.12, (int) Long.parseLong(au.str("rgb", "7B2CFF"), 16), 1.4f); particleBudget--; } }
                }
                case ASSEMBLING -> tickAssembly(w, c);
                case CRACKING -> tickCrack(w, c);
                case SHATTERED -> tickShattered(w, c);
                default -> { }
            }
        }
        for (int i = trails.size() - 1; i >= 0; i--) { trails.get(i)[0].run(); if (++trailTimers.get(i)[0] >= trailTimers.get(i)[1]) { trails.remove(i); trailTimers.remove(i); } }
    }
    @Override public boolean busy() { for (W w : weapons.values()) if (w.st == St.ASSEMBLING || w.st == St.FLYING) return true; return false; }
    @Override public void pause() { paused = true; }
    @Override public void resume() { paused = false; }
    @Override public void cleanup(boolean restoreWorld) {
        for (W w : weapons.values()) { clearDisplays(w); for (Frag f : w.frags) remove(f.d); w.frags.clear(); }
        weapons.clear(); trails.clear(); trailTimers.clear(); PlayerDisplayRig.sweepOrphans();
    }
    @Override public void reset(String productionId) { cleanup(true); }
}
