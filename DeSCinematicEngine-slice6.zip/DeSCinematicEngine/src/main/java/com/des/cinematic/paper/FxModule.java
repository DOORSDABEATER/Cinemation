package com.des.cinematic.paper;

import com.des.cinematic.api.ActionModule;
import com.des.cinematic.api.ProductionContext;
import com.des.cinematic.core.*;
import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.*;

/**
 * EFFECTS actions: energy auras around actors and visual-only lightning. Auras are what make the characters read as supernatural at a
 * glance: ERROR trails void-violet energy, AZRATHIEL carries a slow golden-violet halo, and the ultimate pulls the whole room inward.
 * Lightning is the vanilla visual effect only (no damage, no fire). Nothing here touches players.
 */
public final class FxModule implements ActionModule {
    private record Aura(String actor, String style, int rgb, double density, int until) {}
    private record Bolt(Location at, int when) {}
    private final JavaPlugin plugin; private final ActorModule actors;
    private final List<Aura> auras = new ArrayList<>(); private final List<Bolt> bolts = new ArrayList<>();
    private int now, budget; private boolean paused; private final Random rnd = new Random(7);

    public FxModule(JavaPlugin plugin, ActorModule actors) { this.plugin = plugin; this.actors = actors; }
    @Override public String id() { return "fx"; }
    @Override public Set<ActionCatalog.Category> categories() { return EnumSet.of(ActionCatalog.Category.EFFECTS); }
    @Override public void productionStarted(ProductionContext c) { auras.clear(); bolts.clear(); now = 0; paused = false; }

    @Override public ActionHandler.Outcome begin(Spec.Action a, ProductionContext c) {
        Params p = a.params();
        switch (a.action()) {
            case "aura" -> {
                String style = p.str("style", "void"); int rgb = (int) Long.parseLong(p.str("rgb", defaultRgb(style)).replace("#", ""), 16);
                auras.removeIf(x -> x.actor().equals(a.actor()) && x.style().equals(style));
                auras.add(new Aura(a.actor(), style, rgb, p.dbl("density", 1.0), p.has("duration") ? now + a.durationTicks() : -1));
            }
            case "aura_off" -> auras.removeIf(x -> x.actor().equals(a.actor()) && (!p.has("style") || x.style().equals(p.str("style", ""))));
            case "lightning" -> {
                Vec3 at = p.vec("at"); int n = Math.max(1, p.integer("count", 3)), dur = Math.max(1, a.durationTicks()); double r = p.dbl("radius", 6);
                Random lr = new Random(a.where().hashCode());
                for (int i = 0; i < n; i++) { double ang = lr.nextDouble() * Math.PI * 2, rr = r * Math.sqrt(lr.nextDouble()); bolts.add(new Bolt(c.abs(new Vec3(at.x() + Math.cos(ang) * rr, at.y(), at.z() + Math.sin(ang) * rr)), now + (n == 1 ? 0 : i * dur / n))); }
            }
            default -> { return ActionHandler.Outcome.fail("FxModule does not implement '" + a.action() + "'"); }
        }
        return ActionHandler.Outcome.OK;
    }
    private static String defaultRgb(String style) { return switch (style) { case "sovereign" -> "C9A8FF"; case "ultimate" -> "8A4DFF"; case "flame" -> "7B2CFF"; default -> "5B3CC4"; }; }

    @Override public void tick(ProductionContext c, int sceneTick, int globalTick) {
        if (paused) return; now++; budget = plugin.getConfig().getInt("performance.max-particles-per-tick", 600) / 3;
        for (Iterator<Bolt> it = bolts.iterator(); it.hasNext(); ) { Bolt b = it.next(); if (b.when() <= now) { Fx.lightning(c.world(), b.at()); Fx.spawn(c.world(), Particle.EXPLOSION, b.at(), 2, 0.4, 0.2, 0.4, 0); Fx.dust(c.world(), b.at().clone().add(0, 0.5, 0), 20, 0.6, 0x9B6BFF, 1.6f); it.remove(); } }
        for (Iterator<Aura> it = auras.iterator(); it.hasNext(); ) {
            Aura au = it.next(); if (au.until() >= 0 && now >= au.until()) { it.remove(); continue; }
            Actor ac = actors.actor(au.actor()).orElse(null); if (ac == null) continue;
            emit(c, ac, au);
        }
    }

    private void emit(ProductionContext c, Actor ac, Aura au) {
        Vec3 p = ac.pos(); double h = ac.chest() * 1.5, r = ac.radius() + 0.35; int n = Math.min(budget, (int) Math.max(1, Math.round(au.density() * (au.style().equals("ultimate") ? 14 : 5)))); budget -= n; if (n <= 0) return;
        for (int i = 0; i < n; i++) {
            double ang = now * 0.22 + i * (Math.PI * 2 / n) + rnd.nextDouble() * 0.4, y = rnd.nextDouble() * h;
            Location l = c.abs(new Vec3(p.x() + Math.cos(ang) * r, p.y() + y, p.z() + Math.sin(ang) * r));
            switch (au.style()) {
                case "ultimate" -> { double rr = 4.5 + rnd.nextDouble() * 3; Location far = c.abs(new Vec3(p.x() + Math.cos(ang) * rr, p.y() + rnd.nextDouble() * h * 1.3, p.z() + Math.sin(ang) * rr));
                    Fx.spawn(c.world(), Particle.REVERSE_PORTAL, far, 0, (l.getX() - far.getX()) * 0.08, (c.abs(p).getY() + ac.chest() - far.getY()) * 0.08, (l.getZ() - far.getZ()) * 0.08, 1.0);
                    if (i % 2 == 0) Fx.dust(c.world(), l, 1, 0.15, au.rgb(), 2.0f); }
                case "sovereign" -> { Fx.dust(c.world(), l, 1, 0.1, au.rgb(), 1.5f); if (i == 0) Fx.spawn(c.world(), Particle.END_ROD, l.clone().add(0, 0.2, 0), 1, 0.05, 0.1, 0.05, 0.01); }
                case "flame" -> { Fx.spawn(c.world(), Particle.SOUL_FIRE_FLAME, l, 1, 0.05, 0.1, 0.05, 0.01); if (i % 2 == 0) Fx.dust(c.world(), l, 1, 0.1, au.rgb(), 1.3f); }
                default -> { Fx.dust(c.world(), l, 1, 0.08, au.rgb(), 1.3f); if (i == 0) Fx.spawn(c.world(), Particle.SOUL_FIRE_FLAME, l.clone().add(0, 0.15, 0), 1, 0.03, 0.08, 0.03, 0.005); }
            }
        }
    }
    @Override public void pause() { paused = true; }
    @Override public void resume() { paused = false; }
    @Override public void cleanup(boolean restoreWorld) { auras.clear(); bolts.clear(); }
}
