package com.des.cinematic.api;

/** Static accessor so soft-depending plugins never link against the engine classes unless it is present. */
public final class CinematicEngine {
    private static volatile CinematicApi api;
    private CinematicEngine() {}
    public static boolean isAvailable() { return api != null; }
    public static CinematicApi get() { CinematicApi a = api; if (a == null) throw new IllegalStateException("DeSCinematicEngine is not enabled"); return a; }
    public static void set(CinematicApi a) { api = a; }
}
