package com.des.cinematic.api;

import java.util.List;
import java.util.Optional;

/**
 * Public API for other DeS plugins (theatre system, boss encounters, ...). Obtain via {@link CinematicEngine#get()}.
 * The engine is a soft dependency: always guard with {@link CinematicEngine#isAvailable()}.
 */
public interface CinematicApi {
    enum StartResult { STARTED, UNKNOWN_PRODUCTION, ALREADY_RUNNING, INVALID, WORLD_MISSING, ERROR }
    record Started(StartResult result, String message) { public boolean ok() { return result == StartResult.STARTED; } }

    List<String> productionIds();
    Started start(String productionId);
    /** Starts the production but finishes cleanly after the named scene (partial runs, e.g. testing only the first scenes). */
    default Started start(String productionId, String untilSceneId) { return start(productionId); }
    boolean stop(boolean restoreWorld);
    boolean pause();
    boolean resume();
    Optional<String> activeProduction();
    String status();
    void registerModule(ActionModule module);
}
