package com.des.cinematic.paper;

import com.des.cinematic.rig.*;
import com.des.cinematic.vael.*;
import org.bukkit.Location;

import java.util.Map;

/**
 * AZRATHIEL: the existing 3D model (item_display skeleton: four arms, halo, fragments, markings) driven by THIS engine's own keyframed
 * clips (ParamClip). The animation states/poses of the original plugin are not used.
 */
final class VaelBody implements ActorBody {
    private static final float DT = 0.05f;   // one server tick
    private final VaelRig rig; private final ParamAnimator anim = new ParamAnimator(); private final ParamClipLibrary clips; private final Map<String, String> map;
    private final double groundOffset; private final int tint; private float time, haloAngle, fragAngle;

    VaelBody(VaelRig rig, ParamClipLibrary clips, Map<String, String> map, double groundOffset, int tint) { this.rig = rig; this.clips = clips; this.map = map; this.groundOffset = groundOffset; this.tint = tint; }

    @Override public boolean play(String logical, int blend) {
        String id = map.get(logical);
        if (id == null) throw new IllegalArgumentException("no animation '" + logical + "' mapped for this actor");
        ParamClip c = clips.get(id).orElseThrow(() -> new IllegalStateException("animation '" + logical + "' -> clip '" + id + "' does not exist"));
        anim.play(c, blend);
        return c.loops();
    }
    @Override public boolean hasAnimation(String logical) { String id = map.get(logical); return id != null && clips.get(id).isPresent(); }
    @Override public void tick() { anim.tick(); time += DT; haloAngle += anim.get(P.HALO_SPEED) * DT; fragAngle += anim.get(P.FRAG_SPEED) * DT; }
    @Override public void render(Location feet, double yaw) {
        rig.teleport(feet.clone().add(0, groundOffset, 0), 2);
        rig.render(new VaelRig.RenderState((float) yaw, time, haloAngle, fragAngle, Eidolon.FULL_MASK, -1, tint, true, true, true, 1f, 2, anim));
    }
    @Override public boolean animationFinished() { return anim.finished(); }
    @Override public String currentAnimation() { return anim.clipId(); }
    @Override public void reveal(String level) { rig.setReveal(switch (level) { case "silhouette" -> 0; case "partial" -> 1; default -> 2; }); }
    @Override public void remove() { rig.remove(); }
    @Override public boolean isValid() { return rig.valid(); }
}
