package com.des.cinematic.api;

/** Implemented by modules whose animation/motion can be slowed or frozen (slow motion, freeze-frame). Never affects player cameras. */
public interface TimeScaled { void timeScale(double scale); }
