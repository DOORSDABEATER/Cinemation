package com.des.cinematic.rig;

/** Plays one clip at a time with crossfade. Speed 0 freezes (used by 'freeze'/'time_scale'); never touches player cameras. */
public final class Animator {
    private Clip clip; private double time; private double speed = 1.0;
    private Pose from; private int blendLeft, blendTotal; private Pose current = new Pose(); private boolean finished;

    public void play(Clip c, int blendTicks) {
        from = blendTicks > 0 ? current.copy() : null;
        blendTotal = blendLeft = Math.max(0, blendTicks);
        clip = c; time = 0; finished = false;
        current = c.sample(0);
        if (from != null) current = Pose.lerp(from, current, 0);
    }
    public void speed(double s) { speed = Math.max(0, s); }
    public double speed() { return speed; }
    public String clipId() { return clip == null ? null : clip.id(); }
    public boolean finished() { return finished; }
    public Pose pose() { return current; }

    public void tick() {
        if (clip == null) return;
        time += speed;
        if (!clip.loops() && time >= clip.duration()) { time = clip.duration(); finished = true; }
        Pose target = clip.sample(time);
        if (blendLeft > 0 && from != null) {
            blendLeft = speed > 0 ? blendLeft - 1 : blendLeft;
            double f = 1.0 - (double) blendLeft / blendTotal;
            current = Pose.lerp(from, target, f * f * (3 - 2 * f));
        } else current = target;
    }
}
