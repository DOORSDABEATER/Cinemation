package com.des.cinematic.paper;

import com.des.cinematic.api.ActionModule;
import com.des.cinematic.api.ProductionContext;
import com.des.cinematic.core.*;

import java.util.*;

/** Routes each action to the module registered for its category. A missing module is a loud failure, never a silent skip. */
final class ModuleDispatcher implements ActionHandler {
    private final ProductionContext ctx; private final List<ActionModule> modules; private final boolean logEvery; private final java.util.logging.Logger log; private final RunLog run; private final java.util.Set<String> reported = new java.util.HashSet<>();

    ModuleDispatcher(ProductionContext ctx, List<ActionModule> modules, boolean logEvery, java.util.logging.Logger log, RunLog run) {
        this.ctx = ctx; this.modules = modules; this.logEvery = logEvery; this.log = log; this.run = run;
        for (ActionModule m : modules) m.productionStarted(ctx);
    }

    @Override public Outcome begin(Spec.Action a) {
        ActionCatalog.Def def = ActionCatalog.get(a.action()).orElse(null);
        if (def == null) return Outcome.fail("unknown action '" + a.action() + "'");
        if (logEvery) log.info("[" + a.where() + "]");
        if (run != null) run.line("BEGIN " + a.where() + " " + a.params().raw());
        if (def.category() == ActionCatalog.Category.FLOW) return Outcome.OK;   // scene_end / wait are handled by the runner's schedule
        for (ActionModule m : modules) if (m.categories().contains(def.category())) {
            Outcome o = m.begin(a, ctx);
            if (!o.ok() && run != null) run.line("FAILED " + a.where() + " -> " + o.message());
            return o;
        }
        return Outcome.fail("no module registered for category " + def.category() + " (action '" + a.action() + "')");
    }
    /** One misbehaving module must never stop the show: its exception is logged (once per kind, with stack) and the others keep running. */
    @Override public void tick(int sceneTick, int globalTick) {
        for (ActionModule m : modules) {
            try { m.tick(ctx, sceneTick, globalTick); }
            catch (Throwable t) {
                String key = m.id() + "|" + t.getClass().getName() + "|" + (t.getStackTrace().length > 0 ? t.getStackTrace()[0] : "");
                if (reported.add(key)) {
                    log.log(java.util.logging.Level.SEVERE, "module '" + m.id() + "' threw at scene tick " + sceneTick + " (global " + globalTick + "); the production continues without that frame/effect", t);
                    if (run != null) { java.io.StringWriter sw = new java.io.StringWriter(); t.printStackTrace(new java.io.PrintWriter(sw)); run.line("MODULE-EXCEPTION " + m.id() + " at scene tick " + sceneTick + ":\n" + sw); }
                }
            }
        }
    }
    @Override public boolean busy() { for (ActionModule m : modules) if (m.busy()) return true; return false; }
    @Override public void sceneStarted(Spec.Scene s) { for (ActionModule m : modules) m.sceneStarted(s); }
    @Override public void sceneEnded(Spec.Scene s) { for (ActionModule m : modules) m.sceneEnded(s); }
    @Override public void pause() { for (ActionModule m : modules) m.pause(); }
    @Override public void resume() { for (ActionModule m : modules) m.resume(); }
    @Override public void cleanup(boolean restoreWorld) {
        for (ActionModule m : modules) {
            try { m.cleanup(restoreWorld); } catch (RuntimeException e) { log.severe("module '" + m.id() + "' cleanup failed: " + e); }
        }
    }
}
