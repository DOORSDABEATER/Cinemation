package com.des.cinematic.core;

import java.util.*;

/** The authoritative vocabulary of timeline actions. Adding an action here makes it valid in every production. */
public final class ActionCatalog {
    public enum Category { FLOW, ACTOR, COMBAT, WEAPON, ENVIRONMENT, AUDIO, PRESENTATION, EFFECTS }

    /** required entries may use '|' for "any of". */
    public record Def(String name, Category category, boolean needsActor, List<String> required, boolean critical, int defaultTicks) {}

    private static final Map<String, Def> DEFS = new LinkedHashMap<>();
    private static void d(String n, Category c, boolean actor, boolean crit, int ticks, String... req) { DEFS.put(n, new Def(n, c, actor, List.of(req), crit, ticks)); }

    static {
        d("scene_end", Category.FLOW, false, false, 0);
        d("wait", Category.FLOW, false, false, 0);
        d("spawn", Category.ACTOR, true, true, 0, "at");
        d("despawn", Category.ACTOR, true, false, 0);
        d("walk_to", Category.ACTOR, true, true, 0, "to");
        d("run_to", Category.ACTOR, true, true, 0, "to");
        d("dash_to", Category.ACTOR, true, true, 8, "to");
        d("jump_to", Category.ACTOR, true, true, 14, "to");
        d("leap_to", Category.ACTOR, true, true, 24, "to");
        d("follow_path", Category.ACTOR, true, true, 0, "path");
        d("hold_distance", Category.ACTOR, true, false, 40, "target", "distance");
        d("teleport", Category.ACTOR, true, true, 0, "to");
        d("face", Category.ACTOR, true, false, 0, "target|at|yaw");
        d("animate", Category.ACTOR, true, false, 0, "anim");
        d("launch", Category.ACTOR, true, true, 30, "to", "apex");
        d("knockback", Category.ACTOR, true, true, 12, "to");
        d("land", Category.ACTOR, true, false, 10);
        d("get_up", Category.ACTOR, true, false, 30);
        d("float", Category.ACTOR, true, false, 0, "height");
        d("hit_reaction", Category.ACTOR, true, false, 10);
        d("pose", Category.ACTOR, true, false, 0, "anim");
        d("attack", Category.COMBAT, true, true, 12, "target", "type");
        d("block", Category.COMBAT, true, false, 10, "target");
        d("dodge", Category.COMBAT, true, true, 10, "to");
        d("counter", Category.COMBAT, true, true, 12, "target");
        d("clash", Category.COMBAT, true, true, 12, "target", "at");
        d("projectile", Category.COMBAT, true, true, 20, "to");
        d("area_attack", Category.COMBAT, true, true, 20, "at", "radius");
        d("teleport_attack", Category.COMBAT, true, true, 14, "target");
        d("weapon_show", Category.WEAPON, false, false, 0, "weapon");
        d("weapon_hide", Category.WEAPON, false, false, 0, "weapon");
        d("weapon_take", Category.WEAPON, true, true, 20, "weapon");
        d("weapon_summon", Category.WEAPON, true, true, 100, "weapon");
        d("weapon_equip", Category.WEAPON, true, true, 10, "weapon");
        d("weapon_attack", Category.WEAPON, true, true, 14, "weapon", "target");
        d("weapon_spin", Category.WEAPON, true, false, 30, "weapon");
        d("weapon_trail", Category.WEAPON, true, false, 20, "weapon");
        d("weapon_crack", Category.WEAPON, true, true, 60, "weapon");
        d("weapon_shatter", Category.WEAPON, true, true, 80, "weapon");
        d("fragments_cleanup", Category.WEAPON, false, false, 0, "weapon");
        d("env_activate", Category.ENVIRONMENT, false, false, 0, "effect");
        d("env_particles", Category.ENVIRONMENT, false, false, 20, "at", "particle");
        d("env_tremor", Category.ENVIRONMENT, false, false, 40, "at", "radius");
        d("env_crack", Category.ENVIRONMENT, false, true, 20, "at", "radius");
        d("env_crater", Category.ENVIRONMENT, false, true, 30, "at", "radius", "depth");
        d("env_explosion", Category.ENVIRONMENT, false, true, 10, "at");
        d("env_shockwave", Category.ENVIRONMENT, false, true, 30, "at", "radius");
        d("env_debris", Category.ENVIRONMENT, false, false, 40, "at");
        d("env_pillar_collapse", Category.ENVIRONMENT, false, true, 40, "at");
        d("env_light", Category.ENVIRONMENT, false, false, 20, "level");
        d("env_block_change", Category.ENVIRONMENT, false, true, 20, "region");
        d("env_build", Category.ENVIRONMENT, false, true, 40, "region", "structure");
        d("env_restore", Category.ENVIRONMENT, false, false, 0);
        d("sound", Category.AUDIO, false, false, 0, "sound");
        d("music", Category.AUDIO, false, false, 0, "track");
        d("stop_sound", Category.AUDIO, false, false, 0);
        d("dialogue", Category.AUDIO, true, true, 0, "line");
        d("aura", Category.EFFECTS, true, false, 0);
        d("aura_off", Category.EFFECTS, true, false, 0);
        d("lightning", Category.EFFECTS, false, false, 40, "at");
        d("title", Category.PRESENTATION, false, false, 100, "title");
        d("time_scale", Category.PRESENTATION, false, false, 0, "scale");
        d("freeze", Category.PRESENTATION, false, true, 20);
        d("fade_world", Category.PRESENTATION, false, false, 40, "to_level");
    }

    private ActionCatalog() {}
    public static Optional<Def> get(String name) { return Optional.ofNullable(DEFS.get(name)); }
    public static Collection<Def> all() { return DEFS.values(); }
}
