package com.des.cinematic.paper;

import com.des.cinematic.api.ActionModule;
import com.des.cinematic.api.ProductionContext;
import com.des.cinematic.core.*;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.Location;
import org.bukkit.SoundCategory;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.*;

/**
 * AUDIO actions: positional sounds, loops, music, dialogue. Dialogue plays the recorded line (a resource-pack sound event).
 * If a slot is not listed under audio.voice-recordings-present, a clearly labelled caption is ALSO shown as a fallback, and the
 * validator reports the missing recording. A caption is never presented as a substitute for the voice being finished.
 */
public final class AudioModule implements ActionModule {
    private record Loop(String slot, String event, SoundCategory cat, Location at, float vol, float pitch, int every, int[] t) {}
    private record Caption(String text, int untilTick) {}
    private final JavaPlugin plugin; private final ActorModule actors;
    private final List<Loop> loops = new ArrayList<>(); private final List<Runnable[]> delayedStops = new ArrayList<>();
    private final Map<String, String> playingEvents = new LinkedHashMap<>();   // slot -> event (for stop_sound)
    private Caption caption; private int nowTick; private boolean paused; private final List<int[]> pendingStops = new ArrayList<>(); private final List<String> pendingStopSlots = new ArrayList<>();

    public AudioModule(JavaPlugin plugin, ActorModule actors) { this.plugin = plugin; this.actors = actors; }
    @Override public String id() { return "audio"; }
    @Override public Set<ActionCatalog.Category> categories() { return EnumSet.of(ActionCatalog.Category.AUDIO); }

    @SuppressWarnings("unchecked") private static Map<String, Object> map(Object o) { return o instanceof Map<?, ?> m ? (Map<String, Object>) m : Map.of(); }
    private Map<String, Object> slotDef(ProductionContext c, String slot) { return map(rawSounds(c).get(slot)); }
    private Map<String, Object> rawSounds(ProductionContext c) { return map(c.productionRaw().get("sounds")); }
    private Map<String, Object> rawDialogue(ProductionContext c) { return map(c.productionRaw().get("dialogue")); }

    @Override public void productionStarted(ProductionContext c) { ctxForStop = c; loops.clear(); playingEvents.clear(); caption = null; paused = false; nowTick = 0; }

    @Override public List<Issue> validate(Spec.Production p, Map<String, Map<String, Object>> actorDefs, Map<String, Map<String, Object>> weaponDefs) {
        List<Issue> out = new ArrayList<>();
        List<String> present = plugin.getConfig().getStringList("audio.voice-recordings-present");
        boolean captions = plugin.getConfig().getBoolean("audio.captions-fallback", true);
        for (String d : p.dialogue()) {
            if (present.contains(d)) { out.add(Issue.info(p.id() + ".dialogue." + d, "recording marked present in config.yml (audio.voice-recordings-present); the file itself cannot be verified from the server")); continue; }
            out.add(Issue.warn(p.id() + ".dialogue." + d, "NO RECORDING installed: assets/des_cinematic/sounds/voice/" + d + ".ogg is required for spoken dialogue" + (captions ? "; a labelled caption fallback will be shown instead" : "; the line will be silent")));
        }
        return out;
    }

    @Override public ActionHandler.Outcome begin(Spec.Action a, ProductionContext c) {
        Params p = a.params();
        try {
            switch (a.action()) {
                case "sound" -> { play(c, p.str("sound", ""), p.has("at") ? c.abs(p.vec("at")) : c.origin(), p, false); }
                case "music" -> { play(c, p.str("track", ""), null, p, true); }
                case "stop_sound" -> stop(c, p.str("sound", null), p.integer("fade", 0) * 20);
                case "dialogue" -> dialogue(a, c);
                default -> { return ActionHandler.Outcome.fail("AudioModule does not implement '" + a.action() + "'"); }
            }
        } catch (IllegalArgumentException | IllegalStateException e) { return ActionHandler.Outcome.fail(a.action() + ": " + e.getMessage()); }
        return ActionHandler.Outcome.OK;
    }

    private void play(ProductionContext c, String slot, Location at, Params p, boolean music) {
        Map<String, Object> def = slotDef(c, slot); if (def.isEmpty()) throw new IllegalArgumentException("sound slot '" + slot + "' is not defined in production.sounds");
        String event = String.valueOf(def.get("event")); float vol = (float) (new Params(def).dbl("volume", 1.0) * p.dbl("volume", 1.0)), pitch = (float) p.dbl("pitch", 1.0);
        SoundCategory cat = category(new Params(def).str("category", "master"));
        playingEvents.put(slot, event);
        emit(c, event, cat, at, vol, pitch);
        if (p.bool("loop", false)) loops.add(new Loop(slot, event, cat, at, vol, pitch, Math.max(20, p.ticks("length", 20 * 20)), new int[]{0}));
    }
    private void emit(ProductionContext c, String event, SoundCategory cat, Location at, float vol, float pitch) {
        for (Player pl : c.audience()) pl.playSound(at != null ? at : pl.getLocation(), event, cat, vol, pitch);
    }
    private static SoundCategory category(String s) { return switch (s.toLowerCase(Locale.ROOT)) { case "voice" -> SoundCategory.VOICE; case "ambient" -> SoundCategory.AMBIENT; case "music" -> SoundCategory.MUSIC; case "hostile" -> SoundCategory.HOSTILE; default -> SoundCategory.MASTER; }; }

    private void stop(ProductionContext c, String slot, int fadeTicks) {
        if (fadeTicks > 0) { pendingStops.add(new int[]{nowTick + fadeTicks}); pendingStopSlots.add(slot); return; }
        doStop(c, slot);
    }
    private void doStop(ProductionContext c, String slot) {
        Iterator<Map.Entry<String, String>> it = playingEvents.entrySet().iterator();
        while (it.hasNext()) { var e = it.next(); if (slot != null && !slot.equals(e.getKey())) continue; for (Player pl : c.audience()) pl.stopSound(e.getValue()); it.remove(); }
        loops.removeIf(l -> slot == null || l.slot().equals(slot));
    }

    private void dialogue(Spec.Action a, ProductionContext c) {
        String line = a.params().str("line", ""); Map<String, Object> d = map(rawDialogue(c).get(line));
        if (d.isEmpty()) throw new IllegalArgumentException("dialogue line '" + line + "' is not defined");
        Params dp = new Params(d); String slot = dp.str("sound", "");
        Map<String, Object> sd = slotDef(c, slot); if (sd.isEmpty()) throw new IllegalArgumentException("dialogue '" + line + "' names sound slot '" + slot + "' which is not defined");
        Actor speaker = actors.actor(a.actor()).orElse(null);
        Location at = speaker != null ? c.abs(speaker.pos()).add(0, 3.0, 0) : c.origin();
        emit(c, String.valueOf(sd.get("event")), SoundCategory.VOICE, at, (float) new Params(sd).dbl("volume", 1.5), 1.0f);
        boolean haveRecording = plugin.getConfig().getStringList("audio.voice-recordings-present").contains(line);
        String text = dp.str("text", null);
        if (!haveRecording) {
            plugin.getLogger().warning("dialogue '" + line + "': recording not installed (" + slot + ".ogg)");
            if (plugin.getConfig().getBoolean("audio.captions-fallback", true) && text != null && !text.equals("null")) {
                caption = new Caption(dp.str("speaker", "?").toUpperCase(Locale.ROOT) + ": \"" + text + "\"   (caption: recording not installed)", nowTick + Math.max(60, text.length() * 3));
            }
        }
    }

    @Override public void tick(ProductionContext c, int sceneTick, int globalTick) {
        if (paused) return; nowTick++;
        for (Loop l : loops) if (l.t()[0]++ % l.every() == l.every() - 1) emit(c, l.event(), l.cat(), l.at(), l.vol(), l.pitch());
        for (int i = pendingStops.size() - 1; i >= 0; i--) if (nowTick >= pendingStops.get(i)[0]) { doStop(c, pendingStopSlots.get(i)); pendingStops.remove(i); pendingStopSlots.remove(i); }
        if (caption != null) {
            if (nowTick >= caption.untilTick()) caption = null;
            else if (nowTick % 20 == 0 || caption.untilTick() - nowTick > 0 && nowTick % 20 == 1) for (Player pl : c.audience()) pl.sendActionBar(Component.text(caption.text(), NamedTextColor.GRAY));
        }
    }
    @Override public void pause() { paused = true; }
    @Override public void resume() { paused = false; }
    @Override public void cleanup(boolean restoreWorld) { loops.clear(); caption = null; pendingStops.clear(); pendingStopSlots.clear(); if (ctxForStop != null) doStop(ctxForStop, null); playingEvents.clear(); }
    private ProductionContext ctxForStop;
    @Override public void sceneStarted(Spec.Scene s) { }
}
