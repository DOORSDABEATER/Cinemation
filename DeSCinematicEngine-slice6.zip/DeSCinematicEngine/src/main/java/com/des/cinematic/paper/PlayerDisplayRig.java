package com.des.cinematic.paper;

import com.des.cinematic.rig.Pose;
import com.des.cinematic.rig.RigSolver;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.World;
import org.bukkit.entity.Display;
import org.bukkit.entity.ItemDisplay;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import io.papermc.paper.entity.TeleportFlag;
import org.bukkit.util.Transformation;
import org.joml.Quaternionf;
import org.joml.Vector3f;

/**
 * Standard 6-bone player rig built from ItemDisplay entities: one invisible root (smoothly teleported) with the bones as passengers,
 * each bone animated through interpolated Transformations. Same technique as the existing DeS AZRATHIEL rig.
 * Players cannot hit, push or collide with displays; they are also invulnerable and non-persistent.
 */
public final class PlayerDisplayRig implements ActorRig {
    public static final String TAG = "descinematic_actor";
    private static final String[] PARTS = {"head", "body", "arm_r", "arm_l", "leg_r", "leg_l"};

    private final ItemDisplay root; private final ItemDisplay[] bones = new ItemDisplay[6];
    private final float[][] last = new float[6][8]; private final double scale; private final int interp;
    private boolean removed; private RigSolver.BoneXf[] lastXf;
    public enum Anchor { HAND_R, BACK }
    public record Frame(Vector3f pos, Quaternionf q) {}

    /** Position/orientation (relative to the actor's feet, yaw baked in) of an attachment point on the last rendered pose. */
    public Frame frame(Anchor a, Vector3f offPx) {
        if (lastXf == null) return null;
        RigSolver.BoneXf bx = lastXf[a == Anchor.HAND_R ? 2 : 1]; double k = scale / 16.0;
        Quaternionf q = new Quaternionf((float) bx.q().x(), (float) bx.q().y(), (float) bx.q().z(), (float) bx.q().w());
        Vector3f local = a == Anchor.HAND_R ? new Vector3f(0f, -12f, 0f).add(offPx) : new Vector3f(offPx);
        local.mul((float) k); q.transform(local);
        return new Frame(new Vector3f((float) bx.tx(), (float) bx.ty(), (float) bx.tz()).add(local), q);
    }

    public PlayerDisplayRig(Location feet, String modelPrefix, double scale, String ownerTag, float viewRange, int interp) {
        this.scale = scale; this.interp = interp;
        World w = feet.getWorld();
        root = w.spawn(feet, ItemDisplay.class, d -> { common(d, ownerTag, viewRange); d.setTeleportDuration(Math.max(1, interp)); });
        for (int i = 0; i < 6; i++) {
            final String part = PARTS[i];
            bones[i] = w.spawn(feet, ItemDisplay.class, d -> {
                common(d, ownerTag, viewRange);
                d.setItemStack(stack(modelPrefix + part));
                d.setItemDisplayTransform(ItemDisplay.ItemDisplayTransform.FIXED);
                d.setTransformation(new Transformation(new Vector3f(), new Quaternionf(), new Vector3f((float) scale), new Quaternionf()));
            });
            root.addPassenger(bones[i]);
            for (int k = 0; k < 8; k++) last[i][k] = Float.NaN;
        }
    }

    private static void common(ItemDisplay d, String ownerTag, float viewRange) {
        d.setPersistent(false); d.setInvulnerable(true); d.setGravity(false); d.setViewRange(viewRange);
        d.setBillboard(Display.Billboard.FIXED); d.setShadowRadius(0f);
        d.addScoreboardTag(TAG); d.addScoreboardTag(TAG + ":" + ownerTag);
    }

    private static ItemStack stack(String model) {
        ItemStack it = new ItemStack(Material.PAPER); ItemMeta m = it.getItemMeta();
        NamespacedKey key = NamespacedKey.fromString(model);
        if (key == null) throw new IllegalArgumentException("bad item model key '" + model + "'");
        m.setItemModel(key); it.setItemMeta(m); return it;
    }

    @Override public void render(Location feet, double yaw, Pose pose) {
        if (removed || !root.isValid()) return;
        try { root.teleport(feet, TeleportFlag.EntityState.RETAIN_PASSENGERS); } catch (RuntimeException ignored) { }
        RigSolver.BoneXf[] xf = RigSolver.solve(pose, yaw, scale); lastXf = xf;
        for (int i = 0; i < 6; i++) {
            ItemDisplay d = bones[i]; if (d == null || !d.isValid()) continue;
            RigSolver.BoneXf b = xf[i];
            float[] c = {(float) b.tx(), (float) b.ty(), (float) b.tz(), (float) b.q().x(), (float) b.q().y(), (float) b.q().z(), (float) b.q().w(), 0};
            float[] l = last[i]; boolean changed = Float.isNaN(l[0]);
            for (int k = 0; k < 7 && !changed; k++) if (Math.abs(c[k] - l[k]) > (k < 3 ? 0.002f : 0.0015f)) changed = true;
            if (!changed) continue;
            System.arraycopy(c, 0, l, 0, 7);
            d.setInterpolationDelay(0); d.setInterpolationDuration(Math.max(1, interp));
            d.setTransformation(new Transformation(new Vector3f(c[0], c[1], c[2]), new Quaternionf(c[3], c[4], c[5], c[6]), new Vector3f((float) scale), new Quaternionf()));
        }
    }

    @Override public boolean isValid() { if (removed || !root.isValid()) return false; for (ItemDisplay d : bones) if (d == null || !d.isValid()) return false; return true; }

    @Override public void remove() {
        removed = true;
        for (ItemDisplay d : bones) if (d != null && d.isValid()) d.remove();
        if (root.isValid()) root.remove();
    }

    /** Safety net: removes any leftover actor displays (e.g. after a crash). Only touches loaded chunks. */
    public static int sweepOrphans() {
        int n = 0;
        for (World w : org.bukkit.Bukkit.getWorlds())
            for (org.bukkit.entity.Entity e : w.getEntitiesByClass(Display.class)) if (e.getScoreboardTags().contains(TAG)) { e.remove(); n++; }
        return n;
    }
}
