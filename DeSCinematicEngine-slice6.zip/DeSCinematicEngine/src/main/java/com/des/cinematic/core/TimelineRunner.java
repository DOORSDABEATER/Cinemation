package com.des.cinematic.core;

import java.util.List;

/**
 * Deterministic, tick-driven production scheduler. It owns NO threads and NO Bukkit objects:
 * the server layer calls {@link #tick()} once per server tick. Same input => same action order, always.
 */
public final class TimelineRunner {
    public enum State { IDLE, RUNNING, PAUSED, STOPPED, FINISHED, FAILED }

    public interface Listener {
        default void onSceneStart(Spec.Scene s) {}
        default void onSceneEnd(Spec.Scene s) {}
        default void onActionFailed(Spec.Action a, String reason, boolean aborting) {}
        default void onWarning(String msg) {}
        default void onFinished(State finalState) {}
    }

    private final Spec.Production prod;
    private final ActionHandler handler;
    private final Listener listener;
    private final int graceTicks;

    private State state = State.IDLE;
    private int sceneIdx = -1, sceneTick, globalTick, cursor, sceneEnd;
    private List<Spec.Action> actions = List.of();
    private String failureReason; private int lastScene = Integer.MAX_VALUE; private boolean abortOnCritical = true; private final List<String> failures = new java.util.ArrayList<>();
    /** false = a failed action is logged loudly (production/scene/actor/action + reason) and the show continues. */
    public void abortOnCriticalFailure(boolean b) { this.abortOnCritical = b; }
    public List<String> failures() { return failures; }
    /** Finish cleanly after this scene index (partial runs, e.g. testing only the first scenes). */
    public void stopAfterScene(int index) { this.lastScene = index; }

    public TimelineRunner(Spec.Production prod, ActionHandler handler, Listener listener, int graceTicks) {
        this.prod = prod; this.handler = handler; this.listener = listener; this.graceTicks = graceTicks;
    }

    public State state() { return state; }
    public boolean active() { return state == State.RUNNING || state == State.PAUSED; }
    public int globalTick() { return globalTick; }
    public int sceneTick() { return sceneTick; }
    public Spec.Production production() { return prod; }
    public String failureReason() { return failureReason; }
    public String currentSceneId() { return sceneIdx >= 0 && sceneIdx < prod.scenes().size() ? prod.scenes().get(sceneIdx).id() : "-"; }
    public String status() {
        return state + " scene=" + currentSceneId() + " (" + (sceneIdx + 1) + "/" + prod.scenes().size() + ") sceneTick=" + sceneTick + "/" + sceneEnd + " globalTick=" + globalTick;
    }

    public void start() { startAt(0); }
    public void startAt(int sceneIndex) {
        if (state != State.IDLE) throw new IllegalStateException("runner already used: " + state);
        if (sceneIndex < 0 || sceneIndex >= prod.scenes().size()) throw new IllegalArgumentException("no scene index " + sceneIndex);
        state = State.RUNNING;
        beginScene(sceneIndex);
    }

    public void pause() { if (state == State.RUNNING) { state = State.PAUSED; handler.pause(); } }
    public void resume() { if (state == State.PAUSED) { state = State.RUNNING; handler.resume(); } }

    /** Stops and cleans up. restoreWorld=true also rolls back temporary block changes. */
    public void stop(boolean restoreWorld) {
        if (!active()) return;
        state = State.STOPPED;
        handler.cleanup(restoreWorld);
        listener.onFinished(state);
    }

    public void tick() {
        if (state != State.RUNNING) return;
        // 1) due actions, strictly in (tick, file order)
        while (state == State.RUNNING && cursor < actions.size() && actions.get(cursor).tick() <= sceneTick) {
            Spec.Action a = actions.get(cursor++);
            ActionHandler.Outcome o;
            try { o = handler.begin(a); }
            catch (RuntimeException ex) { o = ActionHandler.Outcome.fail(ex.getClass().getSimpleName() + ": " + ex.getMessage()); }
            if (!o.ok()) {
                boolean abort = a.critical() && abortOnCritical;
                failures.add(a.where() + " -> " + o.message());
                listener.onActionFailed(a, o.message(), abort);
                if (abort) { fail(a.where() + " -> " + o.message()); return; }
            }
        }
        // 2) advance running actions
        handler.tick(sceneTick, globalTick);
        // 3) scene end?
        boolean due = cursor >= actions.size() && sceneTick >= sceneEnd;
        if (due && (!handler.busy() || sceneTick >= sceneEnd + graceTicks)) {
            if (handler.busy()) listener.onWarning("scene '" + currentSceneId() + "' ended with actions still busy after " + graceTicks + " grace ticks");
            Spec.Scene done = prod.scenes().get(sceneIdx);
            handler.sceneEnded(done);
            listener.onSceneEnd(done);
            if (sceneIdx + 1 >= prod.scenes().size() || sceneIdx >= lastScene) {
                state = State.FINISHED;
                handler.cleanup(false);   // finished: temporary entities go; world restoration is scheduled by the restoration settings
                listener.onFinished(state);
                return;
            }
            beginScene(sceneIdx + 1);
            globalTick++;
            return;
        }
        sceneTick++; globalTick++;
    }

    private void beginScene(int i) {
        sceneIdx = i; sceneTick = 0; cursor = 0;
        Spec.Scene s = prod.scenes().get(i);
        actions = s.actions();
        sceneEnd = s.endTick();
        handler.sceneStarted(s);
        listener.onSceneStart(s);
    }

    private void fail(String reason) {
        failureReason = reason;
        state = State.FAILED;
        handler.cleanup(true);
        listener.onFinished(state);
    }
}
