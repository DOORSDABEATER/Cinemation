package com.des.cinematic.paper;

import com.des.cinematic.api.ActionModule;
import com.des.cinematic.api.ProductionContext;
import com.des.cinematic.api.TimeScaled;
import com.des.cinematic.core.*;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.title.Title;
import org.bukkit.entity.Player;

import java.time.Duration;
import java.util.*;

/**
 * PRESENTATION actions: titles, slow motion, freeze-frame, world fade. Nothing here moves, mounts, teleports or aims a player:
 * titles are plain overlay text, slow motion/freeze only slow the actors/weapons, and the fade is done with the world's light blocks.
 */
public final class PresentationModule implements ActionModule {
    private final List<TimeScaled> scaled = new ArrayList<>(); private final EnvironmentModule env;
    private double scale = 1.0, restoreScale = 1.0; private int freezeLeft = -1; private boolean paused;

    public PresentationModule(EnvironmentModule env, TimeScaled... modules) { this.env = env; scaled.addAll(Arrays.asList(modules)); }
    @Override public String id() { return "presentation"; }
    @Override public Set<ActionCatalog.Category> categories() { return EnumSet.of(ActionCatalog.Category.PRESENTATION); }
    @Override public void productionStarted(ProductionContext c) { apply(1.0); freezeLeft = -1; paused = false; }
    /** A few frozen ticks on a heavy impact (actors + weapon fragments only; particles keep moving so the impact still rings). */
    public void hitstop(int ticks) { if (ticks <= 0 || freezeLeft > 0 || scale <= 0.5) return; restoreScale = scale; apply(0.0); freezeLeft = ticks; }
    private void apply(double s) { scale = s; for (TimeScaled t : scaled) t.timeScale(s); }

    @Override public ActionHandler.Outcome begin(Spec.Action a, ProductionContext c) {
        Params p = a.params();
        switch (a.action()) {
            case "title" -> {
                Title t = Title.title(Component.text(p.str("title", ""), NamedTextColor.WHITE), Component.text(p.str("subtitle", ""), NamedTextColor.GRAY),
                        Title.Times.times(Duration.ofMillis(p.integer("fade_in", 1500)), Duration.ofMillis(Math.max(500, a.durationTicks() * 50L)), Duration.ofMillis(p.integer("fade_out", 1500))));
                for (Player pl : c.audience()) pl.showTitle(t);
            }
            case "time_scale" -> { apply(Math.max(0, p.dbl("scale", 1.0))); }
            case "freeze" -> { restoreScale = scale; apply(0.0); freezeLeft = Math.max(1, a.durationTicks()); }
            case "fade_world" -> env.fadeLights((int) Math.round(p.dbl("to_level", 0)), Math.max(1, a.durationTicks()));
            default -> { return ActionHandler.Outcome.fail("PresentationModule does not implement '" + a.action() + "'"); }
        }
        return ActionHandler.Outcome.OK;
    }
    @Override public void tick(ProductionContext c, int sceneTick, int globalTick) { if (!paused && freezeLeft > 0 && --freezeLeft == 0) { freezeLeft = -1; apply(restoreScale); } }
    @Override public void pause() { paused = true; }
    @Override public void resume() { paused = false; }
    @Override public void cleanup(boolean restoreWorld) { apply(1.0); freezeLeft = -1; }
}
