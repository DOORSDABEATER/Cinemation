package com.des.cinematic.motion;

import com.des.cinematic.core.*;
import java.util.*;

/** A deterministic position-over-time curve. t is in ticks from plan start; at(duration()) is EXACTLY the destination. */
public interface MotionPlan {
    int duration();
    Vec3 at(int t);
    Vec3 destination();

    /** Straight move with easing. */
    record Linear(Vec3 from, Vec3 to, int duration, Ease ease) implements MotionPlan {
        public Linear { duration = Math.max(1, duration); }
        public Vec3 at(int t) { return from.lerp(to, ease.apply((double) t / duration)); }
        public Vec3 destination() { return to; }
    }

    /** Constant-speed travel along a polyline (walk/run/follow_path). speed in blocks per tick. */
    final class Path implements MotionPlan {
        private final List<Vec3> pts; private final double[] cum; private final int duration; private final Ease ease;
        public Path(List<Vec3> points, double speed, Ease ease) {
            if (points.size() < 2) throw new IllegalArgumentException("path needs at least 2 points");
            this.pts = List.copyOf(points); this.ease = ease;
            cum = new double[pts.size()];
            for (int i = 1; i < pts.size(); i++) cum[i] = cum[i - 1] + pts.get(i).dist(pts.get(i - 1));
            duration = Math.max(1, (int) Math.ceil(cum[cum.length - 1] / Math.max(1e-6, speed)));
        }
        public int duration() { return duration; }
        public double length() { return cum[cum.length - 1]; }
        public Vec3 destination() { return pts.get(pts.size() - 1); }
        public Vec3 at(int t) {
            if (t >= duration) return destination();
            double d = ease.apply((double) t / duration) * length();
            int i = 1; while (i < cum.length - 1 && cum[i] < d) i++;
            double seg = cum[i] - cum[i - 1];
            double f = seg < 1e-9 ? 1 : (d - cum[i - 1]) / seg;
            return pts.get(i - 1).lerp(pts.get(i), f);
        }
    }

    /**
     * Ballistic arc for jump / leap / launch / knockback. Horizontal motion is eased, the vertical term adds a parabola
     * of height `apex` above the chord, so the actor lands at exactly `to`.
     */
    record Arc(Vec3 from, Vec3 to, double apex, int duration, Ease horizontal) implements MotionPlan {
        public Arc { duration = Math.max(2, duration); }
        public Vec3 at(int t) {
            double u = Math.min(1.0, (double) t / duration);
            double h = horizontal.apply(u);
            Vec3 chord = from.lerp(to, h);
            double lift = 4.0 * apex * u * (1.0 - u);
            return new Vec3(chord.x(), from.y() + (to.y() - from.y()) * u + lift, chord.z());
        }
        public Vec3 destination() { return to; }
    }

    /** Standard speeds, blocks/tick (config can override). */
    record Speeds(double walk, double run) { public static final Speeds DEFAULT = new Speeds(0.12, 0.34); }

    static MotionPlan walk(Vec3 from, Vec3 to, Speeds s) { return new Path(List.of(from, to), s.walk(), Ease.LINEAR); }
    static MotionPlan run(Vec3 from, Vec3 to, Speeds s) { return new Path(List.of(from, to), s.run(), Ease.LINEAR); }
}
