// Vendored from the DeS Azrathiel module (same owner) so DeSCinematicEngine has no hard dependency on that plugin. Package renamed; logic unchanged.
package com.des.cinematic.vael;

/** Indices of the continuous pose parameters that drive the rig. Angles are degrees, speeds deg/s, lengths blocks. */
public final class P {
    private P() {}
    public static final int TORSO_PITCH = 0, TORSO_ROLL = 1, LEAN = 2, SINK = 3,
            ARM_RAISE = 4,   // 4..7   upper-arm swing forward (+) / back (-)  [UL, UR, LL, LR]
            ARM_SPREAD = 8,  // 8..11  outward abduction
            FORE_BEND = 12,  // 12..15 forearm bend
            HALO_SPEED = 16, HALO_RADIUS = 17, HALO_TILT = 18,
            FRAG_RADIUS = 19, FRAG_SPEED = 20, FRAG_BOB = 21,
            CORE_SCALE = 22, CORE_PULSE = 23, HOVER_AMP = 24, HOVER_HZ = 25, BODY_SCALE = 26, GLOW = 27,
            COUNT = 28;
}
