package com.des.cinematic.core;

import java.util.*;

/** Immutable, parsed production model. Coordinates in specs are RELATIVE to the production origin. */
public final class Spec {
    private Spec() {}

    public record Action(String production, String scene, int index, int tick, String actor, String action, Params params, int durationTicks, boolean critical) {
        public String where() { return production + "/" + scene + "#" + index + " [t=" + tick + "] actor=" + (actor == null ? "-" : actor) + " action=" + action; }
    }
    public record Scene(String id, String name, int declaredDurationTicks, List<Action> actions) {
        public int endTick() {
            int e = declaredDurationTicks;
            for (Action a : actions) { e = Math.max(e, a.tick() + a.durationTicks()); if (a.action().equals("scene_end")) e = Math.max(e, a.tick()); }
            return e;
        }
    }
    public record Region(String id, Vec3 min, Vec3 max, boolean destructible) {
        public boolean contains(Vec3 p) {
            return p.x() >= min.x() && p.x() <= max.x() && p.y() >= min.y() && p.y() <= max.y() && p.z() >= min.z() && p.z() <= max.z();
        }
    }
    public record Production(String id, String displayName, String subtitle, String world, Vec3 origin, List<String> actors,
                             List<String> weapons, Set<String> sounds, Set<String> dialogue, List<Region> regions,
                             Map<String, Object> restoration, List<Scene> scenes) {
        public Optional<Scene> scene(String id) { return scenes.stream().filter(s -> s.id().equals(id)).findFirst(); }
        public int totalTicks() { return scenes.stream().mapToInt(Scene::endTick).sum(); }
    }
}
