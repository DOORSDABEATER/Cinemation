package com.des.cinematic.paper;

import com.des.cinematic.core.*;
import org.bukkit.configuration.file.YamlConfiguration;

import java.io.File;
import java.util.*;
import java.util.logging.Logger;

/** Loads productions/<id>/production.yml + scenes/*.yml + weapons/*.yml and actors/*.yml from the plugin folder. */
public final class ProductionLibrary {
    public record Loaded(Spec.Production spec, Map<String, Map<String, Object>> actorDefs, Map<String, Map<String, Object>> weaponDefs, List<Issue> issues, Map<String, Object> raw) {}

    private final File root; private final Logger log;
    private final Map<String, Loaded> productions = new TreeMap<>();

    public ProductionLibrary(File dataFolder, Logger log) { this.root = dataFolder; this.log = log; }

    public Collection<String> ids() { return productions.keySet(); }
    public Optional<Loaded> get(String id) { return Optional.ofNullable(productions.get(id)); }

    public void reload() {
        productions.clear();
        File dir = new File(root, "productions");
        File[] subs = dir.listFiles(File::isDirectory);
        if (subs == null) return;
        Arrays.sort(subs);
        Map<String, Map<String, Object>> actors = loadActors();
        Map<String, Map<String, Object>> origins = loadOrigins();
        for (File d : subs) {
            File pf = new File(d, "production.yml");
            if (!pf.isFile()) continue;
            List<Issue> issues = new ArrayList<>();
            try {
                Map<String, Object> prod = new LinkedHashMap<>(YamlIo.load(pf));
                String id = String.valueOf(prod.getOrDefault("id", d.getName()));
                Map<String, Object> ov = origins.get(id);
                if (ov != null) { prod.put("origin", List.of(num(ov.get("x")), num(ov.get("y")), num(ov.get("z")))); if (ov.get("world") != null) prod.put("world", ov.get("world")); }
                List<Map<String, Object>> scenes = loadScenes(d, prod, issues);
                Map<String, Map<String, Object>> weapons = loadWeapons(d);
                ProductionParser.Result r = ProductionParser.parse(prod, scenes);
                issues.addAll(r.issues());
                if (r.production() != null) productions.put(r.production().id(), new Loaded(r.production(), actors, weapons, issues, prod));
                else log.severe("Production in '" + d.getName() + "' could not be parsed: " + issues);
            } catch (RuntimeException e) { log.severe("Failed to load production '" + d.getName() + "': " + e.getMessage()); }
        }
        log.info("Loaded " + productions.size() + " production(s): " + productions.keySet());
    }

    /** Parse issues + static validation. Module-level asset validation is appended by the caller. */
    public List<Issue> validate(Loaded l) {
        List<Issue> out = new ArrayList<>(l.issues());
        Map<String, Set<String>> anims = new HashMap<>();
        for (String a : l.spec().actors()) {
            Map<String, Object> def = l.actorDefs().get(a);
            if (def == null) continue;
            Object m = def.get("animations");
            anims.put(a, m instanceof Map<?, ?> mm ? new HashSet<>(mm.keySet().stream().map(String::valueOf).toList()) : new HashSet<>());
        }
        out.addAll(Validator.validate(l.spec(), new Validator.Context(anims)));
        for (String w : l.spec().weapons()) if (!l.weaponDefs().containsKey(w)) out.add(Issue.error(l.spec().id(), "weapon '" + w + "' has no weapons/" + w + ".yml"));
        for (String key : l.spec().dialogue()) {
            Object d = ((Map<?, ?>) rawSection(l, "dialogue")).get(key);
            if (d instanceof Map<?, ?> dm && (dm.get("sound") == null || !l.spec().sounds().contains(String.valueOf(dm.get("sound")))))
                out.add(Issue.error(l.spec().id() + ".dialogue." + key, "'sound' must name an entry in production.sounds"));
            if (d instanceof Map<?, ?> dm2 && dm2.get("text") == null)
                out.add(Issue.warn(l.spec().id() + ".dialogue." + key, "script text not supplied; the recording des_cinematic:voice/" + key + ".ogg is still required"));
        }
        return out;
    }

    private Map<?, ?> rawSection(Loaded l, String key) {
        File pf = new File(new File(new File(root, "productions"), l.spec().id()), "production.yml");
        try { Object o = YamlIo.load(pf).get(key); return o instanceof Map<?, ?> m ? m : Map.of(); } catch (RuntimeException e) { return Map.of(); }
    }

    private List<Map<String, Object>> loadScenes(File dir, Map<String, Object> prod, List<Issue> issues) {
        File sd = new File(dir, "scenes");
        File[] files = sd.listFiles((d, n) -> n.endsWith(".yml"));
        List<Map<String, Object>> out = new ArrayList<>();
        if (files == null) return out;
        Arrays.sort(files);
        Map<String, Map<String, Object>> byId = new LinkedHashMap<>();
        for (File f : files) {
            try { Map<String, Object> m = YamlIo.load(f); byId.put(String.valueOf(m.get("id")), m); }
            catch (RuntimeException e) { issues.add(Issue.error("scenes/" + f.getName(), e.getMessage())); }
        }
        Object order = prod.get("scene_order");
        if (order instanceof List<?> l) {
            for (Object o : l) { Map<String, Object> m = byId.remove(String.valueOf(o)); if (m == null) issues.add(Issue.error("production.yml", "scene_order lists '" + o + "' but no scene file has that id")); else out.add(m); }
            for (String left : byId.keySet()) issues.add(Issue.warn("scenes", "scene '" + left + "' is not in scene_order and will not run"));
        } else out.addAll(byId.values());
        return out;
    }

    private Map<String, Map<String, Object>> loadActors() {
        Map<String, Map<String, Object>> out = new LinkedHashMap<>();
        File[] files = new File(root, "actors").listFiles((d, n) -> n.endsWith(".yml"));
        if (files != null) for (File f : files) try { Map<String, Object> m = YamlIo.load(f); out.put(String.valueOf(m.getOrDefault("id", f.getName().replace(".yml", ""))), m); } catch (RuntimeException e) { log.severe(e.getMessage()); }
        return out;
    }
    private Map<String, Map<String, Object>> loadWeapons(File prodDir) {
        Map<String, Map<String, Object>> out = new LinkedHashMap<>();
        File[] files = new File(prodDir, "weapons").listFiles((d, n) -> n.endsWith(".yml"));
        if (files != null) for (File f : files) try { Map<String, Object> m = YamlIo.load(f); out.put(String.valueOf(m.getOrDefault("id", f.getName().replace(".yml", ""))), m); } catch (RuntimeException e) { log.severe(e.getMessage()); }
        return out;
    }
    @SuppressWarnings("unchecked")
    private Map<String, Map<String, Object>> loadOrigins() {
        File f = new File(root, "origins.yml");
        Map<String, Map<String, Object>> out = new HashMap<>();
        if (!f.isFile()) return out;
        YamlConfiguration y = YamlConfiguration.loadConfiguration(f);
        for (String k : y.getKeys(false)) { Object s = y.get(k); if (s instanceof org.bukkit.configuration.ConfigurationSection cs) out.put(k, YamlIo.toMap(cs)); }
        return out;
    }
    private static double num(Object o) { return o instanceof Number n ? n.doubleValue() : 0; }
}
