package com.des.cinematic.paper;

import com.des.cinematic.api.CinematicEngine;
import org.bukkit.plugin.java.JavaPlugin;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;

public final class DeSCinematicPlugin extends JavaPlugin {
    private ProductionService service;

    @Override public void onEnable() {
        saveDefaultConfig();
        Fx.log = getLogger();
        installDefaults();
        ProductionLibrary lib = new ProductionLibrary(getDataFolder(), getLogger());
        lib.reload();
        service = new ProductionService(this, lib);
        ActorModule actors = new ActorModule(this); service.registerModule(actors);
        EnvironmentModule env = new EnvironmentModule(this); service.registerModule(env); env.recoverOnEnable();
        service.registerModule(new AudioModule(this, actors));
        WeaponModule weapons = new WeaponModule(this, actors, env);
        CombatModule combat = new CombatModule(this, actors);
        weapons.setCombat(combat);
        service.registerModule(weapons); service.registerModule(combat);
        PresentationModule presentation = new PresentationModule(env, actors, weapons); combat.setPresentation(presentation);
        service.registerModule(new FxModule(this, actors));
        service.registerModule(presentation);
        CinematicEngine.set(service);
        CinematicCommand cmd = new CinematicCommand(this, service);
        var pc = getCommand("descinematic");
        if (pc == null) { getLogger().severe("command 'descinematic' missing from plugin.yml"); getServer().getPluginManager().disablePlugin(this); return; }
        pc.setExecutor(cmd); pc.setTabCompleter(cmd);
        getLogger().info("DeS Live Cinematic Engine enabled. Modules registered: " + service.modules().size()
                + "  (all subsystems registered; the Paper layer is still uncompiled/untested on a server)");
    }

    @Override public void onDisable() {
        if (service != null) service.shutdown();
        CinematicEngine.set(null);
    }

    /** Copies bundled default files (listed in defaults.index) into the data folder without overwriting edits. */
    private void installDefaults() {
        try (var in = getResource("defaults.index")) {
            if (in == null) { getLogger().warning("defaults.index missing from jar; no default productions installed"); return; }
            BufferedReader r = new BufferedReader(new InputStreamReader(in, StandardCharsets.UTF_8));
            String line;
            while ((line = r.readLine()) != null) {
                line = line.trim();
                if (line.isEmpty() || line.startsWith("#")) continue;
                if (!new java.io.File(getDataFolder(), line).exists()) saveResource(line, false);
            }
        } catch (java.io.IOException e) { getLogger().severe("could not install defaults: " + e.getMessage()); }
    }
}
