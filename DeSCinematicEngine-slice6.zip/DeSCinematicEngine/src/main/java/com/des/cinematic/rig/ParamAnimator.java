package com.des.cinematic.rig;

import com.des.cinematic.vael.P;
import com.des.cinematic.vael.ParamSource;

/** Plays one ParamClip at a time with crossfade. Implements ParamSource so the AZRATHIEL rig can read it directly. */
public final class ParamAnimator implements ParamSource {
    private ParamClip clip; private double time; private float[] from; private int blendLeft, blendTotal; private float[] cur = new float[P.COUNT]; private boolean finished;

    public void play(ParamClip c, int blendTicks) {
        from = blendTicks > 0 ? cur.clone() : null; blendTotal = blendLeft = Math.max(0, blendTicks); clip = c; time = 0; finished = false; cur = c.sample(0);
        if (from != null) for (int i = 0; i < cur.length; i++) cur[i] = from[i];
    }
    public String clipId() { return clip == null ? null : clip.id(); }
    public boolean finished() { return finished; }
    @Override public float get(int i) { return cur[i]; }
    public void tick() {
        if (clip == null) return;
        time += 1;
        if (!clip.loops() && time >= clip.duration()) { time = clip.duration(); finished = true; }
        float[] target = clip.sample(time);
        if (blendLeft > 0 && from != null) { blendLeft--; float f = 1f - (float) blendLeft / blendTotal; float e = f * f * (3 - 2 * f); for (int i = 0; i < cur.length; i++) cur[i] = from[i] + (target[i] - from[i]) * e; }
        else cur = target;
    }
}
