package com.des.cinematic.paper;

import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;

import java.io.File;
import java.util.*;

/** YAML -> plain Maps/Lists so the pure core never sees Bukkit types. */
final class YamlIo {
    private YamlIo() {}
    static Map<String, Object> load(File f) {
        YamlConfiguration y = new YamlConfiguration();
        try { y.load(f); } catch (Exception e) { throw new IllegalStateException("cannot read " + f.getName() + ": " + e.getMessage(), e); }
        return toMap(y);
    }
    static Map<String, Object> load(java.io.Reader r, String name) {
        YamlConfiguration y = new YamlConfiguration();
        try { y.load(r); } catch (Exception e) { throw new IllegalStateException("cannot read " + name + ": " + e.getMessage(), e); }
        return toMap(y);
    }
    static Map<String, Object> toMap(ConfigurationSection s) {
        Map<String, Object> out = new LinkedHashMap<>();
        for (String k : s.getKeys(false)) out.put(k, convert(s.get(k)));
        return out;
    }
    private static Object convert(Object o) {
        if (o instanceof ConfigurationSection cs) return toMap(cs);
        if (o instanceof Map<?, ?> m) { Map<String, Object> r = new LinkedHashMap<>(); for (Map.Entry<?, ?> e : m.entrySet()) r.put(String.valueOf(e.getKey()), convert(e.getValue())); return r; }
        if (o instanceof List<?> l) { List<Object> r = new ArrayList<>(); for (Object e : l) r.add(convert(e)); return r; }
        return o;
    }
}
