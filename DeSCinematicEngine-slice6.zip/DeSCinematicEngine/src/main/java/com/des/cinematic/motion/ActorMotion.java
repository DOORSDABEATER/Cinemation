package com.des.cinematic.motion;

import com.des.cinematic.core.*;
import java.util.function.Supplier;

/**
 * Per-actor kinematic state. The server layer calls {@link #tick()} once per production tick and applies
 * {@link #pos()}/{@link #yaw()} to the rendered model. Multiple actors simply own multiple instances.
 */
public final class ActorMotion {
    private Vec3 pos; private double yaw, pitch;
    private MotionPlan plan; private int planT;
    private Supplier<Vec3> faceTarget; private Double fixedYaw;
    private double turnRate = 18.0;     // degrees per tick
    private Vec3 lastDelta = Vec3.ZERO;
    private boolean faceTravel = true;

    public ActorMotion(Vec3 pos, double yaw) { this.pos = pos; this.yaw = yaw; }

    public Vec3 pos() { return pos; }
    public double yaw() { return yaw; }
    public double pitch() { return pitch; }
    public Vec3 velocity() { return lastDelta; }
    public boolean moving() { return plan != null; }
    public MotionPlan plan() { return plan; }
    public void turnRate(double degPerTick) { this.turnRate = degPerTick; }

    /** Starts a plan, replacing any running one (scripted choreography decides; there is no implicit queueing). */
    public void move(MotionPlan p, boolean faceDirectionOfTravel) { this.plan = p; this.planT = 0; this.faceTravel = faceDirectionOfTravel; }
    public void teleport(Vec3 to) { plan = null; lastDelta = to.minus(pos); pos = to; }
    public void faceTarget(Supplier<Vec3> t) { faceTarget = t; fixedYaw = null; }
    public void faceYaw(double y) { fixedYaw = y; faceTarget = null; }
    public void clearFacing() { faceTarget = null; fixedYaw = null; }
    public void setYawImmediate(double y) { yaw = Angles.wrap(y); }

    public void tick() {
        Vec3 before = pos;
        if (plan != null) {
            planT++;
            pos = plan.at(planT);
            if (planT >= plan.duration()) { pos = plan.destination(); plan = null; }
        }
        lastDelta = pos.minus(before);
        double want = Double.NaN;
        if (faceTarget != null) want = Angles.yawTo(pos, faceTarget.get());
        else if (fixedYaw != null) want = fixedYaw;
        else if (faceTravel && lastDelta.lengthXZ() > 1e-4) want = Angles.yawTo(Vec3.ZERO, lastDelta);
        if (!Double.isNaN(want)) yaw = Angles.turnToward(yaw, want, turnRate);
    }
}
