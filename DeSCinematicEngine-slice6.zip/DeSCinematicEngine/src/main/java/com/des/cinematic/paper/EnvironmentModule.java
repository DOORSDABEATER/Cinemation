package com.des.cinematic.paper;

import com.des.cinematic.api.ActionModule;
import com.des.cinematic.api.ProductionContext;
import com.des.cinematic.core.*;
import org.bukkit.*;
import org.bukkit.block.Block;
import org.bukkit.block.TileState;
import org.bukkit.block.data.BlockData;
import org.bukkit.entity.BlockDisplay;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.util.Transformation;
import org.bukkit.util.Vector;
import org.joml.Quaternionf;
import org.joml.Vector3f;

import java.io.File;
import java.util.*;

/**
 * ENVIRONMENT actions. Safety model: (1) block edits are only accepted inside destructible regions; (2) every original block is
 * journalled to disk BEFORE it changes; (3) tile-entity blocks are never touched; (4) edits are applied in per-tick batches;
 * (5) restoration is batched, delayed by configuration, and recovered after crashes/restarts.
 */
public final class EnvironmentModule implements ActionModule {
    private interface Effect { /** @return true when finished */ boolean tick(); default boolean blocking() { return false; } default void stop() {} }
    private record Pending(int x, int y, int z, BlockData data) {}

    private final JavaPlugin plugin; private final File journalDir, structureDir;
    private BlockJournal journal; private String journalOwner;
    private final ArrayDeque<Pending> queue = new ArrayDeque<>();
    private final List<Effect> effects = new ArrayList<>();
    private final List<Debris> debris = new ArrayList<>();
    private final Map<String, List<int[]>> groups = new HashMap<>();   // absolute coords
    private final List<int[]> lightBlocks = new ArrayList<>();
    private int lightLevel = 6;
    private ProductionContext ctx; private boolean paused;
    private int rejected, skippedTiles, particleBudget, blockBudget; private final Set<String> warned = new HashSet<>();
    private final BlockResolver resolver;
    private BukkitRunnable restorer; private final Map<String, BlockJournal> orphanJournals = new LinkedHashMap<>();

    public EnvironmentModule(JavaPlugin plugin) {
        this.plugin = plugin; this.resolver = new BlockResolver(plugin.getLogger());
        this.journalDir = new File(plugin.getDataFolder(), plugin.getConfig().getString("restoration.journal-dir", "recovery"));
        this.structureDir = new File(plugin.getDataFolder(), "structures");
    }

    @Override public String id() { return "environment"; }
    @Override public Set<ActionCatalog.Category> categories() { return EnumSet.of(ActionCatalog.Category.ENVIRONMENT); }
    public int lightLevel() { return lightLevel; }
    /** Used by PresentationModule (fade_world): smoothly drives the structure's hidden light blocks. */
    public void fadeLights(int level, int ticks) { lightTo(level, ticks); }

    // ------------------------------------------------------------------ lifecycle / recovery
    /** Called from onEnable: finish any restoration a crash or restart interrupted. */
    public void recoverOnEnable() {
        File[] files = journalDir.listFiles((d, n) -> n.endsWith(".journal"));
        if (files == null || files.length == 0) return;
        for (File f : files) {
            String pid = f.getName().replace(".journal", "");
            BlockJournal j = new BlockJournal(journalDir, pid, plugin.getLogger());
            if (j.loadFromDisk()) { orphanJournals.put(pid, j); plugin.getLogger().warning("Recovering " + j.size() + " unrestored block(s) of production '" + pid + "' after an unclean stop."); }
        }
        if (!orphanJournals.isEmpty()) startRestorer(20);
    }

    @Override public String preflight(String productionId) {
        if (orphanJournals.containsKey(productionId) || (journal != null && journal.restoring())) return "the world of '" + productionId + "' is still being restored from an earlier run; wait for it to finish or use /descinematic reset " + productionId;
        return null;
    }

    @Override public void productionStarted(ProductionContext c) {
        ctx = c; paused = false; rejected = skippedTiles = 0; queue.clear(); effects.clear(); warned.clear();
        journalOwner = c.spec().id();
        journal = new BlockJournal(journalDir, journalOwner, plugin.getLogger());
        if (journal.loadFromDisk()) { plugin.getLogger().warning("Found a stale journal for '" + journalOwner + "'; restoring it before building anything."); journal.beginRestore(); while (!journal.restoreBatch(20000, 64)) { } journal = new BlockJournal(journalDir, journalOwner, plugin.getLogger()); }
    }

    @Override public void tick(ProductionContext c, int sceneTick, int globalTick) {
        if (paused) return;
        ctx = c; blockBudget = plugin.getConfig().getInt("performance.max-block-changes-per-tick", 400); particleBudget = plugin.getConfig().getInt("performance.max-particles-per-tick", 600);
        effects.removeIf(Effect::tick);
        drainQueue(c);
        debris.removeIf(d -> d.tick(c));
        if (journal != null) journal.flush();
    }
    @Override public boolean busy() { if (!queue.isEmpty()) return true; for (Effect e : effects) if (e.blocking()) return true; return false; }
    @Override public void pause() { paused = true; }
    @Override public void resume() { paused = false; }

    @Override public void cleanup(boolean restoreWorld) {
        for (Effect e : effects) e.stop();
        effects.clear(); queue.clear();
        for (Debris d : debris) d.remove(); debris.clear();
        PlayerDisplayRig.sweepOrphans();
        if (journal != null && journal.size() > 0) {
            int delay = restoreWorld ? 1 : 20 * (int) new Params(ctx == null ? Map.of() : ctx.spec().restoration()).dbl("delay_seconds", plugin.getConfig().getDouble("restoration.default-delay-seconds", 60));
            orphanJournals.put(journalOwner, journal); journal = null;
            plugin.getLogger().info("Restoring " + orphanJournals.get(journalOwner).size() + " block(s) of '" + journalOwner + "' " + (restoreWorld ? "now" : "in " + delay / 20 + "s") + ".");
            startRestorer(delay);
        }
        groups.clear(); lightBlocks.clear();
        if (rejected > 0 || skippedTiles > 0) plugin.getLogger().warning("environment: " + rejected + " block edit(s) rejected outside destructible regions, " + skippedTiles + " tile-entity block(s) left untouched.");
    }

    @Override public void reset(String productionId) {
        BlockJournal j = orphanJournals.get(productionId);
        if (j == null && journal != null && productionId.equals(journalOwner)) { j = journal; journal = null; orphanJournals.put(productionId, j); }
        if (j == null) { BlockJournal d = new BlockJournal(journalDir, productionId, plugin.getLogger()); if (d.loadFromDisk()) { orphanJournals.put(productionId, d); j = d; } }
        if (j != null) { j.beginRestore(); startRestorer(1); }
    }

    @Override public void shutdown() {
        if (restorer != null) { restorer.cancel(); restorer = null; }
        if (journal != null && journal.size() > 0) orphanJournals.put(journalOwner, journal);
        for (BlockJournal j : orphanJournals.values()) { if (!j.restoring()) j.beginRestore(); int guard = 0; while (!j.restoreBatch(50000, 256) && guard++ < 1000) { } }
        orphanJournals.clear();
    }

    private void startRestorer(int delayTicks) {
        if (restorer != null) { restorer.cancel(); }
        final int[] wait = {delayTicks};
        restorer = new BukkitRunnable() {
            @Override public void run() {
                if (wait[0]-- > 0) return;
                int cap = plugin.getConfig().getInt("restoration.batch-size", 300);
                Iterator<Map.Entry<String, BlockJournal>> it = orphanJournals.entrySet().iterator();
                int budget = cap;
                while (it.hasNext() && budget > 0) {
                    Map.Entry<String, BlockJournal> e = it.next();
                    if (!e.getValue().restoring()) e.getValue().beginRestore();
                    if (e.getValue().restoreBatch(budget, 2)) { plugin.getLogger().info("World of '" + e.getKey() + "' fully restored."); it.remove(); }
                    budget = 0;     // one journal per tick keeps the per-tick budget honest
                }
                if (orphanJournals.isEmpty()) { cancel(); restorer = null; }
            }
        };
        restorer.runTaskTimer(plugin, 1L, 1L);
    }

    // ------------------------------------------------------------------ safe block editing
    private int ox, oy, oz;
    private void origin(ProductionContext c) { Location o = c.origin(); ox = o.getBlockX(); oy = o.getBlockY(); oz = o.getBlockZ(); }
    private boolean inRegion(ProductionContext c, int x, int y, int z) {
        Vec3 rel = new Vec3(x - ox, y - oy, z - oz);
        for (Spec.Region r : c.spec().regions()) if (r.destructible() && r.contains(rel)) return true;
        return false;
    }
    private void enqueue(int x, int y, int z, BlockData d) { queue.add(new Pending(x, y, z, d)); }
    private BlockData data(String s) { return Bukkit.createBlockData(s); }

    private void drainQueue(ProductionContext c) {
        origin(c); World w = c.world(); int loads = 4;
        while (blockBudget > 0 && !queue.isEmpty()) {
            Pending p = queue.poll();
            if (!inRegion(c, p.x, p.y, p.z)) { rejected++; if (warned.add("rej")) plugin.getLogger().severe("environment: REJECTED a block edit outside every destructible region at " + p.x + "," + p.y + "," + p.z); continue; }
            if (!w.isChunkLoaded(p.x >> 4, p.z >> 4)) { if (loads-- <= 0) { queue.addFirst(p); break; } w.loadChunk(p.x >> 4, p.z >> 4, true); }
            Block b = w.getBlockAt(p.x, p.y, p.z);
            if (b.getState() instanceof TileState) { skippedTiles++; continue; }          // never modify tile entities
            journal.record(BlockJournal.key(w, p.x, p.y, p.z), b.getBlockData());
            if (!b.getBlockData().equals(p.data)) b.setBlockData(p.data, false);
            blockBudget--;
        }
    }

    // ------------------------------------------------------------------ validation
    @Override public List<Issue> validate(Spec.Production p, Map<String, Map<String, Object>> actorDefs, Map<String, Map<String, Object>> weaponDefs) {
        List<Issue> out = new ArrayList<>(); Set<String> seen = new HashSet<>();
        for (Spec.Scene s : p.scenes()) for (Spec.Action a : s.actions()) {
            if (a.action().equals("env_build")) {
                String sid = a.params().str("structure", "");
                File f = new File(structureDir, sid + ".yml");
                if (!f.isFile()) { out.add(Issue.error(a.where(), "structure file structures/" + sid + ".yml not found")); continue; }
                if (!seen.add(sid)) continue;
                try {
                    Spec.Region reg = p.regions().stream().filter(r -> r.id().equals(a.params().str("region", ""))).findFirst().orElse(null);
                    if (reg == null) { out.add(Issue.error(a.where(), "unknown region '" + a.params().str("region", "") + "'")); continue; }
                    StructureBuilder.Result r = StructureBuilder.build(YamlIo.load(f), reg);
                    out.addAll(r.issues());
                    Set<String> names = new TreeSet<>(); for (StructureBuilder.Op o : r.ops()) names.add(o.block());
                    for (String n : names) {
                        BlockCompat.Resolution res = resolver.resolve(n, r.fallbacks()); String w = "structures/" + sid + ".yml";
                        switch (res.kind()) {
                            case EXACT -> { if (!res.resolved().equals(n)) out.add(Issue.info(w, "block '" + n + "' accepted on this server as '" + res.resolved() + "'")); }
                            case RENAMED -> out.add(Issue.info(w, "block '" + n + "' is not valid on this server; using its renamed form '" + res.resolved() + "' (tried " + res.tried() + ")"));
                            case FALLBACK -> out.add(Issue.warn(w, "block '" + n + "' is unavailable on this server; using the declared FALLBACK '" + res.resolved() + "' at the same positions (tried " + res.tried() + ")"));
                            case UNRESOLVED -> out.add(Issue.error(w, "unknown block '" + n + "' on this server version; no spelling or fallback worked (tried " + res.tried() + ")"));
                        }
                    }
                    out.add(Issue.info("structures/" + sid + ".yml", r.ops().size() + " blocks, built in about " + String.format("%.0f", r.ops().size() / (double) plugin.getConfig().getInt("performance.max-block-changes-per-tick", 400) / 20.0) + "s at the configured batch size"));
                } catch (RuntimeException e) { out.add(Issue.error("structures/" + sid + ".yml", e.getMessage())); }
            }
            if (a.action().equals("env_particles") && a.params().has("particle")) try { Particle.valueOf(a.params().str("particle", "").toUpperCase(Locale.ROOT)); } catch (IllegalArgumentException e) { out.add(Issue.error(a.where(), "unknown particle '" + a.params().str("particle", "") + "'")); }
            if (a.action().equals("env_activate") && !EFFECTS.contains(a.params().str("effect", ""))) out.add(Issue.error(a.where(), "unknown effect '" + a.params().str("effect", "") + "' (known: " + EFFECTS + ")"));
        }
        return out;
    }
    private static final Set<String> EFFECTS = new TreeSet<>(List.of("inscriptions_dim", "inscriptions_glow", "pedestal_energy_fade", "low_rumble", "distortion_reveal", "atmosphere_distort", "space_distortion"));

    // ------------------------------------------------------------------ actions
    @Override public ActionHandler.Outcome begin(Spec.Action a, ProductionContext c) {
        ctx = c; origin(c);
        try { return run(a, c); }
        catch (IllegalArgumentException | IllegalStateException | NullPointerException | ClassCastException e) { return ActionHandler.Outcome.fail(a.action() + ": " + e.getClass().getSimpleName() + " " + e.getMessage()); }
    }

    private Location at(ProductionContext c, Params p, String key) { Vec3 v = p.vec(key); if (v == null) throw new IllegalArgumentException("'" + key + "' must be [x,y,z]"); return c.abs(v); }
    private int floorY(Location l) { return (int) Math.floor(l.getY()) - 1; }
    private Random rng(Spec.Action a) { return new Random(a.where().hashCode() * 31L + a.tick()); }

    private ActionHandler.Outcome run(Spec.Action a, ProductionContext c) {
        Params p = a.params(); World w = c.world();
        switch (a.action()) {
            case "env_build" -> { return build(a, c); }
            case "env_block_change" -> {
                Vec3 mn = p.vec("min"), mx = p.vec("max"); if (mn == null || mx == null) return ActionHandler.Outcome.fail("env_block_change needs min and max");
                BlockData d = data(p.str("block", "minecraft:air"));
                for (int y = (int) mn.y(); y <= mx.y(); y++) for (int x = (int) mn.x(); x <= mx.x(); x++) for (int z = (int) mn.z(); z <= mx.z(); z++) enqueue(ox + x, oy + y, oz + z, d);
            }
            case "env_restore" -> { if (journal != null && journal.size() > 0) { orphanJournals.put(journalOwner, journal); journal = new BlockJournal(journalDir, journalOwner + "_n", plugin.getLogger()); startRestorer(1); } }
            case "env_activate" -> { return activate(a, c); }
            case "env_light" -> lightTo(p.integer("level", 6), a.durationTicks());
            case "env_particles" -> particles(a, c);
            case "env_tremor" -> tremor(a, c);
            case "env_crack" -> crack(a, c);
            case "env_crater" -> crater(a, c);
            case "env_explosion" -> explosion(a, c);
            case "env_shockwave" -> shockwave(a, c);
            case "env_debris" -> spawnDebris(a, c, at(c, p, "at"), p.integer("count", 20), p.bool("persist", false));
            case "env_pillar_collapse" -> pillarCollapse(a, c);
            default -> { return ActionHandler.Outcome.fail("EnvironmentModule does not implement '" + a.action() + "'"); }
        }
        return ActionHandler.Outcome.OK;
    }

    // ---- structure building
    private ActionHandler.Outcome build(Spec.Action a, ProductionContext c) {
        File f = new File(structureDir, a.params().str("structure", "") + ".yml");
        if (!f.isFile()) return ActionHandler.Outcome.fail("structure file missing: " + f.getName());
        Spec.Region reg = c.spec().regions().stream().filter(r -> r.id().equals(a.params().str("region", ""))).findFirst().orElse(null);
        if (reg == null || !reg.destructible()) return ActionHandler.Outcome.fail("region '" + a.params().str("region", "") + "' is not a destructible region");
        StructureBuilder.Result r = StructureBuilder.build(YamlIo.load(f), reg);
        if (!r.issues().isEmpty()) return ActionHandler.Outcome.fail("structure invalid: " + r.issues().get(0));
        // the arena must be clear: interior blocks are not removed
        if (r.clearMin() != null && r.clearMax() != null) {
            Random rnd = rng(a); int solid = 0, n = Math.max(20, r.samples());
            for (int i = 0; i < n; i++) {
                int x = ox + (int) (r.clearMin().x() + rnd.nextDouble() * (r.clearMax().x() - r.clearMin().x())), y = oy + (int) (r.clearMin().y() + rnd.nextDouble() * (r.clearMax().y() - r.clearMin().y())), z = oz + (int) (r.clearMin().z() + rnd.nextDouble() * (r.clearMax().z() - r.clearMin().z()));
                if (!c.world().isChunkLoaded(x >> 4, z >> 4)) c.world().loadChunk(x >> 4, z >> 4, true);
                if (c.world().getBlockAt(x, y, z).getType().isSolid()) solid++;
            }
            if (solid / (double) n > r.maxSolidRatio()) return ActionHandler.Outcome.fail(String.format("the arena is not clear: %.0f%% of sampled interior blocks are solid (max %.0f%%). Build the chamber on a flat, empty plot at the origin.", 100.0 * solid / n, 100.0 * r.maxSolidRatio()));
        }
        Map<String, BlockData> cache = new HashMap<>();
        for (StructureBuilder.Op o : r.ops()) enqueue(ox + o.x(), oy + o.y(), oz + o.z(), cache.computeIfAbsent(o.block(), bn -> resolver.data(bn, r.fallbacks())));
        groups.clear(); r.groups().forEach((k, v) -> groups.put(k, v.stream().map(q -> new int[]{ox + q[0], oy + q[1], oz + q[2]}).toList()));
        lightBlocks.clear(); for (int[] q : r.lights()) lightBlocks.add(new int[]{ox + q[0], oy + q[1], oz + q[2]});
        lightLevel = r.lightLevel();
        plugin.getLogger().info("env_build '" + r.id() + "': " + r.ops().size() + " blocks queued");
        return ActionHandler.Outcome.OK;
    }

    // ---- lighting
    private void lightTo(int target, int ticks) {
        final int from = lightLevel, to = Math.max(0, Math.min(15, target)); final int dur = Math.max(1, ticks); final int[] t = {0};
        effects.add(new Effect() {
            public boolean tick() { t[0]++; int lvl = from + Math.round((to - from) * Math.min(1f, (float) t[0] / dur)); if (lvl != lightLevel) { setLights(lvl); } return t[0] >= dur; }
        });
    }
    private void setLights(int lvl) { lightLevel = lvl; BlockData d = data("minecraft:light[level=" + lvl + "]"); for (int[] q : lightBlocks) enqueue(q[0], q[1], q[2], d); }

    // ---- named effects
    private ActionHandler.Outcome activate(Spec.Action a, ProductionContext c) {
        String e = a.params().str("effect", "");
        switch (e) {
            case "inscriptions_dim" -> setGroup("inscriptions", "minecraft:chiseled_deepslate", 0);
            case "inscriptions_glow" -> setGroup("inscriptions", "minecraft:crying_obsidian", Math.max(40, a.durationTicks()));
            case "pedestal_energy_fade" -> pedestalEnergy = false;
            case "low_rumble" -> {
                final int[] t = {0}; final int dur = Math.max(20 * 6, a.durationTicks());
                effects.add(new Effect() { public boolean tick() { if (t[0]++ % 30 == 0) c.world().playSound(c.origin(), "minecraft:entity.warden.heartbeat", SoundCategory.AMBIENT, 2.5f, 0.5f); return t[0] >= dur; } });
            }
            case "distortion_reveal" -> distortion(c, a, c.abs(new Vec3(0, 2.5, -6)), 3.0, 20 * 10, Particle.REVERSE_PORTAL);
            case "atmosphere_distort" -> distortion(c, a, c.abs(new Vec3(0, 6, -8)), 10.0, 20 * 25, Particle.PORTAL);
            case "space_distortion" -> distortion(c, a, c.abs(new Vec3(-3, 3, -3.5)), 12.0, 20 * 25, Particle.REVERSE_PORTAL);
            default -> { return ActionHandler.Outcome.fail("unknown effect '" + e + "'"); }
        }
        return ActionHandler.Outcome.OK;
    }
    private boolean pedestalEnergy = true; public boolean pedestalEnergy() { return pedestalEnergy; }

    private void setGroup(String group, String block, int spreadTicks) {
        List<int[]> g = groups.get(group); if (g == null) throw new IllegalStateException("group '" + group + "' does not exist (was env_build run?)");
        BlockData d = data(block);
        List<int[]> order = new ArrayList<>(g); order.sort(Comparator.comparingInt(q -> q[2]));        // a wave travelling down the hall
        if (spreadTicks <= 0) { for (int[] q : order) enqueue(q[0], q[1], q[2], d); return; }
        final int per = Math.max(1, order.size() / spreadTicks + 1); final int[] i = {0};
        effects.add(new Effect() { public boolean tick() { for (int k = 0; k < per && i[0] < order.size(); k++, i[0]++) { int[] q = order.get(i[0]); enqueue(q[0], q[1], q[2], d); } return i[0] >= order.size(); } });
    }

    private void distortion(ProductionContext c, Spec.Action a, Location def, double radius, int defDur, Particle pt) {
        Params p = a.params(); Location at = p.has("at") ? at(c, p, "at") : def; double r = p.dbl("radius", radius); int dur = p.has("duration") ? a.durationTicks() : defDur; final int[] t = {0}; Random rnd = rng(a);
        effects.add(new Effect() { public boolean tick() {
            int n = Math.min(40, particleBudget); particleBudget -= n;
            for (int i = 0; i < n; i++) { double ang = rnd.nextDouble() * Math.PI * 2, rr = r * Math.sqrt(rnd.nextDouble()), h = (rnd.nextDouble() - 0.5) * r;
                Location l = at.clone().add(Math.cos(ang) * rr, h, Math.sin(ang) * rr); Vector toC = new Vector(at.getX() - l.getX(), at.getY() - l.getY(), at.getZ() - l.getZ()).normalize().multiply(0.06);
                Fx.spawn(c.world(), pt, l, 0, toC.getX(), toC.getY(), toC.getZ(), 1.0); }
            return ++t[0] >= dur; } });
    }

    // ---- particles
    private void particles(Spec.Action a, ProductionContext c) {
        Params p = a.params(); Location at = at(c, p, "at");
        Particle pt; try { pt = Particle.valueOf(p.str("particle", "end_rod").toUpperCase(Locale.ROOT)); } catch (IllegalArgumentException e) { throw new IllegalArgumentException("unknown particle '" + p.str("particle", "") + "'"); }
        final int total = p.integer("count", 40), dur = Math.max(1, a.durationTicks()); final double spread = p.dbl("spread", 1.0); final String mode = p.str("mode", "cloud");
        final int[] t = {0}; Random rnd = rng(a);
        effects.add(new Effect() { public boolean tick() {
            int n = Math.min(Math.max(1, total / dur), particleBudget); particleBudget -= n;
            for (int i = 0; i < n; i++) {
                double ang = rnd.nextDouble() * Math.PI * 2, rr = spread * Math.sqrt(rnd.nextDouble()), h = (rnd.nextDouble() - 0.3) * spread;
                switch (mode) {
                    case "implode" -> { Location l = at.clone().add(Math.cos(ang) * spread, (rnd.nextDouble() - 0.5) * spread, Math.sin(ang) * spread); Fx.spawn(c.world(), pt, l, 0, (at.getX() - l.getX()) * 0.12, (at.getY() - l.getY()) * 0.12, (at.getZ() - l.getZ()) * 0.12, 1.0); }
                    case "radiate" -> Fx.spawn(c.world(), pt, at, 0, Math.cos(ang) * 0.35, rnd.nextDouble() * 0.2, Math.sin(ang) * 0.35, 1.0);
                    case "float_up" -> Fx.spawn(c.world(), pt, at.clone().add(Math.cos(ang) * rr, 0, Math.sin(ang) * rr), 0, 0, 0.08 + rnd.nextDouble() * 0.06, 0, 1.0);
                    default -> Fx.spawn(c.world(), pt, at.clone().add(Math.cos(ang) * rr, h, Math.sin(ang) * rr), 1, 0, 0, 0, 0.01);
                }
            }
            return ++t[0] >= dur; } });
    }
    private void tremor(Spec.Action a, ProductionContext c) {
        Params p = a.params(); Location at = at(c, p, "at"); double r = p.dbl("radius", 20); int dur = Math.max(20, a.durationTicks()); final int[] t = {0}; Random rnd = rng(a);
        BlockData floor = c.world().getBlockAt(at.getBlockX(), floorY(at), at.getBlockZ()).getBlockData();
        effects.add(new Effect() { public boolean tick() {
            int n = Math.min(12, particleBudget); particleBudget -= n;
            for (int i = 0; i < n; i++) { double ang = rnd.nextDouble() * Math.PI * 2, rr = r * Math.sqrt(rnd.nextDouble()); Location l = at.clone().add(Math.cos(ang) * rr, 0.15, Math.sin(ang) * rr); Fx.spawn(c.world(), Particle.BLOCK, l, 4, 0.2, 0.05, 0.2, 0.02, floor); }
            if (t[0] % 12 == 0) c.world().playSound(at, "minecraft:block.deepslate_bricks.break", SoundCategory.AMBIENT, 1.8f, 0.5f);
            return ++t[0] >= dur; } });
    }

    // ---- cracks, craters, explosions, shockwaves
    private static final Map<Material, Material> CRACKED = Map.of(Material.DEEPSLATE_TILES, Material.CRACKED_DEEPSLATE_TILES, Material.DEEPSLATE_BRICKS, Material.CRACKED_DEEPSLATE_BRICKS,
            Material.POLISHED_BLACKSTONE_BRICKS, Material.CRACKED_POLISHED_BLACKSTONE_BRICKS, Material.STONE_BRICKS, Material.CRACKED_STONE_BRICKS);
    private void crack(Spec.Action a, ProductionContext c) {
        Params p = a.params(); Location at = at(c, p, "at"); int r = p.integer("radius", 4), fy = floorY(at); int dur = Math.max(1, a.durationTicks()); Random rnd = rng(a);
        int lines = 5 + r / 2; double[] ang = new double[lines], px = new double[lines], pz = new double[lines]; for (int i = 0; i < lines; i++) { ang[i] = i * 2 * Math.PI / lines + rnd.nextDouble() * 0.6; px[i] = at.getX(); pz[i] = at.getZ(); }
        final int[] t = {0}; int steps = Math.max(1, r * 2);
        effects.add(new Effect() { public boolean tick() {
            int k = Math.min(steps, (int) Math.ceil(steps * (t[0] + 1.0) / dur)) - Math.min(steps, (int) Math.ceil(steps * (double) t[0] / dur));
            for (int s = 0; s < k; s++) for (int i = 0; i < lines; i++) {
                ang[i] += (rnd.nextDouble() - 0.5) * 0.7; px[i] += Math.cos(ang[i]) * 0.5; pz[i] += Math.sin(ang[i]) * 0.5;
                if (Math.hypot(px[i] - at.getX(), pz[i] - at.getZ()) > r) continue;
                Block b = c.world().getBlockAt((int) Math.floor(px[i]), fy, (int) Math.floor(pz[i]));
                Material m = CRACKED.get(b.getType()); if (m != null) enqueue(b.getX(), b.getY(), b.getZ(), Bukkit.createBlockData(m));
                else if (b.getType().isSolid()) enqueue(b.getX(), b.getY(), b.getZ(), Bukkit.createBlockData(Material.BLACKSTONE));
            }
            return ++t[0] >= dur; }
            public boolean blocking() { return true; } });
    }
    private void crater(Spec.Action a, ProductionContext c) {
        Params p = a.params(); Location at = at(c, p, "at"); int r = p.integer("radius", 4), depth = p.integer("depth", 2), fy = floorY(at);
        List<int[]> cols = new ArrayList<>();
        for (int dx = -r - 1; dx <= r + 1; dx++) for (int dz = -r - 1; dz <= r + 1; dz++) { double d = Math.sqrt(dx * dx + dz * dz); if (d <= r + 1) cols.add(new int[]{dx, dz, (int) Math.round(d * 100)}); }
        cols.sort(Comparator.comparingInt(q -> q[2]));
        final int per = Math.max(1, cols.size() / Math.max(1, a.durationTicks()) + 1); final int[] i = {0};
        BlockData air = Bukkit.createBlockData(Material.AIR), rim = Bukkit.createBlockData(Material.BLACKSTONE);
        effects.add(new Effect() { public boolean tick() {
            for (int k = 0; k < per && i[0] < cols.size(); k++, i[0]++) {
                int[] q = cols.get(i[0]); double d = q[2] / 100.0; int x = at.getBlockX() + q[0], z = at.getBlockZ() + q[1];
                if (d > r) { Block b = c.world().getBlockAt(x, fy, z); if (b.getType().isSolid()) enqueue(x, fy, z, rim); continue; }   // charred rim
                int dh = (int) Math.round(depth * (1.0 - (d / r) * (d / r)));
                for (int y = fy; y > fy - dh; y--) enqueue(x, y, z, air);
                if (i[0] % 6 == 0 && particleBudget > 0) { particleBudget--; Fx.spawn(c.world(), Particle.CAMPFIRE_COSY_SMOKE, x + 0.5, fy + 1, z + 0.5, 0, 0, 0.12, 0, 1.0); }
            }
            return i[0] >= cols.size(); }
            public boolean blocking() { return true; } });
    }
    private void explosion(Spec.Action a, ProductionContext c) {
        Params p = a.params(); Location at = at(c, p, "at"); String pw = p.str("power", "medium");
        int r = switch (pw) { case "small" -> 2; case "massive" -> 9; default -> 4; };
        Fx.spawn(c.world(), Particle.EXPLOSION_EMITTER, at, pw.equals("massive") ? 6 : pw.equals("medium") ? 2 : 1, r * 0.3, r * 0.15, r * 0.3, 0);
        Fx.spawn(c.world(), Particle.FLASH, at, 1, 0, 0, 0, 0);
        Fx.spawn(c.world(), Particle.LAVA, at, 20 + r * 6, r * 0.4, 0.2, r * 0.4, 0);
        Fx.dust(c.world(), at, 30 + r * 12, r * 0.45, 0x8A4DFF, 2.4f); Fx.spawn(c.world(), Particle.SOUL_FIRE_FLAME, at, 20 + r * 8, r * 0.35, r * 0.25, r * 0.35, 0.12); Fx.spawn(c.world(), Particle.CLOUD, at, 15 + r * 6, r * 0.4, 0.15, r * 0.4, 0.2);
        for (Player pl : c.audience()) { pl.playSound(at, "minecraft:entity.generic.explode", SoundCategory.MASTER, 3.0f, pw.equals("massive") ? 0.55f : 0.85f); if (pw.equals("massive")) pl.playSound(at, "minecraft:entity.lightning_bolt.thunder", SoundCategory.MASTER, 3.0f, 0.5f); }
        // scorch the floor (inside destructible regions only; nothing is destroyed, no damage to anyone)
        int fy = oy - 1; Random rnd = rng(a); BlockData scorch = Bukkit.createBlockData(Material.BLACKSTONE), magma = Bukkit.createBlockData(Material.MAGMA_BLOCK);
        for (int dx = -r; dx <= r; dx++) for (int dz = -r; dz <= r; dz++) { double d = Math.sqrt(dx * dx + dz * dz); if (d <= r && rnd.nextDouble() > d / (r + 1.0) * 0.8) { Block b = c.world().getBlockAt(at.getBlockX() + dx, fy, at.getBlockZ() + dz); if (b.getType().isSolid()) enqueue(b.getX(), fy, b.getZ(), d < r * 0.25 && rnd.nextInt(5) == 0 ? magma : scorch); } }
    }
    private void shockwave(Spec.Action a, ProductionContext c) {
        Params p = a.params(); Location at = at(c, p, "at"); double R = p.dbl("radius", 10); int dur = Math.max(2, a.durationTicks()); final int[] t = {0};
        effects.add(new Effect() { public boolean tick() {
            double f = Ease.OUT_CUBIC.apply((t[0] + 1.0) / dur), r = Math.max(0.5, R * f); int pts = Math.min(Math.max(16, (int) (r * 8)), particleBudget); particleBudget -= pts;
            for (int i = 0; i < pts; i++) { double ang = i * 2 * Math.PI / pts; Location l = at.clone().add(Math.cos(ang) * r, 0.25, Math.sin(ang) * r); Fx.spawn(c.world(), Particle.CLOUD, l, 0, Math.cos(ang) * 0.25, 0.04, Math.sin(ang) * 0.25, 1.0); if (i % 4 == 0) Fx.spawn(c.world(), Particle.CRIT, l, 1, 0, 0.1, 0, 0.05); if (i % 3 == 0) { Fx.dust(c.world(), l, 1, 0.1, 0x9B6BFF, 1.8f); Fx.spawn(c.world(), Particle.BLOCK, l, 2, 0.2, 0.05, 0.2, 0.05); } }
            return ++t[0] >= dur; } });
    }

    // ---- debris & pillars (BlockDisplay physics; never real FallingBlocks, so nothing escapes the journal)
    private final class Debris {
        final BlockDisplay d; double x, y, z, vx, vy, vz; int age, life; final double floor; boolean landed; float rx, ry, rz, sx, sy, sz;
        Debris(BlockDisplay d, Location l, double vx, double vy, double vz, int life, double floor) { this.d = d; x = l.getX(); y = l.getY(); z = l.getZ(); this.vx = vx; this.vy = vy; this.vz = vz; this.life = life; this.floor = floor; }
        boolean tick(ProductionContext c) {
            if (!d.isValid()) return true;
            if (++age >= life) { d.remove(); return true; }
            if (!landed) {
                vy -= 0.045; x += vx; y += vy; z += vz; rx += sx; ry += sy; rz += sz;
                if (y <= floor) { y = floor; landed = true; vx = vy = vz = 0; }
                d.setTeleportDuration(2); d.teleport(new Location(c.world(), x, y, z));
                Transformation t = d.getTransformation(); d.setInterpolationDelay(0); d.setInterpolationDuration(2);
                d.setTransformation(new Transformation(t.getTranslation(), new Quaternionf().rotateXYZ(rx, ry, rz), t.getScale(), new Quaternionf()));
            }
            return false;
        }
        void remove() { if (d.isValid()) d.remove(); }
    }
    private boolean spawnPiece(ProductionContext c, Location l, BlockData bd, double vx, double vy, double vz, int life, double floor, Random rnd) {
        if (debris.size() >= plugin.getConfig().getInt("performance.max-display-entities", 600)) return false;
        float s = 0.25f + rnd.nextFloat() * 0.45f;
        BlockDisplay bdsp = c.world().spawn(l, BlockDisplay.class, e -> { e.setBlock(bd); e.setPersistent(false); e.setInvulnerable(true); e.setGravity(false); e.setViewRange(2f); e.addScoreboardTag(PlayerDisplayRig.TAG);
            e.setTransformation(new Transformation(new Vector3f(-s / 2, 0, -s / 2), new Quaternionf(), new Vector3f(s, s, s), new Quaternionf())); });
        Debris d = new Debris(bdsp, l, vx, vy, vz, life, floor); d.sx = (rnd.nextFloat() - 0.5f) * 0.4f; d.sy = (rnd.nextFloat() - 0.5f) * 0.4f; d.sz = (rnd.nextFloat() - 0.5f) * 0.4f; debris.add(d); return true;
    }
    private void spawnDebris(Spec.Action a, ProductionContext c, Location at, int count, boolean persist) {
        Random rnd = rng(a); Block under = c.world().getBlockAt(at.getBlockX(), Math.max(c.world().getMinHeight(), at.getBlockY() - 1), at.getBlockZ());
        BlockData bd = under.getType().isSolid() && !(under.getState() instanceof TileState) ? under.getBlockData() : Bukkit.createBlockData(Material.DEEPSLATE_BRICKS);
        int life = persist ? 20 * 600 : 20 * (4 + rnd.nextInt(5)); double floor = oy;
        for (int i = 0; i < count; i++) { double ang = rnd.nextDouble() * Math.PI * 2, sp = 0.15 + rnd.nextDouble() * 0.45; if (!spawnPiece(c, at.clone().add(0, 0.5, 0), bd, Math.cos(ang) * sp, 0.25 + rnd.nextDouble() * 0.5, Math.sin(ang) * sp, life, floor, rnd)) break; }
    }
    private void pillarCollapse(Spec.Action a, ProductionContext c) {
        Params p = a.params(); Location base = at(c, p, "at"); int h = p.integer("height", 12), bx = base.getBlockX(), bz = base.getBlockZ(), by = oy; int dur = Math.max(10, a.durationTicks());
        Random rnd = rng(a); double lean = rnd.nextDouble() * Math.PI * 2; int stump = 2; int tiers = h - 1 - stump; final int[] t = {0};
        BlockData air = Bukkit.createBlockData(Material.AIR), rubble = Bukkit.createBlockData(Material.COBBLED_DEEPSLATE);
        effects.add(new Effect() { int tier = 0;
            public boolean tick() {
                int want = Math.min(tiers, (int) Math.ceil(tiers * (t[0] + 1.0) / dur));
                while (tier < want) {
                    int y = by + h - 1 - tier;
                    for (int dx = -2; dx <= 2; dx++) for (int dz = -2; dz <= 2; dz++) {
                        Block b = c.world().getBlockAt(bx + dx, y, bz + dz); if (b.getType().isAir() || b.getState() instanceof TileState) continue;
                        if (rnd.nextInt(3) == 0) spawnPiece(c, b.getLocation().add(0.5, 0.5, 0.5), b.getBlockData(), Math.cos(lean) * 0.12 + (rnd.nextDouble() - 0.5) * 0.2, 0.05 + rnd.nextDouble() * 0.15, Math.sin(lean) * 0.12 + (rnd.nextDouble() - 0.5) * 0.2, 20 * 25, by, rnd);
                        enqueue(bx + dx, y, bz + dz, air);
                    }
                    Fx.spawn(c.world(), Particle.CAMPFIRE_COSY_SMOKE, bx + 0.5, y + 0.5, bz + 0.5, 6, 1.2, 0.5, 1.2, 0.02);
                    tier++;
                }
                if (t[0] % 8 == 0) c.world().playSound(base, "minecraft:block.deepslate_bricks.break", SoundCategory.MASTER, 2.2f, 0.6f);
                if (++t[0] >= dur && tier >= tiers) { for (int y = by + 1; y <= by + stump; y++) for (int dx = -1; dx <= 1; dx++) for (int dz = -1; dz <= 1; dz++) if (!c.world().getBlockAt(bx + dx, y, bz + dz).getType().isAir()) enqueue(bx + dx, y, bz + dz, rubble); return true; }
                return false; }
            public boolean blocking() { return true; } });
    }
}
