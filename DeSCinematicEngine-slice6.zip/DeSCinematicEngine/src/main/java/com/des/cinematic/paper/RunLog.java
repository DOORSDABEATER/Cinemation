package com.des.cinematic.paper;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

/** One text file per production run: every action that began, every failure and every module exception. Send this when something looks wrong. */
final class RunLog implements Closeable {
    private final BufferedWriter out; final File file;
    RunLog(File dir, String productionId) throws IOException {
        dir.mkdirs();
        file = new File(dir, productionId + "-" + LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMdd-HHmmss")) + ".log");
        out = Files.newBufferedWriter(file.toPath(), StandardCharsets.UTF_8, StandardOpenOption.CREATE_NEW);
    }
    synchronized void line(String s) { try { out.write(s); out.newLine(); } catch (IOException ignored) { } }
    synchronized void flush() { try { out.flush(); } catch (IOException ignored) { } }
    @Override public synchronized void close() { try { out.close(); } catch (IOException ignored) { } }
}
