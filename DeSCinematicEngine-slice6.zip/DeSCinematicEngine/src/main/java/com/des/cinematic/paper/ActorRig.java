package com.des.cinematic.paper;

import com.des.cinematic.rig.Pose;
import org.bukkit.Location;

/** A visible, animated body in the world. Implementations: PlayerDisplayRig (ERROR). Future: ModelEngine / AZRATHIEL adapters. */
public interface ActorRig {
    /** Place the actor at a world location and apply a pose. yaw is the Minecraft yaw of the actor's facing. Called once per tick. */
    void render(Location feet, double yaw, Pose pose);
    /** Remove every entity this rig created. Idempotent. */
    void remove();
    boolean isValid();
}
