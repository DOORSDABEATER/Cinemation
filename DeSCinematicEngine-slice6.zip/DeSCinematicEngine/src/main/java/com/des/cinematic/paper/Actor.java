package com.des.cinematic.paper;

import com.des.cinematic.api.ProductionContext;
import com.des.cinematic.core.*;
import com.des.cinematic.motion.ActorMotion;
import com.des.cinematic.motion.MotionPlan;

import java.util.List;
import java.util.Map;

/** One cinematic actor: kinematics (ActorMotion) + a visible animated body. Positions are origin-relative. */
public final class Actor {
    public final String id; public final String displayName;
    private final ActorBody body; private final ActorMotion motion; private final MotionPlan.Speeds speeds;
    private String baseAnim = "idle"; private boolean autoReturn; private String locomotionAnim; private int revertIn = -1;
    private int trailRgb = 0x5B3CC4; public int trailRgb() { return trailRgb; } void trailRgb(int c) { trailRgb = c; }
    private double chest = 1.2, radius = 0.4;
    public double chest() { return chest; } public double radius() { return radius; }
    void dims(double chest, double radius) { this.chest = chest; this.radius = radius; }
    private double hover, hoverFrom, hoverTo; private int hoverT, hoverDur; private double timeAcc;

    Actor(String id, String displayName, ActorBody body, ActorMotion motion, MotionPlan.Speeds speeds) {
        this.id = id; this.displayName = displayName; this.body = body; this.motion = motion; this.speeds = speeds;
    }
    public Vec3 pos() { return motion.pos(); }
    public double yaw() { return motion.yaw(); }
    public ActorMotion motion() { return motion; }
    public MotionPlan.Speeds speeds() { return speeds; }
    public boolean moving() { return motion.moving(); }
    public String currentAnimation() { return body.currentAnimation(); }
    public boolean hasAnimation(String logical) { return body.hasAnimation(logical); }
    private static final Map<String, List<String>> FALLBACKS = Map.of(
            "walk", List.of("walk", "walk_slow", "idle"), "run", List.of("run", "stride", "walk_slow", "walk", "idle"), "jump", List.of("jump", "walk_slow", "idle"),
            "knockback", List.of("knockback", "stagger", "hit_light", "hit", "idle"), "launch_fly", List.of("launch_fly", "knockback", "stagger", "hit_light", "idle"),
            "land", List.of("land", "idle"), "get_up", List.of("get_up", "idle"), "hit", List.of("hit", "hit_light", "stagger", "idle"));
    /** A DEFAULT animation name (not explicitly requested by the scene) degrades to the closest one this actor has. An explicit name never does. */
    public String resolveDefault(String logical) {
        for (String c : FALLBACKS.getOrDefault(logical, List.of(logical))) if (body.hasAnimation(c)) return c;
        return logical;
    }
    ActorBody body() { return body; }

    /** Play a logical animation. hold=true keeps it; otherwise it reverts to the base animation when finished (or after durationTicks for looping ones). */
    public void play(String logical, int blend, boolean hold, int durationTicks) {
        boolean loops = body.play(logical, blend);
        autoReturn = !hold && !loops; revertIn = (!hold && loops && durationTicks > 0) ? durationTicks : -1;
    }
    public void play(String logical, int blend, boolean hold) { play(logical, blend, hold, 0); }
    public void setBase(String logical) { baseAnim = logical; }

    /** Starts a motion plan with a locomotion animation; returns to the base animation when the plan ends. */
    public void move(MotionPlan plan, boolean faceTravel, String anim) {
        motion.move(plan, faceTravel);
        if (anim != null) { play(anim, 5, true); locomotionAnim = anim; } else locomotionAnim = null;
    }
    public void hover(double blocks, int ticks) { hoverFrom = hover; hoverTo = blocks; hoverDur = Math.max(1, ticks); hoverT = 0; }

    void tick(ProductionContext ctx, double timeScale) {
        timeAcc += timeScale;
        while (timeAcc >= 1.0) { timeAcc -= 1.0; step(); }
        render(ctx);
    }
    private void step() {
        boolean wasMoving = motion.moving();
        motion.tick();
        if (hoverT < hoverDur) { hoverT++; double f = (double) hoverT / hoverDur; hover = hoverFrom + (hoverTo - hoverFrom) * (f * f * (3 - 2 * f)); }
        body.tick();
        if (revertIn > 0 && --revertIn == 0) { revertIn = -1; revertToBase(); }
        else if (wasMoving && !motion.moving() && locomotionAnim != null) { locomotionAnim = null; revertToBase(); }
        else if (autoReturn && body.animationFinished() && !motion.moving()) { autoReturn = false; revertToBase(); }
    }
    private void revertToBase() { if (body.hasAnimation(baseAnim)) { body.play(baseAnim, 6); autoReturn = false; } }
    void render(ProductionContext ctx) {
        Vec3 p = motion.pos();
        body.render(ctx.abs(new Vec3(p.x(), p.y() + hover, p.z())), motion.yaw());
    }
    void remove() { body.remove(); }
    boolean valid() { return body.isValid(); }
}
