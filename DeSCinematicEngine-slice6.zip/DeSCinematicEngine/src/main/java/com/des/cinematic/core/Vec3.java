package com.des.cinematic.core;

/** Immutable 3D vector. Pure Java: no server dependency, so it can be unit-tested offline. */
public record Vec3(double x, double y, double z) {
    public static final Vec3 ZERO = new Vec3(0, 0, 0);
    public Vec3 plus(Vec3 o) { return new Vec3(x + o.x, y + o.y, z + o.z); }
    public Vec3 minus(Vec3 o) { return new Vec3(x - o.x, y - o.y, z - o.z); }
    public Vec3 scale(double s) { return new Vec3(x * s, y * s, z * s); }
    public double length() { return Math.sqrt(x * x + y * y + z * z); }
    public double lengthXZ() { return Math.sqrt(x * x + z * z); }
    public double dist(Vec3 o) { return minus(o).length(); }
    public double distXZ(Vec3 o) { return minus(o).lengthXZ(); }
    public Vec3 lerp(Vec3 o, double t) { return new Vec3(x + (o.x - x) * t, y + (o.y - y) * t, z + (o.z - z) * t); }
    public Vec3 normalizedXZ() { double l = lengthXZ(); return l < 1e-9 ? ZERO : new Vec3(x / l, 0, z / l); }
    @Override public String toString() { return String.format("(%.2f, %.2f, %.2f)", x, y, z); }
}
