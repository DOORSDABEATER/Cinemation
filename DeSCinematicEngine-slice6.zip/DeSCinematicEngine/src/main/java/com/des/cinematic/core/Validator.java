package com.des.cinematic.core;

import java.util.*;

/** Static production checks. Asset-level checks (models, .ogg files) are done by the server layer. */
public final class Validator {
    /** actorAnims: actor id -> logical animation names its definition maps. */
    public record Context(Map<String, Set<String>> actorAnims) {}

    private static final Set<String> POSITION_KEYS = Set.of("at", "to", "from", "origin");
    private static final Set<String> DESTRUCTIVE = Set.of("env_build", "env_crack", "env_crater", "env_pillar_collapse", "env_block_change", "env_explosion", "env_debris");

    public static List<Issue> validate(Spec.Production p, Context ctx) {
        List<Issue> out = new ArrayList<>();
        for (String a : p.actors()) if (!ctx.actorAnims().containsKey(a)) out.add(Issue.error(p.id(), "actor '" + a + "' has no definition in actors/" + a + ".yml"));

        Set<String> spawned = new HashSet<>();
        for (Spec.Scene s : p.scenes()) {
            for (Spec.Action a : s.actions()) {
                String w = a.where();
                Optional<ActionCatalog.Def> defO = ActionCatalog.get(a.action());
                if (defO.isEmpty()) { out.add(Issue.error(w, "unknown action '" + a.action() + "'")); continue; }
                ActionCatalog.Def def = defO.get();

                if (def.needsActor()) {
                    if (a.actor() == null) { out.add(Issue.error(w, "action requires an 'actor'")); continue; }
                    if (!p.actors().contains(a.actor())) out.add(Issue.error(w, "actor '" + a.actor() + "' is not listed in production.actors"));
                }
                for (String req : def.required()) {
                    boolean ok = false;
                    for (String alt : req.split("\\|")) if (a.params().has(alt)) ok = true;
                    if (!ok) out.add(Issue.error(w, "missing required parameter '" + req + "'"));
                }
                // coordinates must parse
                for (String k : POSITION_KEYS) if (a.params().has(k) && a.params().vec(k) == null) out.add(Issue.error(w, "'" + k + "' must be [x,y,z]"));
                if (a.params().has("path") && a.params().path("path") == null) out.add(Issue.error(w, "'path' contains a malformed waypoint"));
                // cross references
                if (a.params().has("target") && !p.actors().contains(a.params().str("target", "")) && !a.params().str("target", "").startsWith("@"))
                    out.add(Issue.error(w, "target '" + a.params().str("target", "") + "' is not a production actor (use @x,y,z style via 'at' for points)"));
                if (a.params().has("weapon") && !p.weapons().contains(a.params().str("weapon", ""))) out.add(Issue.error(w, "weapon '" + a.params().str("weapon", "") + "' is not listed in production.weapons"));
                if (a.params().has("sound") && !p.sounds().contains(a.params().str("sound", ""))) out.add(Issue.error(w, "sound '" + a.params().str("sound", "") + "' is not defined in production.sounds"));
                if (a.params().has("line") && !p.dialogue().contains(a.params().str("line", ""))) out.add(Issue.error(w, "dialogue line '" + a.params().str("line", "") + "' is not defined in production.dialogue"));
                if (a.params().has("anim") && a.actor() != null) {
                    Set<String> anims = ctx.actorAnims().get(a.actor());
                    if (anims != null && !anims.contains(a.params().str("anim", ""))) out.add(Issue.error(w, "animation '" + a.params().str("anim", "") + "' is not mapped in actors/" + a.actor() + ".yml"));
                }
                // spawn bookkeeping
                if (a.action().equals("spawn") && a.actor() != null) spawned.add(a.actor());
                else if (def.needsActor() && a.actor() != null && !spawned.contains(a.actor()) && !a.action().equals("despawn"))
                    out.add(Issue.warn(w, "actor '" + a.actor() + "' is used before any 'spawn' in an earlier action"));
                // region safety for anything that edits blocks
                if (DESTRUCTIVE.contains(a.action())) {
                    Vec3 at = a.params().vec("at");
                    if (at != null && p.regions().stream().noneMatch(r -> r.destructible() && r.contains(at)))
                        out.add(Issue.error(w, "destructive action at " + at + " is outside every destructible region (blocks may only change inside configured regions)"));
                    if (a.params().has("region") && p.regions().stream().noneMatch(r -> r.id().equals(a.params().str("region", "")) && r.destructible()))
                        out.add(Issue.error(w, "region '" + a.params().str("region", "") + "' is not a destructible region"));
                }
                if (a.durationTicks() < 0 || a.durationTicks() > 20 * 600) out.add(Issue.warn(w, "suspicious duration " + a.durationTicks() + " ticks"));
            }
            if (s.actions().isEmpty()) out.add(Issue.warn(p.id() + "/" + s.id(), "scene has no actions"));
        }
        return out;
    }
    public static boolean hasErrors(List<Issue> l) { return l.stream().anyMatch(i -> i.severity() == Issue.Severity.ERROR); }
}
