package com.des.cinematic;

import com.des.cinematic.core.*;
import java.nio.file.*;
import java.util.*;

/** Validates the REAL bundled production files with the REAL parser/validator (YAML pre-converted to JSON by tools/yaml_to_json.py). */
public final class ProductionFilesTest {
    // ---- minimal JSON reader (tests only)
    static final class J {
        final String s; int i;
        J(String s) { this.s = s; }
        Object parse() { ws(); char c = s.charAt(i);
            if (c == '{') { i++; Map<String, Object> m = new LinkedHashMap<>(); ws(); if (s.charAt(i) == '}') { i++; return m; }
                while (true) { ws(); String k = str(); ws(); i++; m.put(k, parse()); ws(); if (s.charAt(i++) == '}') return m; } }
            if (c == '[') { i++; List<Object> l = new ArrayList<>(); ws(); if (s.charAt(i) == ']') { i++; return l; }
                while (true) { l.add(parse()); ws(); if (s.charAt(i++) == ']') return l; } }
            if (c == '"') return str();
            if (s.startsWith("true", i)) { i += 4; return true; } if (s.startsWith("false", i)) { i += 5; return false; } if (s.startsWith("null", i)) { i += 4; return null; }
            int st = i; while (i < s.length() && "+-0123456789.eE".indexOf(s.charAt(i)) >= 0) i++; return Double.parseDouble(s.substring(st, i)); }
        String str() { StringBuilder b = new StringBuilder(); i++; while (s.charAt(i) != '"') { char c = s.charAt(i++); if (c == '\\') { char n = s.charAt(i++); switch (n) { case 'n' -> b.append('\n'); case 't' -> b.append('\t'); case 'u' -> { b.append((char) Integer.parseInt(s.substring(i, i + 4), 16)); i += 4; } default -> b.append(n); } } else b.append(c); } i++; return b.toString(); }
        void ws() { while (i < s.length() && Character.isWhitespace(s.charAt(i))) i++; }
    }
    @SuppressWarnings("unchecked") static Map<String, Object> m(Object o) { return (Map<String, Object>) o; }

    public static void main(String[] args) throws Exception {
        Map<String, Object> bundle = m(new J(Files.readString(Path.of(args.length > 0 ? args[0] : "build/bundle.json"))).parse());
        Map<String, Object> actors = m(bundle.get("actors"));
        Map<String, Set<String>> anims = new HashMap<>();
        for (var e : actors.entrySet()) anims.put(e.getKey(), new HashSet<>(m(m(e.getValue()).get("animations")).keySet()));
        int errors = 0, total = 0;
        for (var pe : m(bundle.get("productions")).entrySet()) {
            Map<String, Object> pb = m(pe.getValue()), prod = m(pb.get("production")), scenes = m(pb.get("scenes")), weapons = m(pb.get("weapons"));
            List<Map<String, Object>> ordered = new ArrayList<>();
            for (Object id : (List<?>) prod.get("scene_order")) ordered.add(m(scenes.get(String.valueOf(id))));
            ProductionParser.Result r = ProductionParser.parse(prod, ordered);
            List<Issue> issues = new ArrayList<>(r.issues());
            if (r.production() != null) {
                issues.addAll(Validator.validate(r.production(), new Validator.Context(anims)));
                for (String w : r.production().weapons()) if (!weapons.containsKey(w)) issues.add(Issue.error(pe.getKey(), "missing weapon def " + w));
                // determinism: dry-run twice, identical
                String a = dry(r.production()), b = dry(r.production());
                if (!a.equals(b)) issues.add(Issue.error(pe.getKey(), "dry run not deterministic"));
                System.out.printf("%s: %d scenes, %.1fs, %d actions%n", pe.getKey(), r.production().scenes().size(), r.production().totalTicks() / 20.0,
                        r.production().scenes().stream().mapToInt(s -> s.actions().size()).sum());
                for (Spec.Scene s : r.production().scenes()) System.out.printf("   %-16s %6.1fs  %3d actions%n", s.id(), s.endTick() / 20.0, s.actions().size());
            }
            for (Issue i : issues) { System.out.println("  " + i); total++; if (i.severity() == Issue.Severity.ERROR) errors++; }
        }
        System.out.println("production files: " + errors + " error(s), " + (total - errors) + " other issue(s)");
        if (errors > 0) System.exit(1);
    }
    static String dry(Spec.Production p) {
        StringBuilder sb = new StringBuilder();
        ActionHandler h = new ActionHandler() {
            public Outcome begin(Spec.Action a) { sb.append(a.where()).append(';'); return Outcome.OK; }
            public void tick(int s, int g) {} public boolean busy() { return false; }
            public void sceneStarted(Spec.Scene s) {} public void sceneEnded(Spec.Scene s) {}
            public void pause() {} public void resume() {} public void cleanup(boolean r) {}
        };
        TimelineRunner r = new TimelineRunner(p, h, new TimelineRunner.Listener() {}, 0); r.start();
        int g = 0; while (r.active() && g++ < 100000) r.tick();
        return sb.toString();
    }
}
