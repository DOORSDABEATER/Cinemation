package com.des.cinematic;

import com.des.cinematic.core.*;
import java.nio.file.*;
import java.util.*;

public final class StructureTests {
    static int pass, fail;
    static void check(boolean c, String n) { if (c) pass++; else { fail++; System.out.println("FAIL: " + n); } }
    @SuppressWarnings("unchecked") static Map<String, Object> m(Object o) { return (Map<String, Object>) o; }
    public static void main(String[] a) throws Exception {
        Map<String, Object> bundle = m(new ProductionFilesTest.J(Files.readString(Path.of(a.length > 0 ? a[0] : "build/bundle.json"))).parse());
        Map<String, Object> prod = m(m(m(bundle.get("productions")).get("azrathiel_null_requiem")).get("production"));
        ProductionParser.Result pr = ProductionParser.parse(prod, List.of(Map.of("id", "x", "actions", List.of())));
        Spec.Region arena = pr.production().regions().get(0);
        StructureBuilder.Result r = StructureBuilder.build(m(m(bundle.get("structures")).get("sealed_chamber")), arena);
        check(r.issues().isEmpty(), "structure has no issues: " + r.issues());
        System.out.println("sealed_chamber: " + r.ops().size() + " blocks, " + r.groups().keySet().stream().filter(k -> k.startsWith("pillar")).count() + " pillars, "
                + r.groups().getOrDefault("inscriptions", List.of()).size() + " inscription blocks, " + r.lights().size() + " light blocks");
        check(r.ops().size() > 40000 && r.ops().size() < 120000, "plausible block count");
        check(r.groups().keySet().stream().filter(k -> k.startsWith("pillar")).count() == 12, "12 pillars");
        check(r.lights().size() == 8, "8 lights");
        // the aisle and every pedestal exist; the walking lane is not blocked by solids at standing height
        Set<String> solidAtStand = new HashSet<>();
        for (StructureBuilder.Op o : r.ops()) if (o.y() >= 0 && o.y() <= 2 && !o.block().contains("light")) solidAtStand.add(o.x() + "," + o.z());
        boolean laneClear = true; for (int z = -34; z <= 9; z++) if (solidAtStand.contains("0," + z)) laneClear = false;
        check(laneClear, "ERROR's lane x=0, z=-34..9 is free of solid blocks at standing height");
        check(r.ops().stream().anyMatch(o -> o.x() == -5 && o.y() == 0 && o.z() == 12 && o.block().contains("chiseled")), "NOISEFORM pedestal exists");
        check(r.ops().stream().anyMatch(o -> o.x() == 5 && o.y() == 0 && o.z() == 12), "NEBULUX pedestal exists");
        // floor top surface is y=-1 so standing level y=0 is air
        check(r.ops().stream().filter(o -> o.x() == 0 && o.z() == -20).noneMatch(o -> o.y() == 0), "standing level above the aisle is empty");
        // all coordinates also fit the vertical limits of a normal world after +origin y=64
        check(r.ops().stream().allMatch(o -> o.y() + 64 > -64 && o.y() + 64 < 320), "inside world height limits at origin y=64");
        // a deliberately-too-small region is rejected
        StructureBuilder.Result bad = StructureBuilder.build(m(m(bundle.get("structures")).get("sealed_chamber")), new Spec.Region("tiny", new Vec3(-5, -5, -5), new Vec3(5, 5, 5), true));
        check(bad.issues().stream().anyMatch(i -> i.message().contains("outside region")), "placements outside the region are rejected");
        System.out.println("structure tests: " + pass + " passed, " + fail + " failed");
        if (fail > 0) System.exit(1);
    }
}
