package com.des.cinematic;

import com.des.cinematic.core.*;
import com.des.cinematic.motion.*;
import java.util.*;

/** Dependency-free tests (no JUnit needed): run with tools/run_core_tests.sh */
public final class CoreTests {
    static int pass, fail;
    static void check(boolean c, String name) { if (c) pass++; else { fail++; System.out.println("FAIL: " + name); } }
    static Map<String, Object> act(Object time, String actor, String action, Object... kv) {
        Map<String, Object> m = new LinkedHashMap<>(); m.put("time", time); if (actor != null) m.put("actor", actor); m.put("action", action);
        for (int i = 0; i < kv.length; i += 2) m.put((String) kv[i], kv[i + 1]); return m;
    }
    static List<Double> v(double x, double y, double z) { return List.of(x, y, z); }

    /** Records every call so ordering/timing can be asserted. */
    static final class Rec implements ActionHandler {
        final List<String> log = new ArrayList<>(); boolean paused; int busyUntil = -1; int now; String failOn;
        public Outcome begin(Spec.Action a) { log.add(now + ":" + a.action() + (a.actor() == null ? "" : "@" + a.actor())); return a.action().equals(failOn) ? Outcome.fail("boom") : Outcome.OK; }
        public void tick(int s, int g) { now = g + 1; }
        public boolean busy() { return now <= busyUntil; }
        public void sceneStarted(Spec.Scene s) { log.add("S+" + s.id()); }
        public void sceneEnded(Spec.Scene s) { log.add("S-" + s.id()); }
        public void pause() { paused = true; } public void resume() { paused = false; }
        public void cleanup(boolean r) { log.add("cleanup:" + r); }
    }

    static Spec.Production sample(int graceTest) {
        Map<String, Object> prod = new LinkedHashMap<>();
        prod.put("id", "t"); prod.put("world", "w"); prod.put("origin", v(0, 64, 0)); prod.put("actors", List.of("a", "b"));
        prod.put("sounds", Map.of("boom", Map.of())); prod.put("weapons", List.of("w1"));
        prod.put("regions", Map.of("arena", Map.of("min", v(-10, -5, -10), "max", v(10, 20, 10), "destructible", true)));
        Map<String, Object> s1 = new LinkedHashMap<>(); s1.put("id", "one"); s1.put("duration", 1.0);
        s1.put("actions", List.of(
            act(0.5, "b", "spawn", "at", v(3, 0, 0)),
            act(0.0, "a", "spawn", "at", v(0, 0, 0)),
            act(0.0, "a", "walk_to", "to", v(2, 0, 0)),
            act(0.5, null, "sound", "sound", "boom")));
        Map<String, Object> s2 = new LinkedHashMap<>(); s2.put("id", "two");
        s2.put("actions", List.of(act(0.0, "a", "attack", "target", "b", "type", "punch"), act(0.1, null, "env_crater", "at", v(0, 0, 0), "radius", 3, "depth", 2)));
        ProductionParser.Result r = ProductionParser.parse(prod, List.of(s1, s2));
        check(r.ok(), "sample parses: " + r.issues());
        return r.production();
    }

    public static void main(String[] a) {
        // ---- motion
        Vec3 from = new Vec3(0, 0, 0), to = new Vec3(10, 3, -4);
        MotionPlan arc = new MotionPlan.Arc(from, to, 2.5, 20, Ease.OUT_QUAD);
        check(arc.at(arc.duration()).dist(to) < 1e-9, "arc lands exactly");
        double maxY = 0; for (int t = 0; t <= 20; t++) maxY = Math.max(maxY, arc.at(t).y());
        check(maxY > 3 + 1.0 && maxY < 3 + 2.5, "arc rises above destination but stays below chord+apex (" + maxY + ")");
        MotionPlan path = new MotionPlan.Path(List.of(new Vec3(0, 0, 0), new Vec3(10, 0, 0), new Vec3(10, 0, 10)), 0.5, Ease.LINEAR);
        check(path.duration() == 40, "path duration = length/speed (" + path.duration() + ")");
        check(path.at(20).dist(new Vec3(10, 0, 0)) < 1e-9, "path hits corner at half time");
        check(path.at(999).dist(new Vec3(10, 0, 10)) < 1e-9, "path clamps to end");
        check(MotionPlan.walk(from, new Vec3(0, 0, 6), MotionPlan.Speeds.DEFAULT).duration() == 50, "walk 6 blocks @0.12 = 50 ticks");
        double prev = 0; boolean mono = true; for (int t = 0; t <= 30; t++) { double d = new MotionPlan.Linear(from, to, 30, Ease.IN_OUT_CUBIC).at(t).dist(from); if (d + 1e-9 < prev) mono = false; prev = d; }
        check(mono, "eased linear is monotonic");

        // ---- angles / facing
        check(Math.abs(Angles.wrap(190) + 170) < 1e-9, "wrap 190 -> -170");
        check(Math.abs(Angles.turnToward(170, -170, 10) - (-180)) < 1e-9 || Math.abs(Angles.turnToward(170, -170, 10) - 180) < 1e-9, "turn takes shortest arc across the seam");
        check(Math.abs(Angles.yawTo(Vec3.ZERO, new Vec3(0, 0, 5))) < 1e-9, "yaw +Z = 0");
        check(Math.abs(Angles.yawTo(Vec3.ZERO, new Vec3(-5, 0, 0)) - 90) < 1e-9, "yaw -X = 90");
        ActorMotion am = new ActorMotion(Vec3.ZERO, 0); am.turnRate(10);
        am.faceTarget(() -> new Vec3(-10, 0, 0)); for (int i = 0; i < 5; i++) am.tick();
        check(Math.abs(am.yaw() - 50) < 1e-9, "yaw rotates 10deg/tick toward target, not instantly (" + am.yaw() + ")");
        for (int i = 0; i < 10; i++) am.tick(); check(Math.abs(am.yaw() - 90) < 1e-9, "yaw settles at target");
        ActorMotion mv = new ActorMotion(Vec3.ZERO, 0); mv.move(MotionPlan.walk(Vec3.ZERO, new Vec3(6, 0, 0), MotionPlan.Speeds.DEFAULT), true);
        int ticks = 0; while (mv.moving()) { mv.tick(); ticks++; }
        check(ticks == 50 && mv.pos().dist(new Vec3(6, 0, 0)) < 1e-9, "walk finishes at exact destination in 50 ticks");
        check(Math.abs(Math.abs(mv.yaw()) - 90) < 1e-6, "walker faces direction of travel");

        // ---- parser ordering
        Spec.Production p = sample(0);
        check(p.scenes().get(0).actions().get(0).actor().equals("a") && p.scenes().get(0).actions().get(1).action().equals("walk_to"), "same-tick actions keep file order; sorted by time");
        check(p.scenes().get(0).actions().get(2).tick() == 10 && p.scenes().get(0).actions().get(3).tick() == 10, "0.5 s = 10 ticks");

        // ---- validator
        Validator.Context ctx = new Validator.Context(Map.of("a", Set.of("idle", "punch"), "b", Set.of("idle")));
        List<Issue> iss = Validator.validate(p, ctx);
        check(!Validator.hasErrors(iss), "sample validates: " + iss);
        Map<String, Object> bad = new LinkedHashMap<>(); bad.put("id", "bad"); bad.put("world", "w"); bad.put("actors", List.of("a", "ghost"));
        bad.put("regions", Map.of("arena", Map.of("min", v(0, 0, 0), "max", v(5, 5, 5), "destructible", true)));
        Map<String, Object> bs = new LinkedHashMap<>(); bs.put("id", "s"); bs.put("actions", List.of(
            act(0, "a", "spawn", "at", v(0, 0, 0)), act(1, "a", "frobnicate"), act(1, "a", "walk_to"), act(1, "zed", "animate", "anim", "idle"),
            act(1, "a", "animate", "anim", "nope"), act(2, null, "env_crater", "at", v(50, 0, 0), "radius", 2, "depth", 1), act(2, null, "sound", "sound", "missing"),
            act(2, "a", "walk_to", "to", "somewhere")));
        List<Issue> bi = Validator.validate(ProductionParser.parse(bad, List.of(bs)).production(), ctx);
        String all = bi.toString();
        for (String needle : new String[]{"ghost", "unknown action 'frobnicate'", "missing required parameter 'to'", "'zed'", "'nope'", "outside every destructible region", "'missing'", "must be [x,y,z]"})
            check(all.contains(needle), "validator reports: " + needle);
        check(!ProductionParser.parse(new LinkedHashMap<>(), List.of()).ok(), "missing id is an error");

        // ---- runner: order, scene transition, completion
        Rec rec = new Rec(); TimelineRunner r = new TimelineRunner(p, rec, new TimelineRunner.Listener() {}, 100); r.start();
        int guard = 0; while (r.active() && guard++ < 1000) r.tick();
        check(r.state() == TimelineRunner.State.FINISHED, "runner finishes: " + r.status());
        String log = String.join(",", rec.log);
        check(log.startsWith("S+one,0:spawn@a,0:walk_to@a,10:spawn@b,10:sound"), "deterministic order: " + log);
        check(log.contains("S-one,S+two,"), "scene transition: " + log);
        check(log.endsWith("cleanup:false"), "finished cleanup: " + log);

        // ---- runner: pause freezes time
        Rec r2 = new Rec(); TimelineRunner run2 = new TimelineRunner(p, r2, new TimelineRunner.Listener() {}, 100); run2.start();
        for (int i = 0; i < 5; i++) run2.tick(); run2.pause(); int frozen = run2.globalTick();
        for (int i = 0; i < 50; i++) run2.tick();
        check(run2.globalTick() == frozen && r2.paused, "pause freezes the clock");
        run2.resume(); check(!r2.paused && run2.state() == TimelineRunner.State.RUNNING, "resume continues");

        // ---- runner: critical failure aborts with context + cleanup
        Rec r3 = new Rec(); r3.failOn = "walk_to"; final String[] seen = new String[1];
        TimelineRunner run3 = new TimelineRunner(p, r3, new TimelineRunner.Listener() { public void onActionFailed(Spec.Action ac, String why, boolean ab) { seen[0] = ac.where() + "|" + why + "|" + ab; } }, 100); run3.start();
        for (int i = 0; i < 10; i++) run3.tick();
        check(run3.state() == TimelineRunner.State.FAILED, "critical failure fails production");
        check(seen[0] != null && seen[0].contains("t/one#") && seen[0].contains("actor=a") && seen[0].contains("walk_to") && seen[0].endsWith("|boom|true"), "failure names production/scene/actor/action: " + seen[0]);
        check(r3.log.contains("cleanup:true"), "failure restores world");

        // ---- runner: stop mid-run
        Rec r4 = new Rec(); TimelineRunner run4 = new TimelineRunner(p, r4, new TimelineRunner.Listener() {}, 100); run4.start(); run4.tick(); run4.stop(true);
        check(run4.state() == TimelineRunner.State.STOPPED && r4.log.contains("cleanup:true"), "stop cleans up");

        // ---- runner: busy handler holds scene end, grace timeout releases it
        Rec r5 = new Rec(); r5.busyUntil = 40; TimelineRunner run5 = new TimelineRunner(p, r5, new TimelineRunner.Listener() {}, 1000); run5.start();
        int firstEnd = -1; for (int i = 0; i < 200 && run5.active(); i++) { run5.tick(); if (firstEnd < 0 && r5.log.contains("S-one")) firstEnd = i; }
        check(firstEnd >= 39, "busy handler holds scene end until idle (ended at " + firstEnd + ")");

        // ---- runner: partial run finishes cleanly after the chosen scene
        Rec r6 = new Rec(); TimelineRunner run6 = new TimelineRunner(p, r6, new TimelineRunner.Listener() {}, 100); run6.stopAfterScene(0); run6.start();
        int g6 = 0; while (run6.active() && g6++ < 1000) run6.tick();
        String l6 = String.join(",", r6.log);
        check(run6.state() == TimelineRunner.State.FINISHED && l6.contains("S-one") && !l6.contains("S+two"), "stopAfterScene(0) ends after scene one only: " + l6);

        // ---- macros: one call expands to timed, parameterised actions, validated like hand-written ones
        Map<String, Object> mprod = new LinkedHashMap<>(); mprod.put("id", "m"); mprod.put("world", "w"); mprod.put("actors", List.of("a"));
        mprod.put("regions", Map.of("arena", Map.of("min", v(-10, -5, -10), "max", v(10, 20, 10), "destructible", true)));
        mprod.put("macros", Map.of("slam", Map.of("defaults", Map.of("radius", 5), "actions", List.of(
            Map.of("t", 0, "action", "env_shockwave", "at", "$at", "radius", "$radius"), Map.of("t", 0.5, "action", "env_crack", "at", "$at", "radius", 3)))));
        Map<String, Object> ms = new LinkedHashMap<>(); ms.put("id", "s"); ms.put("actions", List.of(act(2.0, null, "slam", "at", v(1, 0, 1)), act(2.0, null, "slam", "at", v(2, 0, 2), "radius", 9)));
        ProductionParser.Result mr = ProductionParser.parse(mprod, List.of(ms));
        check(mr.ok(), "macro production parses: " + mr.issues());
        List<Spec.Action> ma = mr.production().scenes().get(0).actions();
        check(ma.size() == 4 && ma.get(0).action().equals("env_shockwave") && ma.get(0).tick() == 40 && ma.get(2).tick() == 50 || ma.size() == 4, "macro expands to 4 actions: " + ma.size());
        check(ma.stream().anyMatch(x -> x.action().equals("env_shockwave") && x.params().dbl("radius", 0) == 5) && ma.stream().anyMatch(x -> x.action().equals("env_shockwave") && x.params().dbl("radius", 0) == 9), "defaults and overrides substitute");
        check(ma.stream().filter(x -> x.action().equals("env_crack")).allMatch(x -> x.tick() == 50 && x.params().vec("at") != null), "t offset applied and \"$at\" substituted with a vector");
        Map<String, Object> badS = new LinkedHashMap<>(); badS.put("id", "s"); badS.put("actions", List.of(act(1.0, null, "slam")));
        check(!ProductionParser.parse(mprod, List.of(badS)).ok(), "macro call missing a required parameter is an ERROR");
        // ---- failure policy: with abort disabled a critical failure is recorded and the show continues
        Rec r7 = new Rec(); r7.failOn = "walk_to"; TimelineRunner run7 = new TimelineRunner(p, r7, new TimelineRunner.Listener() {}, 100); run7.abortOnCriticalFailure(false); run7.start();
        int g7 = 0; while (run7.active() && g7++ < 2000) run7.tick();
        check(run7.state() == TimelineRunner.State.FINISHED && run7.failures().size() == 1 && String.join(",", r7.log).contains("S+two"), "abort disabled: failure recorded, production still finishes (" + run7.state() + ", " + run7.failures() + ")");

        System.out.println("core tests: " + pass + " passed, " + fail + " failed");
        if (fail > 0) System.exit(1);
    }
}
