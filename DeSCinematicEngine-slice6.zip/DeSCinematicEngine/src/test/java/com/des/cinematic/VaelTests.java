package com.des.cinematic;

import com.des.cinematic.core.*;
import com.des.cinematic.rig.*;
import com.des.cinematic.vael.*;
import java.nio.file.*;
import java.util.*;

/** AZRATHIEL's OWN animation clips (ParamClip) and their mapping. No animation from the original plugin is involved. */
public final class VaelTests {
    static int pass, fail;
    static void check(boolean c, String n) { if (c) pass++; else { fail++; System.out.println("FAIL: " + n); } }
    @SuppressWarnings("unchecked") static Map<String, Object> m(Object o) { return (Map<String, Object>) o; }
    public static void main(String[] a) throws Exception {
        Map<String, Object> bundle = m(new ProductionFilesTest.J(Files.readString(Path.of(a.length > 0 ? a[0] : "build/bundle.json"))).parse());
        Map<String, Object> def = m(m(bundle.get("actors")).get("azrathiel"));
        ParamClipLibrary lib = new ParamClipLibrary(); List<Issue> iss = lib.load(m(m(bundle.get("rigs")).get("azrathiel_clips")));
        check(iss.isEmpty(), "clips load cleanly: " + iss);
        for (var e : m(def.get("animations")).entrySet()) check(lib.get(String.valueOf(e.getValue())).isPresent(), "clip exists for " + e.getKey() + " -> " + e.getValue());
        check(Form.valueOf(String.valueOf(m(def.get("model")).get("form"))) == Form.APOCALYPSE, "form APOCALYPSE");
        check(!Files.readString(Path.of("src/main/java/com/des/cinematic/paper/VaelBody.java")).contains("AnimState"), "VaelBody uses no original animation states");
        for (String old : new String[]{"AnimState", "AnimationController", "Poses", "Pose"}) check(!Files.exists(Path.of("src/main/java/com/des/cinematic/vael/" + old + ".java")), "original animation class removed: " + old);

        for (String id : lib.ids()) {
            ParamClip c = lib.get(id).get();
            for (double t = 0; t <= c.duration() + 1; t += 3) for (float f : c.sample(t)) if (Float.isNaN(f) || Float.isInfinite(f)) check(false, "NaN in " + id);
            if (c.loops()) { float d = 0; float[] p0 = c.sample(0), p1 = c.sample(c.duration() - 1e-6); for (int i = 0; i < P.COUNT; i++) d = Math.max(d, Math.abs(p0[i] - p1[i])); check(d < 0.05f, "loop seamless: " + id + " (" + d + ")"); }
            else { float[] e1 = c.sample(c.duration()), e2 = c.sample(c.duration() + 99); check(Arrays.equals(e1, e2), "one-shot holds its last pose: " + id); }
            for (ParamClip.Key k : c.keys()) { float[] v = k.v();
                for (int i = 0; i < 4; i++) if (Math.abs(v[P.ARM_RAISE + i]) > 200 || Math.abs(v[P.ARM_SPREAD + i]) > 120 || v[P.FORE_BEND + i] < -10 || v[P.FORE_BEND + i] > 140) check(false, id + " arm angle out of range");
                if (v[P.BODY_SCALE] < 0.3 || v[P.BODY_SCALE] > 1.6 || v[P.HALO_RADIUS] < 0 || v[P.HALO_RADIUS] > 3.5 || v[P.CORE_SCALE] < 0 || v[P.CORE_SCALE] > 4) check(false, id + " scale channel out of range"); }
        }
        float[] idle = lib.get("azr_idle").get().sample(10), ult = lib.get("azr_ult_charge").get().sample(20), block = lib.get("azr_block").get().sample(8), guard = lib.get("azr_guard").get().sample(10);
        check(ult[P.CORE_SCALE] > idle[P.CORE_SCALE] * 2 && ult[P.HALO_RADIUS] > idle[P.HALO_RADIUS] * 1.5 && ult[P.FRAG_RADIUS] > idle[P.FRAG_RADIUS] * 1.8, "the ultimate is far larger than idle (authority at rest, power in the ultimate)");
        check(block[P.ARM_RAISE] > idle[P.ARM_RAISE] + 60 && block[P.ARM_SPREAD] < idle[P.ARM_SPREAD], "block raises and crosses the arms");
        check(guard[P.TORSO_PITCH] > idle[P.TORSO_PITCH] + 4, "guard stance leans into the fight");
        check(idle[P.HOVER_AMP] < 0.12f && idle[P.HALO_SPEED] < 40, "idle is slow and restrained");
        float[] strikeEnd = lib.get("azr_strike").get().sample(0.3 * 20), strikeMid = lib.get("azr_strike").get().sample(0.48 * 20);
        check(strikeEnd[P.ARM_RAISE] > 150 && strikeMid[P.ARM_RAISE] < 40, "heavy strike goes overhead then down");
        // animator: crossfade has no pop, finished flag, freeze-free ticking
        ParamAnimator an = new ParamAnimator(); an.play(lib.get("azr_idle").get(), 0); for (int i = 0; i < 20; i++) an.tick();
        float[] before = new float[P.COUNT]; for (int i = 0; i < P.COUNT; i++) before[i] = an.get(i);
        an.play(lib.get("azr_ult_release").get(), 8); an.tick(); float jump = 0; for (int i = 0; i < P.COUNT; i++) jump = Math.max(jump, Math.abs(an.get(i) - before[i]));
        check(jump < 60, "crossfade has no pop (max channel jump " + jump + ")");
        ParamAnimator os = new ParamAnimator(); os.play(lib.get("azr_counter").get(), 0); for (int i = 0; i < 30; i++) os.tick(); check(os.finished(), "one-shot finishes");
        System.out.println("vael tests: " + pass + " passed, " + fail + " failed");
        if (fail > 0) System.exit(1);
    }
}
