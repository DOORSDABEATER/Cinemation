package com.des.cinematic;

import com.des.cinematic.core.*;
import java.nio.file.*;
import java.util.*;
import java.util.function.Predicate;

/**
 * Regression tests for the "unknown block 'minecraft:chain'" validation failure. The server is SIMULATED: a registry of accepted block
 * names with Bukkit-like parsing (unknown base name => rejected; "name[prop=value]" => base name is what matters). These tests prove
 * the resolution LOGIC; what a real Paper server accepts is reported at runtime by /descinematic validate.
 */
public final class BlockCompatTests {
    static int pass, fail;
    static void check(boolean c, String n) { if (c) pass++; else { fail++; System.out.println("FAIL: " + n); } }
    @SuppressWarnings("unchecked") static Map<String, Object> m(Object o) { return (Map<String, Object>) o; }

    static Predicate<String> server(Set<String> names) { return s -> names.contains(BlockCompat.base(s)); }
    static final Set<String> COMMON = Set.of("minecraft:deepslate_tiles", "minecraft:deepslate_bricks", "minecraft:polished_blackstone", "minecraft:chiseled_polished_blackstone",
            "minecraft:polished_blackstone_bricks", "minecraft:chiseled_deepslate", "minecraft:light", "minecraft:iron_bars", "minecraft:air");
    static Set<String> with(String... extra) { Set<String> s = new HashSet<>(COMMON); s.addAll(Arrays.asList(extra)); return s; }

    public static void main(String[] a) throws Exception {
        List<String> fb = List.of("minecraft:iron_chain", "minecraft:iron_bars");
        Map<String, List<String>> fallbacks = Map.of("minecraft:chain", fb);

        // the ORIGINAL bug, reproduced: exact-name lookup (what the engine did before) fails on such a server, with or without the axis state
        check(!server(with("minecraft:iron_chain")).test("minecraft:chain") && !server(with("minecraft:iron_chain")).test("minecraft:chain[axis=y]"), "old behaviour: chain and chain[axis=y] are both rejected when the name is unknown");
        // the exact failure from the field: a server that does NOT know 'minecraft:chain' but knows 'iron_chain'
        BlockCompat.Resolution modern = BlockCompat.resolve("minecraft:chain", fallbacks, server(with("minecraft:iron_chain")));
        check(modern.ok() && modern.resolved().equals("minecraft:iron_chain") && modern.kind() == BlockCompat.Kind.RENAMED, "modern server: chain -> iron_chain (RENAMED): " + modern);
        check(modern.tried().contains("minecraft:chain") && modern.tried().contains("minecraft:chain[axis=y]"), "both 'chain' and 'chain[axis=y]' were tried first: " + modern.tried());
        // property syntax does not help when the NAME is unknown: it must not be reported as the resolution
        check(!modern.resolved().startsWith("minecraft:chain"), "chain[axis=y] is not accepted when the base name is unknown");

        // older server that still calls it 'chain'
        BlockCompat.Resolution legacy = BlockCompat.resolve("minecraft:chain", fallbacks, server(with("minecraft:chain")));
        check(legacy.kind() == BlockCompat.Kind.EXACT && legacy.resolved().equals("minecraft:chain"), "legacy server: exact 'chain': " + legacy);
        // structure written with the NEW name still works on an old server
        BlockCompat.Resolution rev = BlockCompat.resolve("minecraft:iron_chain", null, server(with("minecraft:chain")));
        check(rev.ok() && rev.resolved().equals("minecraft:chain") && rev.kind() == BlockCompat.Kind.RENAMED, "reverse rename works: " + rev);
        // block states survive a rename
        BlockCompat.Resolution st = BlockCompat.resolve("minecraft:chain[axis=x]", fallbacks, server(with("minecraft:iron_chain")));
        check(st.resolved().equals("minecraft:iron_chain[axis=x]"), "state preserved across rename: " + st.resolved());
        // neither spelling exists: structural fallback keeps the hanging silhouette (iron bars)
        BlockCompat.Resolution bars = BlockCompat.resolve("minecraft:chain", fallbacks, server(with()));
        check(bars.kind() == BlockCompat.Kind.FALLBACK && bars.resolved().equals("minecraft:iron_bars"), "no chain at all: FALLBACK iron_bars: " + bars);
        // nothing works => UNRESOLVED (becomes a validation ERROR, never a silent skip)
        BlockCompat.Resolution none = BlockCompat.resolve("minecraft:chain", fallbacks, server(Set.of("minecraft:air")));
        check(!none.ok() && none.kind() == BlockCompat.Kind.UNRESOLVED && none.resolved() == null, "nothing accepted => UNRESOLVED");
        // a predicate that throws counts as 'not accepted'
        check(BlockCompat.resolve("minecraft:chain", fallbacks, s -> { throw new IllegalArgumentException(s); }).kind() == BlockCompat.Kind.UNRESOLVED, "throwing predicate => UNRESOLVED");
        // unrelated blocks are untouched
        check(BlockCompat.resolve("minecraft:deepslate_tiles", fallbacks, server(with())).kind() == BlockCompat.Kind.EXACT, "ordinary block resolves exactly");
        check(BlockCompat.resolve("minecraft:light[level=6]", null, server(with())).resolved().equals("minecraft:light[level=6]"), "light block with state resolves exactly");
        check(BlockCompat.candidates("minecraft:deepslate_tiles", null).equals(List.of("minecraft:deepslate_tiles")), "no spurious candidates for ordinary blocks");

        // ---- the REAL structure under each simulated server
        Map<String, Object> bundle = m(new ProductionFilesTest.J(Files.readString(Path.of(a.length > 0 ? a[0] : "build/bundle.json"))).parse());
        Map<String, Object> prod = m(m(m(bundle.get("productions")).get("azrathiel_null_requiem")).get("production"));
        Spec.Region arena = ProductionParser.parse(prod, List.of(Map.of("id", "x", "actions", List.of()))).production().regions().get(0);
        StructureBuilder.Result r = StructureBuilder.build(m(m(bundle.get("structures")).get("sealed_chamber")), arena);
        check(r.fallbacks().containsKey("minecraft:chain") && r.fallbacks().get("minecraft:chain").equals(fb), "structure declares the chain fallbacks: " + r.fallbacks());
        long chainOps = r.ops().stream().filter(o -> o.block().equals("minecraft:chain")).count();
        check(chainOps == 9 * 9, "design intact: 9 hanging chains x length 9 = 81 placements (" + chainOps + ")");
        Set<String> names = new TreeSet<>(); for (StructureBuilder.Op o : r.ops()) names.add(o.block());
        Object[][] servers = {{"26.x-style (iron_chain)", with("minecraft:iron_chain"), "minecraft:iron_chain", 0}, {"legacy (chain)", with("minecraft:chain"), "minecraft:chain", 0}, {"no chain at all", with(), "minecraft:iron_bars", 1}};
        for (Object[] s : servers) {
            @SuppressWarnings("unchecked") Set<String> reg = (Set<String>) s[1]; int unresolved = 0, warns = 0; String chainAs = null;
            for (String n : names) { BlockCompat.Resolution res = BlockCompat.resolve(n, r.fallbacks(), server(reg)); if (!res.ok()) unresolved++; else if (res.kind() == BlockCompat.Kind.FALLBACK) warns++; if (n.equals("minecraft:chain")) chainAs = res.resolved(); }
            check(unresolved == 0, s[0] + ": every block of the chamber resolves (" + unresolved + " unresolved)");
            check(Objects.equals(chainAs, s[2]), s[0] + ": chains become " + s[2] + " (got " + chainAs + ")");
            check(warns == (int) s[3], s[0] + ": fallback warnings = " + s[3] + " (got " + warns + ")");
        }
        // resolution never removes or moves a placement
        check(r.ops().stream().filter(o -> o.block().equals("minecraft:chain")).map(o -> o.x() + "," + o.y() + "," + o.z()).distinct().count() == 81, "81 distinct chain positions are all kept");
        System.out.println("block compat tests: " + pass + " passed, " + fail + " failed");
        if (fail > 0) System.exit(1);
    }
}
