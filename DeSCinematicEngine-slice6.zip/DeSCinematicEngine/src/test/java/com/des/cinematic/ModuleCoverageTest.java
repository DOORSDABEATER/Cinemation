package com.des.cinematic;

import com.des.cinematic.core.*;
import java.nio.file.*;
import java.util.*;

/** Every action used by the bundled productions must be implemented by the module that owns its category (source-level check). */
public final class ModuleCoverageTest {
    @SuppressWarnings("unchecked") static Map<String, Object> m(Object o) { return (Map<String, Object>) o; }
    public static void main(String[] args) throws Exception {
        Map<String, Object> bundle = m(new ProductionFilesTest.J(Files.readString(Path.of(args.length > 0 ? args[0] : "build/bundle.json"))).parse());
        Map<ActionCatalog.Category, List<String>> files = new EnumMap<>(ActionCatalog.Category.class);
        files.put(ActionCatalog.Category.ACTOR, List.of("ActorModule"));
        files.put(ActionCatalog.Category.COMBAT, List.of("CombatModule"));
        files.put(ActionCatalog.Category.WEAPON, List.of("WeaponModule"));
        files.put(ActionCatalog.Category.ENVIRONMENT, List.of("EnvironmentModule"));
        files.put(ActionCatalog.Category.AUDIO, List.of("AudioModule"));
        files.put(ActionCatalog.Category.PRESENTATION, List.of("PresentationModule"));
        files.put(ActionCatalog.Category.EFFECTS, List.of("FxModule"));
        Map<String, String> src = new HashMap<>();
        for (List<String> fl : files.values()) for (String f : fl) src.put(f, Files.readString(Path.of("src/main/java/com/des/cinematic/paper/" + f + ".java")));
        int missing = 0, used = 0;
        Set<String> seen = new TreeSet<>();
        for (var pe : m(bundle.get("productions")).entrySet()) {
            Map<String, Object> pb = m(pe.getValue()), prod = m(pb.get("production")), scenes = m(pb.get("scenes"));
            for (Object sid : (List<?>) prod.get("scene_order")) for (Object ao : (List<?>) m(scenes.get(String.valueOf(sid))).get("actions")) {
                String action = String.valueOf(m(ao).get("action")); if (!seen.add(action)) continue;
                var def = ActionCatalog.get(action).orElse(null); if (def == null || def.category() == ActionCatalog.Category.FLOW) continue;
                used++;
                boolean ok = false; for (String f : files.get(def.category())) if (src.get(f).contains("\"" + action + "\"")) ok = true;
                if (!ok) { missing++; System.out.println("NOT IMPLEMENTED: " + action + " (" + def.category() + ")"); }
            }
        }
        System.out.println("module coverage: " + used + " distinct actions used, " + missing + " not implemented");
        if (missing > 0) System.exit(1);
    }
}
