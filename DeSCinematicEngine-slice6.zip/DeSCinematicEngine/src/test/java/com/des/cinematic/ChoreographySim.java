package com.des.cinematic;

import com.des.cinematic.core.*;
import com.des.cinematic.motion.*;
import java.nio.file.*;
import java.util.*;

/**
 * Offline kinematic simulation of the whole production: actors move exactly as ActorModule moves them (same MotionPlan classes and
 * parameters) and attacks reposition exactly as CombatModule does (shared CombatGeometry). At every impact tick we check the blow can
 * physically reach the target. This verifies choreography coordinates without a server; it does NOT verify rendering.
 */
public final class ChoreographySim {
    @SuppressWarnings("unchecked") static Map<String, Object> m(Object o) { return (Map<String, Object>) o; }
    record Impact(int tick, Spec.Action a, String atk, String tgt, double want, String result) {}

    public static void main(String[] args) throws Exception {
        Map<String, Object> bundle = m(new ProductionFilesTest.J(Files.readString(Path.of(args.length > 0 ? args[0] : "build/bundle.json"))).parse());
        Map<String, Object> actorDefs = m(bundle.get("actors"));
        for (var pe : m(bundle.get("productions")).entrySet()) {
            Map<String, Object> pb = m(pe.getValue()), prod = m(pb.get("production")), scenes = m(pb.get("scenes"));
            List<Map<String, Object>> ordered = new ArrayList<>(); for (Object id : (List<?>) prod.get("scene_order")) ordered.add(m(scenes.get(String.valueOf(id))));
            Spec.Production p = ProductionParser.parse(prod, ordered).production();
            Map<String, ActorMotion> mo = new LinkedHashMap<>(); Map<String, Double> radius = new HashMap<>(), reachMul = new HashMap<>();
            List<Impact> impacts = new ArrayList<>(); int offset = 0, problems = 0, checked = 0; double worst = 0; String worstAt = "";
            for (Spec.Scene sc : p.scenes()) {
                int end = sc.endTick(); int ai = 0; List<Spec.Action> acts = sc.actions();
                for (int t = 0; t <= end; t++) {
                    while (ai < acts.size() && acts.get(ai).tick() <= t) { Spec.Action a = acts.get(ai++); problems += apply(a, t, mo, actorDefs, radius, impacts); }
                    for (Iterator<Impact> it = impacts.iterator(); it.hasNext(); ) {
                        Impact im = it.next(); if (im.tick() != t) continue; it.remove();
                        ActorMotion x = mo.get(im.atk()), y = mo.get(im.tgt()); if (x == null || y == null) continue;
                        double gap = x.pos().distXZ(y.pos()); checked++;
                        if (!im.result().equals("dodged")) { double excess = gap - im.want(); if (excess > worst) { worst = excess; worstAt = im.a().where() + " gap=" + String.format("%.1f", gap) + " want=" + String.format("%.1f", im.want()); }
                            if (CombatGeometry.missesGeometrically(gap, im.want())) { problems++; System.out.println("  MISS " + im.a().where() + " result=" + im.result() + String.format(" gap=%.2f want=%.2f", gap, im.want())); }
                            if (gap < im.want() - 1.0) { problems++; System.out.println("  OVERLAP " + im.a().where() + String.format(" gap=%.2f want=%.2f", gap, im.want())); } }
                    }
                    for (ActorMotion am : mo.values()) am.tick();
                }
                offset += end;
            }
            System.out.printf("choreography sim '%s': %d impacts checked, worst reach excess %.2f blocks (%s), %d problem(s)%n", pe.getKey(), checked, worst, worstAt, problems);
            if (problems > 0) System.exit(1);
        }
    }

    static double r(Map<String, Double> radius, Map<String, Object> defs, String id) { return radius.computeIfAbsent(id, k -> new Params(m(defs.get(k))).dbl("body_radius", 0.4)); }

    static int apply(Spec.Action a, int t, Map<String, ActorMotion> mo, Map<String, Object> defs, Map<String, Double> radius, List<Impact> impacts) {
        Params p = a.params(); String id = a.actor(); ActorMotion am = id == null ? null : mo.get(id);
        double walk = 0.12, run = 0.34; if (id != null && defs.get(id) != null) { Params sp = new Params(m(m(defs.get(id)).get("speeds"))); walk = sp.dbl("walk", walk); run = sp.dbl("run", run); }
        switch (a.action()) {
            case "spawn" -> { if (am == null) { ActorMotion n = new ActorMotion(p.vec("at"), p.dbl("yaw", 0)); n.turnRate(new Params(m(defs.get(id))).dbl("turn_rate", 18)); mo.put(id, n); } }
            case "despawn" -> mo.remove(id);
            case "walk_to" -> { if (am != null) am.move(new MotionPlan.Path(List.of(am.pos(), p.vec("to")), p.dbl("speed", walk), p.ease("ease", Ease.LINEAR)), true); }
            case "run_to" -> { if (am != null) am.move(new MotionPlan.Path(List.of(am.pos(), p.vec("to")), p.dbl("speed", run), p.ease("ease", Ease.LINEAR)), true); }
            case "dash_to" -> { if (am != null) am.move(new MotionPlan.Linear(am.pos(), p.vec("to"), a.durationTicks(), Ease.OUT_CUBIC), true); }
            case "jump_to" -> { if (am != null) am.move(new MotionPlan.Arc(am.pos(), p.vec("to"), p.dbl("apex", 1.3), a.durationTicks(), Ease.LINEAR), true); }
            case "leap_to" -> { if (am != null) am.move(new MotionPlan.Arc(am.pos(), p.vec("to"), p.dbl("apex", 3.0), a.durationTicks(), Ease.OUT_QUAD), true); }
            case "follow_path" -> { if (am != null) { List<Vec3> pts = new ArrayList<>(); pts.add(am.pos()); pts.addAll(p.path("path")); am.move(new MotionPlan.Path(pts, p.dbl("speed", walk), p.ease("ease", Ease.LINEAR)), true); } }
            case "teleport" -> { if (am != null) am.teleport(p.vec("to")); }
            case "launch" -> { if (am != null) am.move(new MotionPlan.Arc(am.pos(), p.vec("to"), p.dbl("apex", 12), a.durationTicks(), Ease.OUT_QUAD), false); }
            case "knockback" -> { if (am != null) am.move(new MotionPlan.Linear(am.pos(), p.vec("to"), a.durationTicks(), Ease.OUT_QUAD), false); }
            case "dodge" -> { if (am != null) am.move(new MotionPlan.Linear(am.pos(), p.vec("to"), Math.max(3, a.durationTicks()), Ease.OUT_QUAD), false); }
            case "face" -> { if (am != null && p.has("target") && mo.get(p.str("target", "")) != null) { ActorMotion tg = mo.get(p.str("target", "")); am.faceTarget(tg::pos); } else if (am != null && p.has("at")) { Vec3 at = p.vec("at"); am.faceTarget(() -> at); } }
            case "attack", "counter", "weapon_attack", "teleport_attack" -> {
                ActorMotion tg = mo.get(p.str("target", "")); if (am == null || tg == null) { System.out.println("  MISSING ACTOR for " + a.where()); return 1; }
                boolean weapon = a.action().equals("weapon_attack") || a.action().equals("teleport_attack");
                double want = CombatGeometry.wantedDistance(p.dbl("reach", weapon ? 2.7 : 1.9), r(radius, defs, p.str("target", "")));
                int impact = Math.max(1, (int) Math.round(p.dbl("impact", 0.3) * 20));
                am.faceTarget(tg::pos);
                if (a.action().equals("teleport_attack")) { double fy = Math.toRadians(tg.yaw()); double s = p.bool("behind", false) ? -1 : 1; am.teleport(new Vec3(tg.pos().x() - Math.sin(fy) * want * s, am.pos().y(), tg.pos().z() + Math.cos(fy) * want * s)); }
                else if (p.bool("move_in", true) && CombatGeometry.needsRepositioning(am.pos().distXZ(tg.pos()), want)) am.move(new MotionPlan.Linear(am.pos(), CombatGeometry.stepInPoint(am.pos(), tg.pos(), want), CombatGeometry.stepInTicks(impact), Ease.OUT_QUAD), false);
                impacts.add(new Impact(t + impact, a, id, p.str("target", ""), want, p.str("result", "hit")));
            }
            default -> { }
        }
        return 0;
    }
}
