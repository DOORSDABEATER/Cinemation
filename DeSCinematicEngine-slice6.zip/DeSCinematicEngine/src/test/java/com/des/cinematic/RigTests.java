package com.des.cinematic;

import com.des.cinematic.core.*;
import com.des.cinematic.rig.*;
import java.nio.file.*;
import java.util.*;

/** Rig maths + the real ERROR clip file. Needs build/bundle.json (tools/yaml_to_json.py). */
public final class RigTests {
    static int pass, fail;
    static void check(boolean c, String n) { if (c) pass++; else { fail++; System.out.println("FAIL: " + n); } }
    @SuppressWarnings("unchecked") static Map<String, Object> m(Object o) { return (Map<String, Object>) o; }
    static final int HEAD = 0, BODY = 1, ARM_R = 2, ARM_L = 3, LEG_R = 4, LEG_L = 5;
    static final double S = 0.9;

    public static void main(String[] a) throws Exception {
        Map<String, Object> bundle = m(new ProductionFilesTest.J(Files.readString(Path.of(a.length > 0 ? a[0] : "build/bundle.json"))).parse());
        ClipLibrary lib = new ClipLibrary();
        List<Issue> iss = lib.load(m(m(bundle.get("rigs")).get("error_clips")));
        check(iss.isEmpty(), "clips load cleanly: " + iss);
        Map<String, Object> animMap = m(m(m(bundle.get("actors")).get("error")).get("animations"));
        for (var e : animMap.entrySet()) check(lib.get(String.valueOf(e.getValue())).isPresent(), "clip exists for " + e.getKey() + " -> " + e.getValue());

        // neutral pose geometry (px -> blocks at scale 0.9)
        RigSolver.BoneXf[] n = RigSolver.solve(new Pose(), 0, S);
        check(Math.abs(n[HEAD].ty() - 24 / 16.0 * S) < 1e-9, "neck at 24px: " + n[HEAD].ty());
        check(Math.abs(n[ARM_R].tx() + 6 / 16.0 * S) < 1e-9 && Math.abs(n[ARM_L].tx() - 6 / 16.0 * S) < 1e-9, "arms at +-6px (right arm on -X)");
        check(Math.abs(n[LEG_R].ty() - 12 / 16.0 * S) < 1e-9 && Math.abs(n[LEG_R].tx() + 2 / 16.0 * S) < 1e-9, "hips at 12px, legs +-2px");

        // yaw: facing -X (yaw 90), the character's right arm must be on the north (-Z) side
        RigSolver.BoneXf[] y90 = RigSolver.solve(new Pose(), 90, S);
        check(y90[ARM_R].tz() < -0.2 && Math.abs(y90[ARM_R].tx()) < 1e-6, "yaw 90: right arm at -Z (" + y90[ARM_R].tz() + ")");

        // forward swing: a hand-end point of a limb rotated rx=+90 must point toward +Z (forward)
        Pose fwd = new Pose(); fwd.set(Pose.index("arm_r"), 0, 90);
        RigSolver.BoneXf ar = RigSolver.solve(fwd, 0, S)[ARM_R];
        double[] tip = ar.q().rotate(0, -12, 0);   // hand end in bone space (down 12px)
        check(tip[2] > 11 && Math.abs(tip[1]) < 1e-6, "arm rx=+90 swings forward: " + Arrays.toString(tip));

        // lying on back: head behind (-Z) and low; feet ahead (+Z)
        Pose lie = lib.get("error_crater_lie").orElseThrow().sample(0);
        RigSolver.BoneXf[] L = RigSolver.solve(lie, 0, S);
        check(L[HEAD].ty() < 0.5 && L[HEAD].tz() < -0.5, "lying: head low and toward -Z (y=" + L[HEAD].ty() + " z=" + L[HEAD].tz() + ")");
        double[] foot = L[LEG_R].q().rotate(0, -12, 0);
        check(L[LEG_R].tz() + foot[2] * S / 16 > 0.4 && L[LEG_R].ty() + foot[1] * S / 16 < 0.4, "lying: feet toward +Z and near ground");
        // body stays above the floor in every lying key (back plane ~2px thick => centre >= 1.5px)
        double minY = 9;
        for (double t = 0; t <= 80; t += 4) { Pose p = lib.get("error_land_flat").orElseThrow().sample(t); RigSolver.BoneXf[] b = RigSolver.solve(p, 0, S); minY = Math.min(minY, b[BODY].ty()); }
        check(minY > -0.02, "land_flat never sinks body pivot below ground: " + minY);

        // punch reaches forward at impact key
        Clip pr = lib.get("error_punch_right").orElseThrow();
        Pose hit = pr.sample(0.22 * 20);
        RigSolver.BoneXf shoulder = RigSolver.solve(hit, 0, S)[ARM_R];
        double[] hand = shoulder.q().rotate(0, -12, 0);
        double reach = shoulder.tz() + hand[2] * S / 16;
        check(reach > 0.45, "right punch hand ends >0.45 blocks in front (" + reach + ")");
        // sword/scythe overhead: hands above head at the raise key
        Pose up = lib.get("error_scythe_slash_v").orElseThrow().sample(0.26 * 20);
        RigSolver.BoneXf[] U = RigSolver.solve(up, 0, S);
        double[] h2 = U[ARM_R].q().rotate(0, -12, 0);
        check(U[ARM_R].ty() + h2[1] * S / 16 > U[HEAD].ty() + 0.3, "overhead raise: hand above the neck by 0.3+ blocks");

        // loops are seamless; one-shot clips hold their last pose
        for (String id : lib.ids()) {
            Clip c = lib.get(id).get();
            if (c.loops()) { double d = 0; Pose p0 = c.sample(0), p1 = c.sample(c.duration() - 1e-6); for (int i = 0; i < Pose.N; i++) d = Math.max(d, Math.abs(p0.v[i] - p1.v[i])); check(d < 0.05, "loop seamless: " + id + " (" + d + ")"); }
            else { Pose e1 = c.sample(c.duration()), e2 = c.sample(c.duration() + 50); boolean same = true; for (int i = 0; i < Pose.N; i++) if (Math.abs(e1.v[i] - e2.v[i]) > 1e-9) same = false; check(same, "one-shot holds last pose: " + id); }
        }
        // no pose channel is wildly out of range (authoring typo guard): rotations within +-1100, offsets within +-30px
        for (String id : lib.ids()) for (Clip.Key k : lib.get(id).get().keys()) for (int b = 0; b < 7; b++) {
            for (int ch = 0; ch < 3; ch++) if (Math.abs(k.pose().get(b, ch)) > 1100) check(false, id + " rotation out of range");
            for (int ch = 3; ch < 6; ch++) if (Math.abs(k.pose().get(b, ch)) > 30) check(false, id + " offset out of range");
        }

        // animator: crossfade is continuous, freeze holds, finished flag
        Animator an = new Animator(); an.play(lib.get("error_idle").orElseThrow(), 0); for (int i = 0; i < 10; i++) an.tick();
        Pose before = an.pose().copy(); an.play(lib.get("error_kick").orElseThrow(), 6); an.tick();
        double jump = 0; for (int i = 0; i < Pose.N; i++) jump = Math.max(jump, Math.abs(an.pose().v[i] - before.v[i]));
        check(jump < 25, "crossfade has no pop (max channel jump " + jump + ")");
        for (int i = 0; i < 40; i++) an.tick();
        check(an.finished(), "kick finishes");
        Animator fz = new Animator(); fz.play(lib.get("error_walk").orElseThrow(), 0); for (int i = 0; i < 7; i++) fz.tick(); Pose f1 = fz.pose().copy(); fz.speed(0); for (int i = 0; i < 20; i++) fz.tick();
        check(Arrays.equals(f1.v, fz.pose().v), "speed 0 freezes the pose");
        // walk cycle: legs alternate
        Clip w = lib.get("error_walk").orElseThrow();
        check(w.sample(5).get(Pose.index("leg_r"), 0) * w.sample(15).get(Pose.index("leg_r"), 0) < 0, "walk legs alternate");

        System.out.println("rig tests: " + pass + " passed, " + fail + " failed");
        if (fail > 0) System.exit(1);
    }
}
