# Testing plan

Status legend: **offline** = verified in the authoring sandbox without a server; **server** = must be done on a real Paper 26.2 server.

| # | Area | How | Status |
|---|---|---|---|
| 1 | Plugin startup | start server, expect "enabled" + 6 modules registered | server |
| 2 | Dependency detection | none required; ModelEngine is NOT used | n/a |
| 3 | ModelEngine integration | not implemented (display rigs) | n/a |
| 4 | Actor spawning | `/descinematic start azrathiel_null_requiem until sealed_chamber`: ERROR appears at the chamber entrance | server |
| 5 | Actor cleanup | `/descinematic stop`: no ItemDisplays left (`/kill @e[type=item_display,tag=descinematic_actor]` finds none) | server |
| 6 | Animation playback | all 41 ERROR clips parse and map (offline); visual quality in game | offline + server |
| 7 | Movement interpolation | exact landings, smooth turning, loops seamless | **offline** (core + rig tests) |
| 8 | Multiple simultaneous actors | ERROR and AZRATHIEL move concurrently | offline sim + server |
| 9 | Timeline synchronisation | deterministic order, pause freezes clock, failures name production/scene/actor/action | **offline** |
| 10 | Concurrent actions | same-tick actions run in file order | **offline** |
| 11 | Dialogue playback | event fires + caption fallback; real voice needs .ogg files | server (voice missing) |
| 12-14 | Weapon summon / destruction / fragments | `... until summoning`, then the full run: 5-part assembly, 24-fragment shatter, fragments persist | server |
| 15-16 | Environment destruction / restoration | build 58k blocks, crater, pillar collapse, then restoration after the configured delay | server |
| 17 | Player movement during events | walk through the chamber during a run; nothing moves/damages you | server |
| 18 | Audience protection | no damage, no push, no spectator, no teleport, no camera | server (design: none of these are ever applied) |
| 19 | Pause / resume | `/descinematic pause` then `resume`: actors freeze/continue | server |
| 20 | Unexpected stop | `stop` mid-fight: actors removed, blocks restored | server |
| 21 | Restart recovery | kill the server mid-build, restart: journal in `plugins/DeSCinematicEngine/recovery/` is restored | server |
| 22 | Full production | `/descinematic start azrathiel_null_requiem` (about 400 s) | server |

## Suggested first session
1. `gradle build`, copy the jar to `plugins/`, merge `resourcepack/assets/des_cinematic` into the shared DeS pack, install the pack.
2. Flat empty plot (the chamber is 76 x 84 blocks, 27 tall). Stand at the floor centre: `/descinematic setorigin azrathiel_null_requiem`.
3. `/descinematic validate azrathiel_null_requiem` (expect warnings about missing voice files only).
4. `/descinematic start azrathiel_null_requiem until first_battle` (scenes 1-3), then the rest.

Offline suite: `sh tools/run_core_tests.sh` (JDK 21+, python3 + PyYAML).
