package com.des.cinematic.paper;

import com.des.cinematic.api.CinematicApi;
import com.des.cinematic.core.Issue;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextColor;
import org.bukkit.command.*;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;

import java.io.File;
import java.io.IOException;
import java.util.*;

/** /descinematic. Strictly OP-only: no player-facing command can start or influence a production. */
public final class CinematicCommand implements CommandExecutor, TabCompleter {
    private static final List<String> SUB = List.of("help", "list", "status", "start", "stop", "pause", "resume", "reload", "preview", "validate", "reset", "setorigin", "debug");
    private final DeSCinematicPlugin plugin; private final ProductionService svc;

    CinematicCommand(DeSCinematicPlugin plugin, ProductionService svc) { this.plugin = plugin; this.svc = svc; }

    private static void say(CommandSender s, TextColor c, String t) { s.sendMessage(Component.text(t, c)); }

    @Override public boolean onCommand(CommandSender s, Command cmd, String label, String[] a) {
        if (!s.isOp()) { say(s, NamedTextColor.RED, "You do not have permission to use this command."); return true; }
        String sub = a.length == 0 ? "help" : a[0].toLowerCase(Locale.ROOT);
        switch (sub) {
            case "help" -> help(s);
            case "list" -> {
                if (svc.productionIds().isEmpty()) say(s, NamedTextColor.YELLOW, "No productions loaded.");
                for (String id : svc.productionIds()) {
                    var l = svc.library().get(id).orElseThrow();
                    say(s, NamedTextColor.AQUA, id + " - " + l.spec().displayName() + " (" + l.spec().scenes().size() + " scenes, " + String.format("%.0fs", l.spec().totalTicks() / 20.0) + ")");
                }
            }
            case "status" -> say(s, NamedTextColor.GREEN, svc.status());
            case "start" -> {
                if (a.length < 2) { say(s, NamedTextColor.RED, "Usage: /descinematic start <production> [until <scene>]"); break; }
                String until = a.length >= 4 && a[2].equalsIgnoreCase("until") ? a[3] : null;
                var r = svc.start(a[1], until);
                say(s, r.ok() ? NamedTextColor.GREEN : NamedTextColor.RED, r.result() + ": " + r.message());
            }
            case "stop" -> { boolean did = svc.stop(true); say(s, did ? NamedTextColor.GREEN : NamedTextColor.YELLOW, did ? "Stopped. Temporary entities removed and blocks restored." : "Nothing is running."); }
            case "pause" -> { boolean did = svc.pause(); say(s, did ? NamedTextColor.GREEN : NamedTextColor.YELLOW, did ? "Paused." : "Nothing to pause."); }
            case "resume" -> { boolean did = svc.resume(); say(s, did ? NamedTextColor.GREEN : NamedTextColor.YELLOW, did ? "Resumed." : "Nothing to resume."); }
            case "reload" -> {
                if (svc.activeProduction().isPresent()) { say(s, NamedTextColor.RED, "Refusing to reload while a production is running. /descinematic stop first."); break; }
                plugin.reloadConfig(); svc.library().reload();
                say(s, NamedTextColor.GREEN, "Reloaded " + svc.productionIds().size() + " production(s).");
            }
            case "preview" -> {
                if (a.length < 2) { say(s, NamedTextColor.RED, "Usage: /descinematic preview <production>   (dry run: prints the timeline, spawns nothing)"); break; }
                List<String> lines = svc.preview(a[1]);
                int shown = 0;
                for (String ln : lines) { if (shown++ > 60) { say(s, NamedTextColor.GRAY, "  ... (" + (lines.size() - 60) + " more lines in console)"); break; } say(s, NamedTextColor.GRAY, ln); }
                lines.forEach(ln -> plugin.getLogger().info(ln));
            }
            case "validate" -> {
                if (a.length < 2) { say(s, NamedTextColor.RED, "Usage: /descinematic validate <production>"); break; }
                List<Issue> issues = svc.validate(a[1]);
                long err = issues.stream().filter(i -> i.severity() == Issue.Severity.ERROR).count(), warn = issues.stream().filter(i -> i.severity() == Issue.Severity.WARN).count();
                int shown = 0;
                for (Issue i : issues) {
                    if (shown++ >= 25) { say(s, NamedTextColor.GRAY, "... " + (issues.size() - 25) + " more in console"); break; }
                    say(s, i.severity() == Issue.Severity.ERROR ? NamedTextColor.RED : i.severity() == Issue.Severity.WARN ? NamedTextColor.YELLOW : NamedTextColor.GRAY, i.toString());
                }
                issues.forEach(i -> plugin.getLogger().info("validate: " + i));
                say(s, err == 0 ? NamedTextColor.GREEN : NamedTextColor.RED, "Validation: " + err + " error(s), " + warn + " warning(s). " + (err == 0 ? "Production can start." : "Production cannot start."));
            }
            case "reset" -> {
                if (a.length < 2) { say(s, NamedTextColor.RED, "Usage: /descinematic reset <production>"); break; }
                svc.reset(a[1]); say(s, NamedTextColor.GREEN, "Reset '" + a[1] + "': stopped, entities removed, block journal restored.");
            }
            case "setorigin" -> {
                if (!(s instanceof Player p)) { say(s, NamedTextColor.RED, "Run this in-game: it uses your position."); break; }
                if (a.length < 2 || svc.library().get(a[1]).isEmpty()) { say(s, NamedTextColor.RED, "Usage: /descinematic setorigin <production>"); break; }
                if (svc.activeProduction().isPresent()) { say(s, NamedTextColor.RED, "Stop the running production first."); break; }
                var loc = p.getLocation();
                File f = new File(plugin.getDataFolder(), "origins.yml");
                YamlConfiguration y = YamlConfiguration.loadConfiguration(f);
                y.set(a[1] + ".world", loc.getWorld().getName()); y.set(a[1] + ".x", loc.getBlockX()); y.set(a[1] + ".y", loc.getBlockY()); y.set(a[1] + ".z", loc.getBlockZ());
                try { y.save(f); } catch (IOException e) { say(s, NamedTextColor.RED, "Could not save origins.yml: " + e.getMessage()); break; }
                svc.library().reload();
                say(s, NamedTextColor.GREEN, "Origin of '" + a[1] + "' set to " + loc.getWorld().getName() + " " + loc.getBlockX() + " " + loc.getBlockY() + " " + loc.getBlockZ() + ". Floor level of the arena is this Y.");
            }
            case "debug" -> {
                boolean on = !plugin.getConfig().getBoolean("engine.log-every-action", false);
                plugin.getConfig().set("engine.log-every-action", on);
                say(s, NamedTextColor.GREEN, "Per-action logging " + (on ? "ON" : "OFF") + " (until reload). Modules: " + svc.modules().stream().map(m -> m.id()).toList());
            }
            default -> help(s);
        }
        return true;
    }

    private void help(CommandSender s) {
        say(s, NamedTextColor.GOLD, "DeS Live Cinematic Engine (OP only)");
        for (String l : List.of("list", "status", "start <production> [until <scene>]  - until runs only the first scenes", "stop", "pause", "resume", "reload", "preview <production>  - dry-run timeline", "validate <production>", "reset <production>", "setorigin <production>  - uses your position", "debug"))
            say(s, NamedTextColor.GRAY, "  /descinematic " + l);
    }

    @Override public List<String> onTabComplete(CommandSender s, Command c, String label, String[] a) {
        if (!s.isOp()) return List.of();
        List<String> out = new ArrayList<>();
        if (a.length == 1) { for (String x : SUB) if (x.startsWith(a[0].toLowerCase(Locale.ROOT))) out.add(x); }
        else if (a.length == 3 && a[0].equalsIgnoreCase("start")) { if ("until".startsWith(a[2].toLowerCase(Locale.ROOT))) out.add("until"); }
        else if (a.length == 4 && a[0].equalsIgnoreCase("start") && a[2].equalsIgnoreCase("until")) svc.library().get(a[1]).ifPresent(l -> l.spec().scenes().forEach(scene -> { if (scene.id().startsWith(a[3])) out.add(scene.id()); }));
        else if (a.length == 2 && List.of("start", "preview", "validate", "reset", "setorigin").contains(a[0].toLowerCase(Locale.ROOT)))
            for (String id : svc.productionIds()) if (id.startsWith(a[1].toLowerCase(Locale.ROOT))) out.add(id);
        return out;
    }
}
