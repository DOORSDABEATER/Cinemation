package com.des.cinematic.vael;

/** Anything that can supply the rig's continuous pose parameters (indices in {@link P}). */
public interface ParamSource {
    float get(int param);

    /** Optional head rotation in degrees; defaults to neutral for animators without head tracks. */
    default float headYaw() { return 0.0f; }

    /** Optional head pitch in degrees; defaults to neutral for animators without head tracks. */
    default float headPitch() { return 0.0f; }
}
